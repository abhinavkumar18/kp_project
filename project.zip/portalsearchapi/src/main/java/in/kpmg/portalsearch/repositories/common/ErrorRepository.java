package in.kpmg.portalsearch.repositories.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.kpmg.portalsearch.models.common.ErrorDetails;

@Repository
public interface ErrorRepository extends JpaRepository<ErrorDetails, Integer> {
    
}