package in.kpmg.portalsearch.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import in.kpmg.portalsearch.dtos.common.AdvanceHospitalSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceProcedureSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.portalsearch.dtos.common.SearchHospitalResult;
import in.kpmg.portalsearch.dtos.common.SearchProcedureResult;
import in.kpmg.portalsearch.dtos.common.SearchSpecialityResult;

import org.springframework.stereotype.Service;


@Service
public class PublicService {

	@PersistenceContext
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public List<SearchHospitalResult> advanceHospitalSearch(AdvanceHospitalSearch request) {

		String nativeQuery ="SELECT ah.hosp_name hospitalName,\n"
				+ "        ah.hosp_type hospitalType,\n"
				+ "                ah.hosp_addr1\n"
				+ "    || ' '\n"
				+ "    || ah.hosp_addr2\n"
				+ "    || ' '\n"
				+ "    || ah.hosp_addr3 hospitalAddress,\n"
				+ "        al.loc_name districtName,\n"
				+ "        spec.specialities_mapped specialities,\n"
				+ "        ah.crt_dt empanalledDate,\n"
				+ "         medco.mithra_name medcoName,\n"
				+ "        medco.mithra_contact medcoContactNo,\n"
				+ "        mit.mithra_name mitraName,\n"
				+ "        mit.mithra_contact mitraContactNo\n"
				+ "FROM\n"
				+ "   \n"
				+ "    ASRIM_LOCATIONS al\n"
				+ "     RIGHT JOIN ASRIM_HOSPITALS ah ON al.loc_id=ah.dist_id and al.loc_hdr_id='LH6'\n"
				+ "     left join (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            group_concat(ahs.speciality_id) specialities_mapped\n"
				+ "        FROM\n"
				+ "            ASRIM_HOSP_SPECIALITY ahs,\n"
				+ "            ASRIM_PHASE_DURATION apd\n"
				+ "        WHERE\n"
				+ "  			ahs.phase_id = apd.phase_id\n"
					+ "            AND   ahs.renewal = apd.renewal\n"
					+ "            AND   apd.end_dt > SYSDATE()\n"
					+ "            AND   ahs.is_active_flg = 'Y' "
				+" GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) spec on ah.hosp_id=spec.hosp_id \n"
				+ "     left join (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            group_concat(au.first_name) mithra_name,\n"
				+ "            group_concat(au.cug) mithra_contact\n"
				+ "        FROM\n"
				+ "            ASRIM_MIT_USERS amu,\n"
				+ "            ASRIM_USERS au\n"
				+ "        WHERE\n"
				+ " 			amu.user_id = au.user_id\n"
				 +"            AND   amu.eff_end_dt IS NULL "
				 +" GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) mit on ah.hosp_id=mit.hosp_id\n"
				+ "          left join   (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            group_concat(au.first_name) mithra_name,\n"
				+ "            group_concat(au.cug) mithra_contact\n"
				+ "        FROM\n"
				+ "            ASRIM_NWH_USERS amu,\n"
				+ "            ASRIM_USERS au\n"
				+ "        WHERE"
				+" 				amu.user_id = au.user_id\n"
				+ "            AND   amu.eff_end_dt IS NULL "
				+ " GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) medco on medco.hosp_id=ah.hosp_id\n"
				+ "WHERE  ah.hosp_active_yn = 'Y'\n";
			if(request.getDistrictid() != null)
					nativeQuery = nativeQuery + "   and  ah.dist_id='"+request.getDistrictid()+"'";
			if(request.getHospitalid() != null)
					nativeQuery = nativeQuery +"    and ah.hosp_id='"+request.getHospitalid()+"'";
			if(request.getDistrictid() != null)
				nativeQuery = nativeQuery + "    and ah.hosp_type ='"+request.getHospitaltypeid()+"'";
		
		nativeQuery = nativeQuery + " ORDER BY\n"
				+ "    hosp_name\n";
				

		Query query = em.createNativeQuery(nativeQuery, SearchHospitalResult.class);


				List<SearchHospitalResult> searchResults = (List<SearchHospitalResult>)query.getResultList();		

		return searchResults;

	}

	
	@SuppressWarnings("unchecked")
	public List<SearchSpecialityResult> advanceSpecialitySearch(AdvanceSpecialitySearch request) {

		String nativeQuery = "SELECT COM.COMPLIANCE_ID appid, COM.MEETING_NAME meetingName, COM.MEETING_TYPE meetingType, COM.MEETING_ID meetingId, DATE_FORMAT(COM.MEETING_DATE,'%d-%m-%Y') meetingDate, DATE_FORMAT(COM.CREATED_ON,'%d-%m-%Y %h:%i %p') createdOn  FROM T_COMPLIANCE_DTLS COM WHERE COM.IS_ACTIVE='Y'";

		if ((request.getProceduretypeid()) != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_TYPE)  like :meetingType ";

		if (request.getProcedurename() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_NAME) like :meetingName ";

		if (request.getSpecialitycode() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_ID) like :meetingId ";

		if (request.getSpecialityid() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_VENUE) like :venue ";
		
		nativeQuery = nativeQuery + " order by COM.COMPLIANCE_NO desc ";

		Query query = em.createNativeQuery(nativeQuery, SearchSpecialityResult.class);


		if ((request.getProceduretypeid()) != null)
			query.setParameter("meetingType", request.getProceduretypeid());

		if (request.getProcedurename() != null)
			query.setParameter("meetingName", "%" + request.getProcedurename().toLowerCase() + "%");

		if (request.getSpecialitycode() != null)
			query.setParameter("meetingId", "%" + request.getSpecialitycode().toLowerCase() + "%");		

		if (request.getSpecialityid() != null)
			query.setParameter("venue", request.getSpecialityid());

		List<SearchSpecialityResult> searchResults = (List<SearchSpecialityResult>)query.getResultList();		

		return searchResults;

	}
	
	@SuppressWarnings("unchecked")
	public List<SearchProcedureResult> advanceProcedureSearch(AdvanceProcedureSearch request) {

		String nativeQuery = "SELECT COM.COMPLIANCE_ID appid, COM.MEETING_NAME meetingName, COM.MEETING_TYPE meetingType, COM.MEETING_ID meetingId, DATE_FORMAT(COM.MEETING_DATE,'%d-%m-%Y') meetingDate, DATE_FORMAT(COM.CREATED_ON,'%d-%m-%Y %h:%i %p') createdOn  FROM T_COMPLIANCE_DTLS COM WHERE COM.IS_ACTIVE='Y'";

		if ((request.getMeetingType()) != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_TYPE)  like :meetingType ";

		if (request.getMeetingName() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_NAME) like :meetingName ";

		if (request.getMeetingId() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_ID) like :meetingId ";

		if (request.getVenue() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_VENUE) like :venue ";

		if ((request.getStartdate()) != null && (request.getStartdate().length() > 0))
			nativeQuery = nativeQuery + " AND COM.CREATED_ON >= TIMESTAMP(:fromDate)";

		if ((request.getEnddate()) != null && (request.getEnddate().length() > 0))
			nativeQuery = nativeQuery + " AND COM.CREATED_ON <= TIMESTAMP(:toDate)";

		nativeQuery = nativeQuery + " order by COM.COMPLIANCE_NO desc ";

		Query query = em.createNativeQuery(nativeQuery, SearchProcedureResult.class);


		if ((request.getMeetingType()) != null)
			query.setParameter("meetingType", "%" + request.getMeetingType().toLowerCase() + "%");

		if (request.getMeetingName() != null)
			query.setParameter("meetingName", "%" + request.getMeetingName().toLowerCase() + "%");

		if (request.getMeetingId() != null)
			query.setParameter("meetingId", "%" + request.getMeetingId().toLowerCase() + "%");		

		if (request.getVenue() != null)
			query.setParameter("venue", "%" + request.getVenue().toLowerCase() + "%");
		
		if ((request.getStartdate()) != null && (request.getStartdate().length() > 0))
			query.setParameter("fromDate", request.getStartdate() + " 00:00:00");

		if ((request.getEnddate()) != null && (request.getEnddate().length() > 0))
			query.setParameter("toDate", request.getEnddate() + " 23:59:59");

		List<SearchProcedureResult> searchResults = (List<SearchProcedureResult>)query.getResultList();		

		return searchResults;

	}

}