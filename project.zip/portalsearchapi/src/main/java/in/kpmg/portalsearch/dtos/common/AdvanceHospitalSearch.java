package in.kpmg.portalsearch.dtos.common;



public class AdvanceHospitalSearch {
    private String districtid;
    private String hospitalid;
    private String hospitaltypeid;
	public String getDistrictid() {
		return districtid;
	}
	public void setDistrictid(String districtid) {
		this.districtid = districtid;
	}
	public String getHospitalid() {
		return hospitalid;
	}
	public void setHospitalid(String hospitalid) {
		this.hospitalid = hospitalid;
	}
	public String getHospitaltypeid() {
		return hospitaltypeid;
	}
	public void setHospitaltypeid(String hospitaltypeid) {
		this.hospitaltypeid = hospitaltypeid;
	}

}