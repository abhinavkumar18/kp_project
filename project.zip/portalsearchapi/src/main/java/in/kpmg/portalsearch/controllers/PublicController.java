package in.kpmg.portalsearch.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.kpmg.portalsearch.dtos.common.AdvanceHospitalSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceProcedureSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.portalsearch.dtos.common.ApiResponse;
import in.kpmg.portalsearch.dtos.common.SearchHospitalResult;
import in.kpmg.portalsearch.dtos.common.SearchProcedureResult;
import in.kpmg.portalsearch.dtos.common.SearchSpecialityResult;
import in.kpmg.portalsearch.services.ErrorService;
import in.kpmg.portalsearch.services.PublicService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/public")
public class PublicController {
    
    @Autowired
    private PublicService pubServ;
    

    @Autowired
    private ErrorService eService;
    
    @GetMapping("/checkconn")
    public ApiResponse<?> checkconn() {
        //userServ.updateAllPassword()
        return new ApiResponse<>(true, "Connection is successfull.",null );
    } 
    
	@PostMapping("/searchhospital")
	public ApiResponse<?> advanceHospitalSearch(@RequestBody AdvanceHospitalSearch request) {

		try {

			List<SearchHospitalResult> results = pubServ.advanceHospitalSearch(request);
			if (results.size() > 0) {
				return new ApiResponse<>(true, "Search Results found.", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	
	@PostMapping("/searchprocedure")
	public ApiResponse<?> advanceProcedureSearch(@RequestBody AdvanceProcedureSearch request) {

		try {

			List<SearchProcedureResult> results = pubServ.advanceProcedureSearch(request);
			if (results.size() > 0) {
				return new ApiResponse<>(true, "Search Results found.", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	
	@PostMapping("/searchspeciality")
	public ApiResponse<?> advanceSpecialitySearch(@RequestBody AdvanceSpecialitySearch request) {

		try {

			List<SearchSpecialityResult> results = pubServ.advanceSpecialitySearch(request);
			if (results.size() > 0) {
				return new ApiResponse<>(true, "Search Results found.", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}

    
}
