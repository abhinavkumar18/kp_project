package in.kpmg.portalsearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class SbmBiharApplication {

	// @PostConstruct
	// void started() {
	//   TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
	//   System.out.println("Spring boot application running in UTC timezone :"+new Date());
	// }
	public static void main(String[] args) {
		SpringApplication.run(SbmBiharApplication.class, args);
	}

}
