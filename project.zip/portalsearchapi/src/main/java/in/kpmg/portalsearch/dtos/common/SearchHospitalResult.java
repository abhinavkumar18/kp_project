package in.kpmg.portalsearch.dtos.common;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class SearchHospitalResult {
	@Id
	private BigInteger appid;
	private String hospitalName;
	private String hospitalType;
	private String hospitalAddress;
	private String districtName;
	private String mandalName;
	private String specialities;
	private String empanalledDate;
	private String medcoName;
	private String medcoContactNo;
	private String mitraName;
	private String mitraContactNo;

	public SearchHospitalResult() {
	}

}