package in.kpmg.ehs.portalsearch.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
/*import java.util.ArrayList;*/
import org.springframework.web.bind.annotation.RequestBody;

import in.kpmg.ehs.portalsearch.dtos.common.AdvanceCountSpecialitySearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceDistrictCount;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceHospitalSearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceMitraDistrict;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceMitraDistrictCount;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceProcedureSearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceSpecialitySearchHospital;
import in.kpmg.ehs.portalsearch.dtos.common.CountSearchSpecialityResult;
import in.kpmg.ehs.portalsearch.dtos.common.DisplayResult;
import in.kpmg.ehs.portalsearch.dtos.common.DistrictCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictWiseCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraSearchResult;
//import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchHospitalResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchProcedureResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchSpecialityResult;
import in.kpmg.ehs.portalsearch.dtos.common.SpecialitySearchHospitalResult;
import in.kpmg.ehs.portalsearch.dtos.common.StateCountResult;

@Service
public class PublicService {

	@PersistenceContext
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public List<SearchHospitalResult> advanceHospitalSearch(AdvanceHospitalSearch request) {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    es.hosp_name hospitalName,\n"
				+ "    es.hosp_type hospitalType,\n"
				+ "    el.loc_name AS districtName,\n"
				+ "	   replace(es.HOUSE_NO\n"
				+ "    ||','\n"
				+ "    || es.STREET,',','<br/>') hospitalAddress,\n"
				+ "    replace(specialities,',','<br/>') specialities,\n"
				+ "    replace(name_of_medco,',','<br/>') medcoName,\n"
				+ "    replace(medco_contact_number,',','<br/>') medcoContactNo,\n"
				+ "    replace(name_of_mitra,',','<br/>') mitraName,\n"
				+ "    replace(mitra_contact_number,',','<br/>') mitraContactNo\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "            || ' '\n"
				+ "            || eu.middle_name\n"
				+ "            || ' '\n"
				+ "            || eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                || ' '\n"
				+ "                || eu.middle_name\n"
				+ "                || ' '\n"
				+ "                || eu.last_name\n"
				+ "            ) AS name_of_mitra,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS mitra_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.mithra_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN ('G','C')\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) ehmd,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "            || ' '\n"
				+ "            || eu.middle_name\n"
				+ "            || ' '\n"
				+ "            || eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                || ' '\n"
				+ "                || eu.middle_name\n"
				+ "                || ' '\n"
				+ "                || eu.last_name\n"
				+ "            ) AS name_of_medco,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS medco_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_medco_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.medco_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN ('G','C')\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) emd,\n"
				+ "    (SELECT HOSP_ID,LISTAGG(ess.DIS_MAIN_NAME,',') WITHIN GROUP(ORDER BY ess.DIS_MAIN_NAME) AS specialities FROM ehfm_hosp_speciality ehs,\n"
				+ "    EHFM_SPECIALITIES ESS\n"
				+ "    WHERE is_active_flg = 'Y' AND phase_id = '1' AND renewal = '1' \n"
				+ "    AND scheme_id = 'CD201' \n"
				+ "    AND ESS.DIS_MAIN_ID=ehs.icd_cat_code\n"
				+ "    AND ess.DIS_ACTIVE_YN='Y'\n"
				+ "    --AND ICD_CAT_CODE='S8'\n"
				+ "    GROUP BY HOSP_ID\n"
				+ "    ) ehs\n"
				+ "WHERE\n"
				+ "          es.hosp_dist = el.loc_id\n"
				+ "    AND   es.hosp_active_yn = 'Y'\n"
				+ "    AND   es.scheme = 'CD201'\n"
				+ "    AND   loc_hdr_id = 'LH6'\n"
				+ "    AND   es.hosp_type IN ('G','C')\n"
				+ "    and   ehs.hosp_id=es.hosp_id\n"
				+ "    AND   es.hosp_id = ehmd.hosp_id (+)\n"
				+ "    AND   es.hosp_id = emd.hosp_id (+)";
				if(request.getDistrictid() != null)
				nativeQuery = nativeQuery + " AND el.loc_id='"+request.getDistrictid()+"'";
				

		Query query = em.createNativeQuery(nativeQuery, SearchHospitalResult.class);

		List<SearchHospitalResult> searchResults = query.getResultList();
					
				
		return searchResults;
	}

//	
	@SuppressWarnings("unchecked")
	public List<SearchSpecialityResult> advanceSpecialitySearch() {

		String nativeQuery = "SELECT DISTINCT\n"
				+ "    c.dis_main_id AS specialit_code,\n"
				+ "    c.dis_main_name AS speciality ,\n"
				+ "    a.icd_proc_code AS procedure_code,\n"
				+ "    a.proc_name AS procedure_name,\n"
				+ "    a.hosp_stay_amt + a.common_cat_amt + a.icd_amt AS packageEhs,\n"
				+ "    invest_name investDesc\n"
				+ "\n"
				+ "FROM\n"
				+ "    ehfm_main_therapy a,\n"
				+ "    ehfm_specialities c,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            eti.icd_proc_code,LISTAGG(invest_desc,',') within group (order by invest_desc) as invest_name\n"
				+ "        FROM\n"
				+ "            ehfm_therapy_invest eti\n"
				+ "        WHERE\n"
				+ "            active_yn = 'Y'\n"
				+ "            AND   scheme_id = 'CD201'\n"
				+ "            group by eti.icd_proc_code\n"
				+ "    ) eti\n"
				+ "WHERE\n"
				+ "          a.active_yn = 'Y'\n"
				+ "    AND   a.state = 'CD201'\n"
				+ "    --AND   a.asri_code = 'S4'\n"
				+ "    AND   c.dis_main_id = a.asri_code\n"
				+ "    AND   c.dis_active_yn = 'Y'\n"
				+ "    AND   a.icd_cat_code = eti.icd_proc_code(+)\n"
				+ "	   ORDER BY speciality";

		Query query = em.createNativeQuery(nativeQuery, SearchSpecialityResult.class);


		List<SearchSpecialityResult> searchResults = query.getResultList();		

		return searchResults;

	}
//	
	@SuppressWarnings("unchecked")
	public List<SearchProcedureResult> advanceProcedureSearch() {

		String nativeQuery ="SELECT distinct\n"
				+ " c.dis_main_name AS specialityName,\n"
				+ " c.dis_main_id AS specialityCode,\n"
				+ " b.icd_cat_code AS dissubId,\n"
				+ " b.icd_cat_name AS dissubName,\n"
				+ " a.icd_proc_code AS procedureType,\n"
				+ " a.proc_name AS procedureName,\n"
				+ " a.hosp_stay_amt + a.common_cat_amt + a.icd_amt AS packageAmount\n"
				//+ " INVESTIGATION_ID preInvestigations\n"
				//+ " INVEST_DESC \n"
				+ "FROM\n"
				+ " ehfm_main_therapy a,\n"
				+ " ehfm_main_category b,\n"
				+ " ehfm_specialities c,\n"
				+ " (select * from EHFM_THERAPY_INVEST where ACTIVE_YN='Y' and SCHEME_ID='CD201')eti\n"
				+ "WHERE\n"
				+ " a.state = 'CD201'\n"
				+ " AND a.active_yn = 'Y'\n"
				+ " AND a.process IN ('IP','DOP')\n"
				+ " AND a.icd_cat_code = b.icd_cat_code\n"
				+ " AND b.active_yn = 'Y'\n"
				+ " AND a.asri_code = b.asri_cat_code\n"
				+ " AND a.hosp_stay_amt IS NOT NULL\n"
				+ " AND c.dis_main_id = a.asri_code\n"
				+ " AND c.dis_active_yn = 'Y'\n"
				+ " and a.ICD_CAT_CODE=eti.ICD_PROC_CODE(+)";


		Query query = em.createNativeQuery(nativeQuery, SearchProcedureResult.class);

		List<SearchProcedureResult> searchResults = query.getResultList();		

		return searchResults;

	}
	@SuppressWarnings("unchecked")
	public List<StateCountResult> advanceStateCount() {
		
		String nativeQuery ="SELECT DISTINCT\n"
				+ "    --el.loc_name AS District,\n"
				+ "    els.LOC_ID AS stateid ,\n"
				+ "    els.LOC_NAME AS State,\n"
				+ "    --el.loc_id as District_id,\n"
				+ "    COUNT(DISTINCT ehs.hosp_id) AS Govt ,\n"
				+ "    COUNT(DISTINCT ehss.hosp_id) AS Pvt \n"
				+ "FROM\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='G')ehs,\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='C')ehss,\n"
				+ "     (select * from ehfm_locations where loc_hdr_id='LH1') ELS,\n"
				+ "    (select * from ehfm_locations where loc_hdr_id = 'LH6')el   \n"
				+ "WHERE\n"
				+ "    ehs.HOSP_DIST = el.loc_id\n"
				+ "    and ehss.HOSP_DIST=el.loc_id\n"
				+ "    and ELS.LOC_ID=el.LOC_PARNT_ID\n"
				+ "    --AND els.LOC_ID='S35'\n"
				+ "    GROUP BY els.LOC_ID,els.LOC_NAME";
		
		Query query = em.createNativeQuery(nativeQuery, StateCountResult.class);
		List<StateCountResult> searchResults = query.getResultList();
		return searchResults;
	}
	//done
	@SuppressWarnings("unchecked")
	public List<DistrictCountResult> advanceDistrictCount(AdvanceDistrictCount request) {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    el.loc_name AS District,\n"
				+ "    el.loc_id AS District_id,\n"
				+ "    COUNT(DISTINCT ehs.hosp_id) AS Govt,\n"
				+ "    COUNT(DISTINCT ehss.hosp_id) AS Private\n"
				+ "FROM\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='G')ehs,\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='C')ehss,\n"
				+ "    (select * from ehfm_locations where loc_hdr_id='LH1') ELS ,\n"
				+ "    (select * from ehfm_locations where loc_hdr_id = 'LH6')el\n"
				+ "WHERE\n"
				+ "    ehs.HOSP_DIST = el.loc_id\n"
				+ "    and ehss.HOSP_DIST=el.loc_id\n"
				+ "    and ELS.LOC_ID=el.LOC_PARNT_ID\n";
				if(request.getStateVal()!=null) {
				 nativeQuery=nativeQuery + " and els.LOC_ID='"+request.getStateVal()+"' \n"
				+"GROUP BY el.loc_name,el.loc_id ";		 }
				else {
					nativeQuery=nativeQuery+" GROUP BY el.loc_name,el.loc_id ";
				}
		Query query = em.createNativeQuery(nativeQuery, DistrictCountResult.class);

		List<DistrictCountResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	//done
	@SuppressWarnings("unchecked")
	public List<MitraSearchResult> advanceMitraSearch() {

		String nativeQuery = "SELECT distinct\n"
				+ "    el.loc_ID AS locstateVal,\n"
				+ "    el.loc_name AS state,\n"
				+ "    COUNT(USER_ID) AS mitraCount\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            DISTINCT HOSP_ID,USER_ID\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,EHFM_USERS EU\n"
				+ "        WHERE\n"
				+ "                ehmd.end_dt IS NULL\n"
				+ "            AND ehmd.scheme = 'CD201'\n"
				+ "            AND eu.SERVICE_FLG='Y'\n"
				+ "            AND eu.USER_TYPE='CD201'\n"
				+ "            AND ehmd.MITHRA_ID=EU.USER_ID\n"
				+ "    ) ehmd\n"
				+ "WHERE\n"
				+ "          es.state_code = el.loc_id\n"
				+ "    AND   el.loc_hdr_id = 'LH1'\n"
				+ "    AND   es.hosp_active_yn = 'Y'\n"
				+ "    AND   ES.scheme = 'CD201'\n"
				+ "    AND   es.HOSP_ID=EHMD.HOSP_ID\n"
				+ "    --and   es.STATE_CODE='S35'\n"
				+ "    GROUP BY el.loc_name,el.loc_ID";
		Query query = em.createNativeQuery(nativeQuery, MitraSearchResult.class);
		List<MitraSearchResult> searchResults = query.getResultList();
		return searchResults;
	}
	
	@SuppressWarnings("unchecked")
	public List<MitraDistrictWiseCountResult> advanceMitraDistrictWiseCount(AdvanceMitraDistrictCount request) {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    el.loc_id districtId,\n"
				+ "    loc_name district,\n"
				+ "    count(ehmd.mithra_id) as mitraCount\n"
				+ "FROM\n"
				+ "    ehfm_hosp_mithra_dtls ehmd,\n"
				+ "    ehfm_users eu,\n"
				+ "    ehfm_hospitals eh,\n"
				+ "    ehfm_locations el\n"
				+ "WHERE\n"
				+ "    ehmd.end_dt IS NULL\n"
				+ "    AND   ehmd.scheme = 'CD201'\n"
				+ "    AND   service_flg = 'Y'\n"
				+ "    AND   user_type = 'CD201'\n"
				+ "    AND   ehmd.mithra_id = eu.user_id\n"
				+ "    AND   ehmd.hosp_id = eh.hosp_id\n"
				+ "    AND   eh.hosp_active_yn = 'Y'\n"
				+ "    AND   eh.scheme = 'CD201'\n";
		if(request.getStateid()!=null) {
				nativeQuery=nativeQuery+" AND eh.state_code='"+request.getStateid()+"'";
		}
		nativeQuery = nativeQuery+"AND   eh.hosp_dist = el.loc_id\n"
				+ "    group by  el.loc_id,loc_name ";
		
		
		Query query = em.createNativeQuery(nativeQuery, MitraDistrictWiseCountResult.class);

		List<MitraDistrictWiseCountResult> searchResults = query.getResultList();
				
		return searchResults;
				

	}
	
	@SuppressWarnings("unchecked")
	public List<MitraDistrictResult> advanceMitraDistrictCount() {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    replace(eu.first_name\n"
				+ "    || ' '\n"
				+ "    || eu.middle_name\n"
				+ "    || ' '\n"
				+ "    || eu.last_name,',','<br/>') AS mitraName,\n"
				+ "    replace(eu.mobile_no,',','<br/>') AS mitraContact,\n"
				+ "    es.loc_name AS district,\n"
				+ "    es.hosp_id hospitalId,\n"
				+ "    esu.hosp_name hospitalName,\n"
				+ "    replace(esu.specialities,',','<br/>') Speciality\n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            *\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,\n"
				+ "            ehfm_users eu\n"
				+ "        WHERE\n"
				+ "            end_dt IS NULL\n"
				+ "            AND   scheme = 'CD201'\n"
				+ "            AND   service_flg = 'Y'\n"
				+ "            AND   user_type = 'CD201'\n"
				+ "            AND   ehmd.mithra_id = eu.user_id\n"
				+ "    ) eu,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            *\n"
				+ "        FROM\n"
				+ "            ehfm_hospitals es,\n"
				+ "            ehfm_locations el\n"
				+ "        WHERE\n"
				+ "            es.hosp_dist = el.loc_id\n"
				+ "            AND   es.hosp_active_yn = 'Y'\n"
				+ "            AND   es.scheme = 'CD201'\n"
				+ "            AND   loc_hdr_id = 'LH6'\n"
				+ "    ) es,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            es.hosp_id,\n"
				+ "            es.hosp_name,\n"
				+ "            LISTAGG(ehs.icd_cat_code,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                ehs.icd_cat_code\n"
				+ "            ) AS specialities\n"
				+ "        FROM\n"
				+ "            ehfm_hospitals es,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    *\n"
				+ "                FROM\n"
				+ "                    ehfm_hosp_speciality\n"
				+ "                WHERE\n"
				+ "                    is_active_flg = 'Y'\n"
				+ "                    AND   phase_id = '1'\n"
				+ "                    AND   renewal = '1'\n"
				+ "                    AND   scheme_id = 'CD201'\n"
				+ "            ) ehs\n"
				+ "        WHERE\n"
				+ "            es.hosp_active_yn = 'Y'\n"
				+ "            AND   es.scheme = 'CD201'\n"
				+ "            AND   es.hosp_id = ehs.hosp_id (+)\n"
				+ "        GROUP BY\n"
				+ "            es.hosp_id,es.hosp_name\n"
				+ "    ) esu\n"
				+ "WHERE\n"
				+ "    es.hosp_id = eu.hosp_id\n"
				+ "    AND   es.hosp_id = esu.hosp_id";
		
		Query query = em.createNativeQuery(nativeQuery, MitraDistrictResult.class);

		List<MitraDistrictResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	//done
	@SuppressWarnings("unchecked")
	public List<CountSearchSpecialityResult> advanceCountSpecialitySearch(AdvanceCountSpecialitySearch request) {

		String nativeQuery = "SELECT\n"
				+ "    DISTINCT\n"
				+ "    upper(b.dis_main_name|| ' ( '|| b.dis_main_id|| ' )') speciality,\n"
				+ "    SUM(a.procedures_count) proceduresCount,\n"
				+ "    SUM(b.hospitals_count) hospitalsCount\n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            asri_code,\n"
				+ "            COUNT(DISTINCT icd_proc_code) AS procedures_count\n"
				+ "        FROM\n"
				+ "            ehfm_main_therapy\n"
				+ "        WHERE\n"
				+ "            active_yn = 'Y'\n"
				+ "            AND   state = 'CD201'\n"
				+ "        GROUP BY\n"
				+ "            asri_code\n"
				+ "    ) a,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            dis_main_id,\n"
				+ "            dis_main_name,\n"
				+ "            COUNT(DISTINCT ehs.hosp_id) AS hospitals_count\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_speciality ehs,\n"
				+ "            ehfm_specialities es,\n"
				+ "            ehfm_hospitals eh\n"
				+ "        WHERE\n"
				+ "            is_active_flg = 'Y'\n"
				+ "            AND scheme_id = 'CD201'";
			 if(request.getSpecialityId()!=null) {
				 nativeQuery=nativeQuery+" AND es.dis_main_id='"+request.getSpecialityId()+"'";
				 }
				nativeQuery=nativeQuery + "AND ehs.icd_cat_code = es.dis_main_id\n"
						+"and eh.hosp_id=ehs.hosp_id\n"
						+ "            and eh.HOSP_ACTIVE_YN='Y'\n"
						+ "            AND eh.SCHEME='CD201'\n"
						+ "            AND eh.hosp_type IN ('G','C')\n"
						+ "        GROUP BY\n"
						+ "            dis_main_id,\n"
						+ "            dis_main_name\n"
						+ "    ) b\n"
						+ "WHERE\n"
						+ "    a.asri_code = b.dis_main_id\n"
						+ "    group by upper(b.dis_main_name|| ' ( '|| b.dis_main_id|| ' )')";

		Query query = em.createNativeQuery(nativeQuery, CountSearchSpecialityResult.class);


		List<CountSearchSpecialityResult> searchResults = query.getResultList();		

		return searchResults;

	}
	@SuppressWarnings("unchecked")
	public List<SpecialitySearchHospitalResult> advanceSpecialitySearchHospital(@RequestBody AdvanceSpecialitySearchHospital request){
		
		
		String nativeQuery="select * from (SELECT DISTINCT\n"
				+ "    es.hosp_name hospitalName,\n"
				+ "    es.hosp_type hospitalType,\n"
				+ "    el.LOC_NAME AS district,\n"
				+ "    (SELECT LISTAGG(ehs.icd_cat_code,',') WITHIN GROUP(ORDER BY ehs.icd_cat_code) AS specialities FROM ehfm_hosp_speciality ehs WHERE is_active_flg = 'Y' AND phase_id = '1' AND renewal = '1'\n"
				+ "    AND scheme_id = 'CD201' and ehs.hosp_id=es.hosp_id) as specialities,\n"
				+ "    es.CRT_DT as hospitalEmpDate,\n"
				+ "    emd.FIRST_NAME||' '||emd.MIDDLE_NAME||' '||emd.LAST_NAME as medcoName,\n"
				+ "    emd.MOBILE_NO as medcoContact,\n"
				+ "    ehmd.FIRST_NAME||' '||ehmd.MIDDLE_NAME||' '||ehmd.LAST_NAME as mitraName,\n"
				+ "    ehmd.MOBILE_NO as mitraContact\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT * FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,EHFM_USERS EU\n"
				+ "        WHERE\n"
				+ "            end_dt IS NULL\n"
				+ "            AND scheme = 'CD201'\n"
				+ "            AND SERVICE_FLG='Y'\n"
				+ "            AND EU.USER_TYPE='CD201'\n"
				+ "            AND ehmd.MITHRA_ID=EU.USER_ID\n"
				+ "    ) ehmd,\n"
				+ "    (\n"
				+ "        SELECT * FROM\n"
				+ "            EHFM_MEDCO_DTLS ehmd,EHFM_USERS EU\n"
				+ "        WHERE\n"
				+ "            end_dt IS NULL\n"
				+ "            AND scheme = 'CD201'\n"
				+ "            AND SERVICE_FLG='Y'\n"
				+ "            AND EU.USER_TYPE='CD201'\n"
				+ "            AND ehmd.MEDCO_ID=EU.USER_ID\n"
				+ "    ) emd\n"
				+ "WHERE\n"
				+ "          es.HOSP_DIST = el.loc_id\n"
				+ "    AND   loc_hdr_id = 'LH6'\n"
				+ "    AND   hosp_active_yn = 'Y'\n"
				+ "    AND   ES.scheme = 'CD201'\n"
				+ "    AND   es.HOSP_ID(+)=EHMD.HOSP_ID\n"
				+ "    and   es.HOSP_ID(+)=emd.hosp_id)";
		
		if(request.getSpecialityId()!=null&&request.getHospitalType()!=null) {
			nativeQuery=nativeQuery +"where specialities like '%"+ request.getSpecialityId()+",%' and hospitalType = '"+request.getHospitalType()+"'";
		}
		else if(request.getSpecialityId()==null&&request.getHospitalType()!=null)
		{
			nativeQuery=nativeQuery +"where hospitalType = '"+request.getHospitalType()+"'";
		}
		else if(request.getSpecialityId()!=null&&request.getHospitalType()==null)
		{
			nativeQuery=nativeQuery +"where specialities like '%"+ request.getSpecialityId()+",%'";
		}
		
		
		Query query = em.createNativeQuery(nativeQuery, SpecialitySearchHospitalResult.class);


		List<SpecialitySearchHospitalResult> searchResults = query.getResultList();		

		return searchResults;

	
	
}
}