package in.kpmg.ehs.portalsearch.dtos.common;

public class AdvanceCountSpecialitySearch {
	private String specialityId;

	public String getSpecialityId() {
		return specialityId;
	}

	public void setSpecialityId(String specialityId) {
		this.specialityId = specialityId;
	}


}
