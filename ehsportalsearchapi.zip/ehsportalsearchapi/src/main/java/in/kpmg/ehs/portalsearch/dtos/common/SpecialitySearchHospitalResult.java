package in.kpmg.ehs.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class SpecialitySearchHospitalResult {
	
	@Id
	private String hospitalName;
	private String hospitalType;
	private String district;
	private String specialities;
	private String hospitalEmpDate;
	private String medcoName;
	private String medcoContact;
	private String mitraName;
	private String mitraContact;
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getHospitalType() {
		return hospitalType;
	}
	public void setHospitalType(String hospitalType) {
		this.hospitalType = hospitalType;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getSpecialities() {
		return specialities;
	}
	public void setSpecialities(String specialities) {
		this.specialities = specialities;
	}
	public String getHospitalEmpDate() {
		return hospitalEmpDate;
	}
	public void setHospitalEmpDate(String hospitalEmpDate) {
		this.hospitalEmpDate = hospitalEmpDate;
	}
	public String getMedcoName() {
		return medcoName;
	}
	public void setMedcoName(String medcoName) {
		this.medcoName = medcoName;
	}
	public String getMedcoContact() {
		return medcoContact;
	}
	public void setMedcoContact(String medcoContact) {
		this.medcoContact = medcoContact;
	}
	public String getMitraName() {
		return mitraName;
	}
	public void setMitraName(String mitraName) {
		this.mitraName = mitraName;
	}
	public String getMitraContact() {
		return mitraContact;
	}
	public void setMitraContact(String mitraContact) {
		this.mitraContact = mitraContact;
	}

}
