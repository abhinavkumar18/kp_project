package in.kpmg.ehs.portalsearch.dtos.common;

import org.json.JSONArray;

public class ApiResponse<T> {
    private Boolean status;
    private String message;
    private String result;
    private Integer statusCode;

    public ApiResponse(Boolean status, String message, String result) {
        this.status = status;
        this.message = message;
        this.result = result;
    }


    public ApiResponse(String ticketString) {
        this.statusCode = 500;
        this.status = false;
        this.message = "Error Occured during processing Request$" + ticketString;
    }

    public ApiResponse(Boolean status, String message) {
        this.status = status;
        this.message = message;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


	public String getResult() {
		return result;
	}


	public void setResult(String result) {
		this.result = result;
	}


}
