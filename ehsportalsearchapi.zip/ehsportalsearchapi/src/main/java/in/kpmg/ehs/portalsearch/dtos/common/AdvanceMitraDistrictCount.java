package in.kpmg.ehs.portalsearch.dtos.common;

public class AdvanceMitraDistrictCount {
	private String stateid;

	public String getStateid() {
		return stateid;
	}

	public void setStateid(String stateid) {
		this.stateid = stateid;
	}
}
