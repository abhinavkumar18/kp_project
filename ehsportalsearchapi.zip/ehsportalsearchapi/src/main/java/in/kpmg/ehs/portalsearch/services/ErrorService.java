package in.kpmg.ehs.portalsearch.services;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.kpmg.ehs.portalsearch.models.common.ErrorDetails;
import in.kpmg.ehs.portalsearch.repositories.common.ErrorRepository;

@Service
public class ErrorService {

    @Autowired
    private ErrorRepository errorRepo;

    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");

    @Transactional
    public String reportError(Exception ex){
        ErrorDetails error = new ErrorDetails();
        StringWriter sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        error.setErrorDetails(sw.toString());
     //   error.setUserId(uService.getSessionUser().getUserId());
        error = errorRepo.save(error);
        LocalDateTime now = LocalDateTime.now();
        error.setTicketId("TKT" + dtf.format(now)  + error.getId());
        error = errorRepo.save(error);
        return error.getTicketId();
    }

    public String reportSchedularError(Exception ex){
        ErrorDetails error = new ErrorDetails();
        StringWriter sw = new StringWriter();
        ex.printStackTrace(new PrintWriter(sw));
        error.setErrorDetails(sw.toString());
        error.setUserId(1);
        error = errorRepo.save(error);
        error.setTicketId("TKT20200801" + error.getId());
        //System.out.println("Schedular Ticket Error : " + error.getTicketId());
        error = errorRepo.save(error);
        return error.getTicketId();
    }
}