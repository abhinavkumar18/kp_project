package in.kpmg.ehs.portalsearch.dtos.common;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class SearchSpecialityResult {
	@Id
	private String speciality;
	private String specialit_code;
	//private String sub_category_code;
	//private String sub_category_name;
	private String procedure_code;
	private String procedure_name;
	//private int duration_of_stay;
	private String packageEhs;
	//private String investigationId;
	private String investDesc;
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	public String getSpecialit_code() {
		return specialit_code;
	}
	public void setSpecialit_code(String specialit_code) {
		this.specialit_code = specialit_code;
	}
	/*public String getSub_category_code() {
		return sub_category_code;
	}
	public void setSub_category_code(String sub_category_code) {
		this.sub_category_code = sub_category_code;
	}
	public String getSub_category_name() {
		return sub_category_name;
	}
	public void setSub_category_name(String sub_category_name) {
		this.sub_category_name = sub_category_name;
	}*/
	public String getProcedure_code() {
		return procedure_code;
	}
	public void setProcedure_code(String procedure_code) {
		this.procedure_code = procedure_code;
	}
	public String getProcedure_name() {
		return procedure_name;
	}
	public void setProcedure_name(String procedure_name) {
		this.procedure_name = procedure_name;
	}
	/*public int getDuration_of_stay() {
		return duration_of_stay;
	}
	public void setDuration_of_stay(int duration_of_stay) {
		this.duration_of_stay = duration_of_stay;
	}*/
	public String getPackageEhs() {
		return packageEhs;
	}
	public void setPackageEhs(String packageEhs) {
		this.packageEhs = packageEhs;
	}
	/*public String getInvestigationId() {
		return investigationId;
	}
	public void setInvestigationId(String investigationId) {
		this.investigationId = investigationId;
	}*/
	public String getInvestDesc() {
		return investDesc;
	}
	public void setInvestDesc(String investDesc) {
		this.investDesc = investDesc;
	}
	
}