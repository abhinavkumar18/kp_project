package in.kpmg.ehs.portalsearch.dtos.common;




public class AdvanceSpecialitySearch {
    private String specialityid;
    private String hospitalid;
	private String specialitycode;
    private String procedurename;
    private Long proceduretypeid;
    
    public String getHospitalid() {
		return hospitalid;
	}
	public void setHospitalid(String hospitalid) {
		this.hospitalid = hospitalid;
	}
	public String getSpecialityid() {
		return specialityid;
	}
	public void setSpecialityid(String specialityid) {
		this.specialityid = specialityid;
	}
	public String getSpecialitycode() {
		return specialitycode;
	}
	public void setSpecialitycode(String specialitycode) {
		this.specialitycode = specialitycode;
	}
	public String getProcedurename() {
		return procedurename;
	}
	public void setProcedurename(String procedurename) {
		this.procedurename = procedurename;
	}
	public Long getProceduretypeid() {
		return proceduretypeid;
	}
	public void setProceduretypeid(Long proceduretypeid) {
		this.proceduretypeid = proceduretypeid;
	}

   
   
}