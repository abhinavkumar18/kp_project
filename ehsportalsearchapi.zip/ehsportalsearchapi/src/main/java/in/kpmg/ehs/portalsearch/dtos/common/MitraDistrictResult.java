package in.kpmg.ehs.portalsearch.dtos.common;
import javax.persistence.Entity;
import javax.persistence.Id;

	@Entity
public class MitraDistrictResult {
		@Id
		private String mitraName;
		public String getMitraName() {
			String str="<div style=\"max-height: 70px;overflow-y: scroll;width:auto;\"> ";
			String str1=" </div>";
			return str+mitraName+str1;
		}
		public void setMitraName(String mitraName) {
			this.mitraName = mitraName;
		}
		public String getDistrict() {
			return district;
		}
		public void setDistrict(String district) {
			this.district = district;
		}
		public String getHospitalName() {
			return hospitalName;
		}
		public void setHospitalName(String hospitalName) {
			this.hospitalName = hospitalName;
		}
		public String getSpeciality() {
			String str="<div style=\"max-height: 70px;overflow-y: scroll;width:auto;\"> ";
			String str1=" </div>";
			return str+Speciality+str1;
		}
		public void setSpeciality(String speciality) {
			Speciality = speciality;
		}
		private String mitraContact;
		public String getMitraContact() {
			String str="<div style=\"max-height: 70px;overflow-y: scroll;width:auto;\"> ";
			String str1=" </div>";
			return str+mitraContact+str1;
		}
		public void setMitraContact(String mitraContact) {
			this.mitraContact = mitraContact;
		}
		private String district;
		private String hospitalName;
		private String Speciality;
		private String hospitalId;
//		private String districtid;
//		public String getDistrictid() {
//			return districtid;
//		}
//		public void setDistrictid(String districtid) {
//			this.districtid = districtid;
//		}
//		public MitraDistrictResult() {
//			
//		}
		public String getHospitalId() {
			return hospitalId;
		}
		public void setHospitalId(String hospitalId) {
			this.hospitalId = hospitalId;
		}
}
