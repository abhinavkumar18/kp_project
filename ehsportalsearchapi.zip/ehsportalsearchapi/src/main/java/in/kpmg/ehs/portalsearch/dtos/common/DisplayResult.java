package in.kpmg.ehs.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class DisplayResult {
	@Id
	private Long Micr;
	private String City;
	private String branchName;
	private String bankName;
	public Long getMicr() {
		return Micr;
	}
	public void setMicr(Long micr) {
		Micr = micr;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
}
