package in.kpmg.ehs.portalsearch.dtos.common;


public class AdvanceSpecialitySearchHospital {
	private String specialityId;
	private String hospitalType;
	public String getSpecialityId() {
		return specialityId;
	}
	public void setSpecialityId(String specialityId) {
		this.specialityId = specialityId;
	}
	public String getHospitalType() {
		return hospitalType;
	}
	public void setHospitalType(String hospitalType) {
		this.hospitalType = hospitalType;
	}
}
