package in.kpmg.ehs.portalsearch.dtos.common;

public class AdvanceProcedureSearch {
    private String surgeryid;

	public String getSurgeryid() {
		return surgeryid;
	}

	public void setSurgeryid(String surgeryid) {
		this.surgeryid = surgeryid;
	}

	

}
