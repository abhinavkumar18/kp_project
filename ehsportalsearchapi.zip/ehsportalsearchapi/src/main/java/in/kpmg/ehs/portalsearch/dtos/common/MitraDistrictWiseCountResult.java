package in.kpmg.ehs.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MitraDistrictWiseCountResult {

	@Id
	private String districtId;
	//private String state;
	private String district;
	private int mitraCount;
	
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDistrictId() {
		return districtId;
	}
	public void setDistrictId(String districtId) {
		this.districtId = districtId;
	}
	public int getMitraCount() {
		return mitraCount;
	}
	public void setMitraCount(int mitraCount) {
		this.mitraCount = mitraCount;
	}
	public MitraDistrictWiseCountResult() {
		
	}

}
