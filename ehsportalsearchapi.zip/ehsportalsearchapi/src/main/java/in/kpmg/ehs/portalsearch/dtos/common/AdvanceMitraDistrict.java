package in.kpmg.ehs.portalsearch.dtos.common;

public class AdvanceMitraDistrict {
	private String districtid;

	public String getDistrictid() {
		return districtid;
	}

	public void setDistrictid(String districtid) {
		this.districtid = districtid;
	}
}
