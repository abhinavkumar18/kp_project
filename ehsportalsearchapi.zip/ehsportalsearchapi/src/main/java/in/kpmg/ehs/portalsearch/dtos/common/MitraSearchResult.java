package in.kpmg.ehs.portalsearch.dtos.common;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MitraSearchResult {
	@Id
	private String locstateVal;
	private Long mitraCount;
	private String state;
	
	public String getLocstateVal() {
		return locstateVal;
	}
	public void setLocstateVal(String locstateVal) {
		this.locstateVal = locstateVal;
	}
	public Long getMitraCount() {
		return mitraCount;
	}
	public void setMitraCount(Long mitraCount) {
		this.mitraCount = mitraCount;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
}
