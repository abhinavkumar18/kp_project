import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";
export const STATUSES = Object.freeze({
  IDLE: "idle",
  ERROR: "error",
  LOADING: "loading",
  SUCCESS: "success",
});

const userSlice = createSlice({
  name: "user",
  initialState: {
    data: [],
    status: STATUSES.IDLE,
  },
  reducers: {
    logout: (state, action) => {
      state.data = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchUsers.pending, (state, action) => {
        state.status = STATUSES.LOADING;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.data = action.payload;
        state.status = STATUSES.SUCCESS;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.status = STATUSES.ERROR;
      });
  },
});
export const { setUsers, setStatus, logout } = userSlice.actions;
// Thunks
export const fetchUsers = createAsyncThunk("users/fetch", async (body) => {
  const res = await axios.post(
    `${process.env.REACT_APP_USER_MANAGEMENT_API}/user/authenticate`,
    body
  );
  return res;
});
export default userSlice.reducer;
