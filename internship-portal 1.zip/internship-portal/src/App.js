import React, { Suspense, lazy } from "react";
import { Route, Routes } from "react-router-dom";
import ScrollToTop from "./components/ScrollToTop";
import "./index.css";
import Header from "./layouts/Header";

/*****Pages******/
const Login = lazy(() => import("./pages/auth/Login"));
const Home = lazy(() => import("./pages/Home"));
//
const InternshipOpportunities=lazy(()=>import("./pages/student-screens/InternshipOpportunities"));
const ApplyInternship= lazy(()=>import("./pages/student-screens/ApplyInternship"));

const App = () => {
  return <AppRoutes />;
};

const AppRoutes = () => {
  return (
    <Suspense fallback={<div />}>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Login />} exact />
        {/* <Route path="/" element={<Home />} /> */}
        <Route element={<Header />}>
          <Route path="/home" element={<Home />} />
          <Route path="/internship-opportunities" element={<InternshipOpportunities />} />
          <Route path="/apply-for-internship" element={<ApplyInternship />} />
          {/* <Route path="/" element={< />} />
          <Route path="/" element={< />} /> */}
        </Route>
      </Routes>
    </Suspense>
  );
};
// function RequireAuth({ children }) {
//   const user = useSelector((state) => state.user);
//   return user.data.length !== 0 ? children : <Navigate to="/" replace />;
// }

export default App;
