import * as React from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
//import Link from '@mui/material/Link';

function Copyright() {
  return (
    <Typography
      variant="body2"
      //variant="body1" color="text.secondary" align="center"
    >
      {"Copyright © "}
      {/* <Link color="inherit"  */}
      {/* // href="https://www./" target="_blank" */}
      {/* > */}
      Site Maintained By KPMG Advisory Services Pvt. Ltd. The Contents Are Owned
      By Govt.Of AP, India
      {/* </Link> */} {new Date().getFullYear()}
      {"."}
    </Typography>
  );
}

export default function StickyFooter() {
  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: "column",
        minHeight: "10vh",
      }}
    >
      <CssBaseline />
      <Box
        component="footer"
        sx={{
          py: 1,
          px: 1,
          mt: "auto",
          backgroundColor: (theme) =>
            theme.palette.mode === "light"
              ? theme.palette.grey[200]
              : theme.palette.grey[800],
        }}
      >
        <Container maxWidth="sm">
          <Copyright />
        </Container>
      </Box>
    </Box>
  );
}
