import React from 'react'

const InternshipOpportunities = () => {
  return (
    <div>InternshipOpportunities</div>
  )
}

export default InternshipOpportunities