import React from 'react'

const ApplyInternship = () => {
  return (
    <div>ApplyInternship</div>
  )
}

export default ApplyInternship