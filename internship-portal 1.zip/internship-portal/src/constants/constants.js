export const PORTAL_NAMES={
   PORTAL_NAME:"Internship Portal"
}


export const HEADINGS = {

};
