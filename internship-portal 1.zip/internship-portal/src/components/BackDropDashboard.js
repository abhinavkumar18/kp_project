import * as React from 'react';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Button from '@mui/material/Button';

export default function SimpleBackdrop() {
  const [open, setOpen] = React.useState(false);
  const handleClose = () => {
    setOpen(false);
  };
  const handleOpen = () => {
    setOpen(true);
  };

  return (
    <div>
      <Button onClick={handleOpen}>Detailed View</Button>
      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={open}
        onClick={handleClose}
      >
        {/* <iframe src="http://10.48.19.52/app/dashboards#/view/39687c00-d3ba-11ed-834f-6dc1d3d85dee?embed=true&_g=(filters:!(),refreshInterval:(pause:!t,value:0),time:(from:now-2y,to:now))&_a=(description:%27%27,filters:!(),fullScreenMode:!f,options:(hidePanelTitles:!f,syncColors:!f,useMargins:!t),panels:!((embeddableConfig:(enhancements:(),hidePanelTitles:!f,timeRange:(from:now-2y,to:now)),gridData:(h:15,i:%279a982e36-058e-4896-85a0-3d30efc1b2f8%27,w:24,x:0,y:0),id:%27901e6bf0-b721-11ed-834f-6dc1d3d85dee%27,panelIndex:%279a982e36-058e-4896-85a0-3d30efc1b2f8%27,title:%27Preauth%20%26%20Claim%20Records%20In%20ASRI%20For%20Last%202%20Years%27,type:lens,version:%277.17.6%27),(embeddableConfig:(enhancements:(),hidePanelTitles:!f),gridData:(h:15,i:a3179f75-663e-4c85-a1ec-161948301137,w:24,x:24,y:0),id:eb43e240-b2b6-11ed-834f-6dc1d3d85dee,panelIndex:a3179f75-663e-4c85-a1ec-161948301137,title:%27Age%20Wise%20Preauth%20Approved%20In%20ASRI%27,type:lens,version:%277.17.6%27),(embeddableConfig:(enhancements:(),hidePanelTitles:!f),gridData:(h:12,i:%276d93ee0a-a7e3-442e-9ea6-a243c498af8d%27,w:12,x:0,y:15),id:%2741951f30-b2b5-11ed-834f-6dc1d3d85dee%27,panelIndex:%276d93ee0a-a7e3-442e-9ea6-a243c498af8d%27,title:%27Hospital%20Type%20Wise%20Preauth%20In%20ASRI%27,type:lens,version:%277.17.6%27),(embeddableConfig:(enhancements:(),hidePanelTitles:!f),gridData:(h:12,i:a49769d4-5bdb-4959-8423-a8b5f3a183d2,w:12,x:12,y:15),id:%2746e908f0-b2b7-11ed-834f-6dc1d3d85dee%27,panelIndex:a49769d4-5bdb-4959-8423-a8b5f3a183d2,title:%27Gender%20Wise%20Preauth%20In%20ASRI%27,type:lens,version:%277.17.6%27),(embeddableConfig:(enhancements:(),hidePanelTitles:!f),gridData:(h:12,i:%2704c8b3f7-3b05-4807-862c-15c449e58c21%27,w:24,x:24,y:15),id:f019a2b0-b2b5-11ed-834f-6dc1d3d85dee,panelIndex:%2704c8b3f7-3b05-4807-862c-15c449e58c21%27,title:%27District%20Wise%20Preauth%20In%20ASRI%27,type:lens,version:%277.17.6%27),(embeddableConfig:(enhancements:(),hidePanelTitles:!f),gridData:(h:15,i:ec3e8021-1bf0-476b-aa26-002750a17603,w:48,x:0,y:27),id:%2723ca9900-b2b8-11ed-834f-6dc1d3d85dee%27,panelIndex:ec3e8021-1bf0-476b-aa26-002750a17603,title:%27Speciality%20Wise%20Preauth%20In%20ASRI%27,type:lens,version:%277.17.6%27)),query:(language:kuery,query:%27%27),tags:!(),timeRestore:!t,title:final_asri_preauth,viewMode:edit)%22" height="85%" width="80%" title="DETAILED_DASHBOARD"></iframe> */}
      </Backdrop>
    </div>
  );
}