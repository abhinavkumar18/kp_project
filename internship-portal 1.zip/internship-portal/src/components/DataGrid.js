import * as React from 'react';
import { TableVirtuoso } from 'react-virtuoso';

import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';

const sample = [
  [ 1,'MEDICO_CGH_GNT', 'Dr.T.Prabhakar Rao', 'MEDICO','9876504321','CR Created','24/02/2023 11:57:23 am','NA'],
  [ 2,'MEDICO_CGH_GNT', 'Dr.T.Prabhakar Rao', 'MEDICO','9876504321','CR Created','24/02/2023 11:57:23 am','NA']
];

function createData(id,sno, empcode, actionTakenby, designation,phn,remarks, actionTakentime,attachments) {
  return {id, sno, empcode, actionTakenby, designation,phn,remarks, actionTakentime,attachments};
}

const columns = [
  {
    width: 50,
    label: 'SNo',
    dataKey: 'sno',
    numeric:'true'
  },
  {
    width: 160,
    label: 'EmpCode',
    dataKey: 'empcode',
   
  },
  {
    width: 120,
    label: 'ActionTakenby',
    dataKey: 'actionTakenby',
   
  },
  {
    width: 120,
    label: 'Designation',
    dataKey: 'designation',
   
  },
  {
    width: 120,
    label: 'Phone Number',
    dataKey: 'phn',
   
  },
  {
    width: 120,
    label: 'Remarks',
    dataKey: 'remarks',
   
  },
  {
    width: 120,
    label: 'ActionTakentime',
    dataKey: 'actionTakentime',
   
  },
  {
    width: 120,
    label: 'Attachments',
    dataKey: 'attachments',
   
  },
  
];

const rows = Array.from({ length: 200 }, (_, index) => {
  const randomSelection = sample[Math.floor(Math.random() * sample.length)];
  return createData(index, ...randomSelection);
});

const VirtuosoTableComponents = {
  Scroller: React.forwardRef((props, ref) => (
    <TableContainer component={Paper} {...props} ref={ref} />
  )),
  Table: (props) => (
    <Table {...props}  size="small" aria-label="a dense table" sx={{ minWidth: 650 ,borderCollapse: 'separate', tableLayout: 'fixed' }} />
  ),
  TableHead,
  TableRow: ({ item: _item, ...props }) => <TableRow {...props} />,
  TableBody: React.forwardRef((props, ref) => <TableBody {...props} ref={ref} />),
};

function fixedHeaderContent() {
  return (
    <TableRow>
      {columns.map((column) => (
        <TableCell
          key={column.dataKey}
          variant="head"
          align={column.numeric || false ? 'right' : 'left'}
          style={{ width: column.width }}
         
        >
          {column.label}
        </TableCell>
      ))}
    </TableRow>
  );
}

function rowContent(_index, row) {
  return (
    <React.Fragment>
      {columns.map((column) => (
        <TableCell
          key={column.dataKey}
          align={column.numeric || false ? 'right' : 'left'}
        >
          {row[column.dataKey]}
        </TableCell>
      ))}
    </React.Fragment>
  );
}

export default function DataGrid() {
  return (
    <Paper style={{ height: 400, width: '100%' }}>
      <TableVirtuoso
        data={rows}
        components={VirtuosoTableComponents}
        fixedHeaderContent={fixedHeaderContent}
        itemContent={rowContent}
      />
    </Paper>
  );
}