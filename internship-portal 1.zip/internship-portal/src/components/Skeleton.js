//Particularly for Inbox and Sentbox
import * as React from "react";
// import PageTitle from '../../layouts/PageTitle';
import { Card, CardContent, Skeleton, Stack } from "@mui/material";

// import VirtualizedTable from '../../components/tables/VirtualizedTable';
export default function SkeletonForInboxSentbox() {
  return (
    <>
      <Skeleton variant="rectangular" width={"100%"} height={400} />
    </>
  );
}
