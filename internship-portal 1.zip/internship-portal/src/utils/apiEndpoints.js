const modulePath = "/preauth";

export const commonAPIEndpoints = {
  apiEndPoint: `${modulePath}/`,
};
