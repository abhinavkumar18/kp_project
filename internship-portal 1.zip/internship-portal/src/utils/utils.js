//For mapping dropdown data, radio buttons list
export const mapListData = (array, labelKey, idKey) => {
  return array.map((item) => ({
    label: item[labelKey],
    id: item[idKey],
  }));
};
