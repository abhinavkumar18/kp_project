package in.kpmg.ehs.portalsearch.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
/*import java.util.ArrayList;*/
import org.springframework.web.bind.annotation.RequestBody;

import in.kpmg.ehs.portalsearch.dtos.common.AdvanceCountSpecialitySearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceDistrictCount;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceHospitalSearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceMitraDistrict;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceMitraDistrictCount;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceProcedureSearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceSpecialitySearchHospital;
import in.kpmg.ehs.portalsearch.dtos.common.CountSearchSpecialityResult;
import in.kpmg.ehs.portalsearch.dtos.common.DisplayResult;
import in.kpmg.ehs.portalsearch.dtos.common.DistrictCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictWiseCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraSearchResult;
//import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchHospitalResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchProcedureResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchSpecialityResult;
import in.kpmg.ehs.portalsearch.dtos.common.SpecialitySearchHospitalResult;
import in.kpmg.ehs.portalsearch.dtos.common.StateCountResult;

@Service
public class PublicService {

	@PersistenceContext
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public List<SearchHospitalResult> advanceHospitalSearch(AdvanceHospitalSearch request) {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    es.hosp_name hospitalName ,\n"
				+ "    es.hosp_type hospitalType ,\n"
				+ "    el.loc_name AS districtName ,\n"
				+ "    (SELECT LISTAGG(ess.DIS_MAIN_NAME,',') WITHIN GROUP(ORDER BY ess.DIS_MAIN_NAME) AS specialities FROM ehfm_hosp_speciality ehs,\n"
				+ "    EHFM_SPECIALITIES ESS\n"
				+ "    WHERE is_active_flg = 'Y' AND phase_id = '1' AND renewal = '1' \n"
				+ "    AND scheme_id = 'CD201' and ehs.hosp_id=es.hosp_id\n"
				+ "    AND ESS.DIS_MAIN_ID=ehs.icd_cat_code\n"
				+ "    AND ess.DIS_ACTIVE_YN='Y'\n"
				+ "    ) as specialities,\n"
				+ "    name_of_medco as medcoName,\n"
				+ "    medco_contact_number as medcoContactNo,\n"
				+ "    name_of_mitra as mitraName,\n"
				+ "    mitra_contact_number as mitraContactNo\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "            || ' '\n"
				+ "            || eu.middle_name\n"
				+ "            || ' '\n"
				+ "            || eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                || ' '\n"
				+ "                || eu.middle_name\n"
				+ "                || ' '\n"
				+ "                || eu.last_name\n"
				+ "            ) AS name_of_mitra,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS mitra_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.mithra_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN ('G','C')\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) ehmd,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "            || ' '\n"
				+ "            || eu.middle_name\n"
				+ "            || ' '\n"
				+ "            || eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                || ' '\n"
				+ "                || eu.middle_name\n"
				+ "                || ' '\n"
				+ "                || eu.last_name\n"
				+ "            ) AS name_of_medco,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS medco_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_medco_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.medco_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN ('G','C')\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) emd\n"
				+ "WHERE\n"
				+ "    es.hosp_dist = el.loc_id\n"
				+ "    AND   es.hosp_active_yn = 'Y'\n"
				+ "    AND   es.scheme = 'CD201'\n"
				+ "    AND   loc_hdr_id = 'LH6'\n"
				+ "    AND   es.hosp_type IN ('G','C')\n"
				+ "    AND   es.hosp_id = ehmd.hosp_id (+)\n"
				+ "    AND   es.hosp_id = emd.hosp_id (+) ";
				if(request.getDistrictid() != null)
				nativeQuery = nativeQuery + " AND el.loc_id='"+request.getDistrictid()+"'";
				

		Query query = em.createNativeQuery(nativeQuery, SearchHospitalResult.class);

		List<SearchHospitalResult> searchResults = query.getResultList();
					
				
		return searchResults;
	}
//	
//	
	@SuppressWarnings("unchecked")
	public List<SearchSpecialityResult> advanceSpecialitySearch() {

		String nativeQuery = "SELECT distinct\n"
				+ "    c.dis_main_name as speciality,\n"
				+ "    c.dis_main_id as specialit_code,\n"
				+ "    b.icd_cat_code sub_category_code,\n"
				+ "    b.icd_cat_name as sub_category_name,\n"
				+ "    a.icd_proc_code as procedure_code,\n"
				+ "    a.proc_name as procedure_name,\n"
				+ "    a.no_of_days as duration_of_stay,\n"
				+ "    a.hosp_stay_amt + a.common_cat_amt + a.icd_amt as packageEhs,\n"
				+ "    INVESTIGATION_ID as investigationId,\n"
				+ "    INVEST_DESC as investDesc\n"
				+ "FROM\n"
				+ "    ehfm_main_therapy a,\n"
				+ "    ehfm_main_category b,\n"
				+ "    ehfm_specialities c,\n"
				+ "    (select * from EHFM_THERAPY_INVEST where ACTIVE_YN='Y' and SCHEME_ID='CD201')eti\n"
				+ "WHERE\n"
				+ "          a.state = 'CD201'\n"
				+ "    AND   a.active_yn = 'Y'\n"
				+ "    AND   a.process IN ('IP','DOP')\n"
				+ "    AND   a.icd_cat_code = b.icd_cat_code\n"
				+ "    AND   b.active_yn = 'Y'\n"
				+ "    AND   a.asri_code = b.asri_cat_code\n"
				+ "    AND   a.hosp_stay_amt IS NOT NULL\n"
				+ "    AND   c.dis_main_id = a.asri_code\n"
				+ "    AND   c.dis_active_yn = 'Y'\n"
				+ "    and   a.ICD_CAT_CODE=eti.ICD_PROC_CODE(+)";

		Query query = em.createNativeQuery(nativeQuery, SearchSpecialityResult.class);


		List<SearchSpecialityResult> searchResults = query.getResultList();		

		return searchResults;

	}
//	
	@SuppressWarnings("unchecked")
	public List<SearchProcedureResult> advanceProcedureSearch() {

		String nativeQuery ="SELECT distinct\n"
				+ " c.dis_main_name AS specialityName,\n"
				+ " c.dis_main_id AS specialityCode,\n"
				+ " b.icd_cat_code AS dissubId,\n"
				+ " b.icd_cat_name AS dissubName,\n"
				+ " a.icd_proc_code AS procedureType,\n"
				+ " a.proc_name AS procedureName,\n"
				+ " a.hosp_stay_amt + a.common_cat_amt + a.icd_amt AS packageAmount\n"
				//+ " INVESTIGATION_ID preInvestigations\n"
				//+ " INVEST_DESC \n"
				+ "FROM\n"
				+ " ehfm_main_therapy a,\n"
				+ " ehfm_main_category b,\n"
				+ " ehfm_specialities c,\n"
				+ " (select * from EHFM_THERAPY_INVEST where ACTIVE_YN='Y' and SCHEME_ID='CD201')eti\n"
				+ "WHERE\n"
				+ " a.state = 'CD201'\n"
				+ " AND a.active_yn = 'Y'\n"
				+ " AND a.process IN ('IP','DOP')\n"
				+ " AND a.icd_cat_code = b.icd_cat_code\n"
				+ " AND b.active_yn = 'Y'\n"
				+ " AND a.asri_code = b.asri_cat_code\n"
				+ " AND a.hosp_stay_amt IS NOT NULL\n"
				+ " AND c.dis_main_id = a.asri_code\n"
				+ " AND c.dis_active_yn = 'Y'\n"
				+ " and a.ICD_CAT_CODE=eti.ICD_PROC_CODE(+)";


		Query query = em.createNativeQuery(nativeQuery, SearchProcedureResult.class);

		List<SearchProcedureResult> searchResults = query.getResultList();		

		return searchResults;

	}
//	
//	
//	@SuppressWarnings("unchecked")
//	public List<DisplayResult> display() {
//
//		String nativeQuery = "SELECT aamm.MICR Micr,aamm.CITY City,aamm.BRANCH_NAME branchName,aamm.BANK_NAME bankName FROM ASRIM_ACCT_MICR_MASTER aamm where ROWNUM < 10 ";
//		Query query = em.createNativeQuery(nativeQuery, DisplayResult.class);
//		List<DisplayResult> searchResults = query.getResultList();
//		return searchResults;
//	}
	
	//done
	@SuppressWarnings("unchecked")
	public List<StateCountResult> advanceStateCount() {
		
		String nativeQuery ="SELECT DISTINCT\n"
				+ "    --el.loc_name AS District,\n"
				+ "    els.LOC_ID AS stateid ,\n"
				+ "    els.LOC_NAME AS State,\n"
				+ "    --el.loc_id as District_id,\n"
				+ "    COUNT(DISTINCT ehs.hosp_id) AS Govt ,\n"
				+ "    COUNT(DISTINCT ehss.hosp_id) AS Pvt \n"
				+ "FROM\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='G')ehs,\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='C')ehss,\n"
				+ "     (select * from ehfm_locations where loc_hdr_id='LH1') ELS,\n"
				+ "    (select * from ehfm_locations where loc_hdr_id = 'LH6')el   \n"
				+ "WHERE\n"
				+ "    ehs.HOSP_DIST = el.loc_id\n"
				+ "    and ehss.HOSP_DIST=el.loc_id\n"
				+ "    and ELS.LOC_ID=el.LOC_PARNT_ID\n"
				+ "    --AND els.LOC_ID='S35'\n"
				+ "    GROUP BY els.LOC_ID,els.LOC_NAME";
		
		Query query = em.createNativeQuery(nativeQuery, StateCountResult.class);
		List<StateCountResult> searchResults = query.getResultList();
		return searchResults;
	}
	//done
	@SuppressWarnings("unchecked")
	public List<DistrictCountResult> advanceDistrictCount(AdvanceDistrictCount request) {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    el.loc_name AS District,\n"
				+ "    el.loc_id AS District_id,\n"
				+ "    COUNT(DISTINCT ehs.hosp_id) AS Govt,\n"
				+ "    COUNT(DISTINCT ehss.hosp_id) AS Private\n"
				+ "FROM\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='G')ehs,\n"
				+ "    (select * from ehfm_hospitals where hosp_active_yn = 'Y' and scheme = 'CD201' and hosp_type='C')ehss,\n"
				+ "    (select * from ehfm_locations where loc_hdr_id='LH1') ELS ,\n"
				+ "    (select * from ehfm_locations where loc_hdr_id = 'LH6')el\n"
				+ "WHERE\n"
				+ "    ehs.HOSP_DIST = el.loc_id\n"
				+ "    and ehss.HOSP_DIST=el.loc_id\n"
				+ "    and ELS.LOC_ID=el.LOC_PARNT_ID\n";
				if(request.getStateVal()!=null) {
				 nativeQuery=nativeQuery + " and els.LOC_ID='"+request.getStateVal()+"' \n"
				+"GROUP BY el.loc_name,el.loc_id ";		 }
				else {
					nativeQuery=nativeQuery+" GROUP BY el.loc_name,el.loc_id ";
				}
		Query query = em.createNativeQuery(nativeQuery, DistrictCountResult.class);

		List<DistrictCountResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	//done
	@SuppressWarnings("unchecked")
	public List<MitraSearchResult> advanceMitraSearch() {

		String nativeQuery = "SELECT DISTINCT\n"
				+ "es.state_code AS locstateVal,\n"
				+ "    el.loc_name  AS state,\n"
				+ "    COUNT(DISTINCT USER_ID) AS mitraCount\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            DISTINCT HOSP_ID,USER_ID\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,EHFM_USERS EU\n"
				+ "        WHERE\n"
				+ "            end_dt IS NULL\n"
				+ "            AND   scheme = 'CD201'\n"
				+ "            AND SERVICE_FLG='Y'\n"
				+ "            AND EU.USER_TYPE='CD201'\n"
				+ "            AND ehmd.MITHRA_ID=EU.USER_ID\n"
				+ "    ) ehmd\n"
				+ "WHERE\n"
				+ "    es.state_code = el.loc_id\n"
				+ "    AND   loc_hdr_id = 'LH1'\n"
				+ "    AND   hosp_active_yn = 'Y'\n"
				+ "    AND   ES.scheme = 'CD201'\n"
				+ "    AND   es.HOSP_ID=EHMD.HOSP_ID\n"
				+ "    GROUP BY  el.loc_name,es.state_code";
		Query query = em.createNativeQuery(nativeQuery, MitraSearchResult.class);
		List<MitraSearchResult> searchResults = query.getResultList();
		return searchResults;
	}
	
	@SuppressWarnings("unchecked")
	public List<MitraDistrictWiseCountResult> advanceMitraDistrictWiseCount(AdvanceMitraDistrictCount request) {

		String nativeQuery ="select * from (\n"
				+ "SELECT\n"
				+ "    a.loc_parnt_id as stateId,\n"
				+ "    b.loc_name as state,\n"
				+ "    a.district as district,\n"
				+ "    SUM(mitra_count) as mitraCount\n"
				+ "FROM\n"
				+ "    (SELECT\n"
				+ "            d.loc_parnt_id,\n"
				+ "            c.STATE_CODE,\n"
				+ "            d.loc_hdr_id,\n"
				+ "            d.loc_name district,\n"
				+ "            COUNT(a.user_id) mitra_count\n"
				+ "        FROM\n"
				+ "            ehfm_users a,\n"
				+ "            ehfm_hosp_mithra_dtls b,\n"
				+ "            ehfm_hospitals c,\n"
				+ "            (SELECT * FROM ehfm_locations\n"
				+ "                WHERE active_yn = 'Y') d\n"
				+ "        WHERE\n"
				+ "            a.user_id = b.mithra_id\n"
				+ "            AND   b.hosp_id = c.hosp_id\n"
				+ "            AND   c.hosp_dist = d.loc_id\n"
				+ "            AND   a.dsgn_id = 'DG3009'\n"
				+ "            AND   c.scheme = 'CD201'\n"
				+ "            AND   a.service_flg = 'Y'\n"
				+ "            AND   b.end_dt IS NULL\n"
				+ "        GROUP BY\n"
				+ "            d.loc_parnt_id,\n"
				+ "            c.STATE_CODE,\n"
				+ "            d.loc_hdr_id,\n"
				+ "            d.loc_name\n"
				+ "    )A,\n"
				+ "    \n"
				+ "    (SELECT DISTINCT\n"
				+ "            b.loc_name,\n"
				+ "            a.loc_parnt_id,\n"
				+ "            a.loc_hdr_id,\n"
				+ "            COUNT(a.loc_id) district\n"
				+ "        FROM\n"
				+ "            ehfm_locations a,\n"
				+ "            (SELECT * FROM ehfm_locations\n"
				+ "                WHERE loc_hdr_id = 'LH1' AND   active_yn = 'Y') b\n"
				+ "        WHERE\n"
				+ "            a.loc_hdr_id = 'LH6'\n"
				+ "            AND   a.loc_parnt_id = b.loc_id\n"
				+ "            AND   a.active_yn = 'Y'\n"
				+ "        GROUP BY\n"
				+ "        \n"
				+ "            b.loc_name,\n"
				+ "            a.loc_parnt_id,\n"
				+ "            a.loc_hdr_id)b\n"
				+ "\n"
				+ "WHERE\n"
				+ "    a.loc_parnt_id = b.loc_parnt_id\n"
				+ "    and  a.loc_hdr_id=b.loc_hdr_id\n"
				+ "GROUP BY\n"
				+ "a.loc_parnt_id,b.loc_name,a.district)";
		if(request.getStateid()!=null) {
				nativeQuery=nativeQuery+"where stateId='"+request.getStateid()+"'";
		}
//		Query query = em.createNativeQuery(nativeQuery);
//		List<Object[]> rs= query.getResultList();
//		
//		for(int i=0;i<rs.size();i++) {
//			System.out.println(rs.get(i)[0]);
//			System.out.println(rs.get(i)[1]);
//			System.out.println(rs.get(i)[2]);
//		} 
		Query query = em.createNativeQuery(nativeQuery, MitraDistrictWiseCountResult.class);

		List<MitraDistrictWiseCountResult> searchResults = query.getResultList();
				
		return searchResults;
				

	}
	
	@SuppressWarnings("unchecked")
	public List<MitraDistrictResult> advanceMitraDistrictCount() {

		String nativeQuery ="SELECT DISTINCT\n"
				+ " eu.first_name\n"
				+ " || ' '\n"
				+ " || eu.middle_name\n"
				+ " || ' '\n"
				+ " || eu.last_name AS mitraName,\n"
				+ " eu.mobile_no AS mitraContact,\n"
				+ " es.loc_name AS district,\n"
				+ " esu.hosp_name hospitalName,\n"
				+ " esu.specialities Speciality\n"
				+ "FROM\n"
				+ " (\n"
				+ " SELECT\n"
				+ " *\n"
				+ " FROM\n"
				+ " ehfm_hosp_mithra_dtls ehmd,\n"
				+ " ehfm_users eu\n"
				+ " WHERE\n"
				+ " end_dt IS NULL\n"
				+ " AND scheme = 'CD201'\n"
				+ " AND service_flg = 'Y'\n"
				+ " AND user_type = 'CD201'\n"
				+ " AND ehmd.mithra_id = eu.user_id\n"
				+ " ) eu,\n"
				+ " (\n"
				+ " SELECT\n"
				+ " *\n"
				+ " FROM\n"
				+ " ehfm_hospitals es,\n"
				+ " ehfm_locations el\n"
				+ " WHERE\n"
				+ " es.hosp_dist = el.loc_id\n"
				+ " AND es.hosp_active_yn = 'Y'\n"
				+ " AND es.scheme = 'CD201'\n"
				+ " AND loc_hdr_id = 'LH6'\n"
				+ " ) es,\n"
				+ " (\n"
				+ " SELECT\n"
				+ " es.hosp_id,\n"
				+ " es.hosp_name,\n"
				+ " LISTAGG(ehs.icd_cat_code,\n"
				+ " ',') WITHIN GROUP(\n"
				+ " ORDER BY\n"
				+ " ehs.icd_cat_code\n"
				+ " ) AS specialities\n"
				+ " FROM\n"
				+ " ehfm_hospitals es,\n"
				+ " (\n"
				+ " SELECT\n"
				+ " *\n"
				+ " FROM\n"
				+ " ehfm_hosp_speciality\n"
				+ " WHERE\n"
				+ " is_active_flg = 'Y'\n"
				+ " AND phase_id = '1'\n"
				+ " AND renewal = '1'\n"
				+ " AND scheme_id = 'CD201'\n"
				+ " ) ehs\n"
				+ " WHERE\n"
				+ " es.hosp_active_yn = 'Y'\n"
				+ " AND es.scheme = 'CD201'\n"
				+ " AND es.hosp_id = ehs.hosp_id (+)\n"
				+ " GROUP BY\n"
				+ " es.hosp_id,es.hosp_name\n"
				+ " ) esu\n"
				+ "WHERE\n"
				+ " es.hosp_id = eu.hosp_id\n"
				+ " AND es.hosp_id = esu.hosp_id";

		Query query = em.createNativeQuery(nativeQuery, MitraDistrictResult.class);

		List<MitraDistrictResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	//done
	@SuppressWarnings("unchecked")
	public List<CountSearchSpecialityResult> advanceCountSpecialitySearch(AdvanceCountSpecialitySearch request) {

		String nativeQuery = "SELECT\n"
				+ "    DISTINCT\n"
				+ "    upper(b.dis_main_name|| ' ( '|| b.dis_main_id|| ' )') speciality,\n"
				+ "    SUM(a.procedures_count) proceduresCount,\n"
				+ "    SUM(b.hospitals_count) hospitalsCount\n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            asri_code,\n"
				+ "            COUNT(DISTINCT icd_proc_code) AS procedures_count\n"
				+ "        FROM\n"
				+ "            ehfm_main_therapy\n"
				+ "        WHERE\n"
				+ "            active_yn = 'Y'\n"
				+ "            AND   state = 'CD201'\n"
				+ "        GROUP BY\n"
				+ "            asri_code\n"
				+ "    ) a,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            dis_main_id,\n"
				+ "            dis_main_name,\n"
				+ "            COUNT(DISTINCT hosp_id) AS hospitals_count\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_speciality ehs,\n"
				+ "            ehfm_specialities es\n"
				+ "        WHERE\n"
				+ "            is_active_flg = 'Y'\n"
				+ "            AND   scheme_id = 'CD201'\n";
			if(request.getSpecialityId()!=null) {
				nativeQuery=nativeQuery + "AND '"+ request.getSpecialityId() +"'= es.dis_main_id \n";}
				else if(request.getSpecialityId()==null) {
				nativeQuery=nativeQuery +" AND   ehs.icd_cat_code = es.dis_main_id \n";}
				nativeQuery=nativeQuery + "        GROUP BY\n"
				+ "            dis_main_id,\n"
				+ "            dis_main_name\n"
				+ "    ) b\n"
				+ "WHERE\n"
				+ "    a.asri_code = b.dis_main_id\n"
				+ "    group by upper(b.dis_main_name|| ' ( '|| b.dis_main_id|| ' )')";

		Query query = em.createNativeQuery(nativeQuery, CountSearchSpecialityResult.class);


		List<CountSearchSpecialityResult> searchResults = query.getResultList();		

		return searchResults;

	}
	@SuppressWarnings("unchecked")
	public List<SpecialitySearchHospitalResult> advanceSpecialitySearchHospital(@RequestBody AdvanceSpecialitySearchHospital request){
		
		
		String nativeQuery="select * from (SELECT DISTINCT\n"
				+ "    es.hosp_name hospitalName,\n"
				+ "    es.hosp_type hospitalType,\n"
				+ "    el.LOC_NAME AS district,\n"
				+ "    (SELECT LISTAGG(ehs.icd_cat_code,',') WITHIN GROUP(ORDER BY ehs.icd_cat_code) AS specialities FROM ehfm_hosp_speciality ehs WHERE is_active_flg = 'Y' AND phase_id = '1' AND renewal = '1'\n"
				+ "    AND scheme_id = 'CD201' and ehs.hosp_id=es.hosp_id) as specialities,\n"
				+ "    es.CRT_DT as hospitalEmpDate,\n"
				+ "    emd.FIRST_NAME||' '||emd.MIDDLE_NAME||' '||emd.LAST_NAME as medcoName,\n"
				+ "    emd.MOBILE_NO as medcoContact,\n"
				+ "    ehmd.FIRST_NAME||' '||ehmd.MIDDLE_NAME||' '||ehmd.LAST_NAME as mitraName,\n"
				+ "    ehmd.MOBILE_NO as mitraContact\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT * FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,EHFM_USERS EU\n"
				+ "        WHERE\n"
				+ "            end_dt IS NULL\n"
				+ "            AND scheme = 'CD201'\n"
				+ "            AND SERVICE_FLG='Y'\n"
				+ "            AND EU.USER_TYPE='CD201'\n"
				+ "            AND ehmd.MITHRA_ID=EU.USER_ID\n"
				+ "    ) ehmd,\n"
				+ "    (\n"
				+ "        SELECT * FROM\n"
				+ "            EHFM_MEDCO_DTLS ehmd,EHFM_USERS EU\n"
				+ "        WHERE\n"
				+ "            end_dt IS NULL\n"
				+ "            AND scheme = 'CD201'\n"
				+ "            AND SERVICE_FLG='Y'\n"
				+ "            AND EU.USER_TYPE='CD201'\n"
				+ "            AND ehmd.MEDCO_ID=EU.USER_ID\n"
				+ "    ) emd\n"
				+ "WHERE\n"
				+ "          es.HOSP_DIST = el.loc_id\n"
				+ "    AND   loc_hdr_id = 'LH6'\n"
				+ "    AND   hosp_active_yn = 'Y'\n"
				+ "    AND   ES.scheme = 'CD201'\n"
				+ "    AND   es.HOSP_ID(+)=EHMD.HOSP_ID\n"
				+ "    and   es.HOSP_ID(+)=emd.hosp_id)";
		
		if(request.getSpecialityId()!=null&&request.getHospitalType()!=null) {
			nativeQuery=nativeQuery +"where specialities like '%"+ request.getSpecialityId()+",%' and hospitalType = '"+request.getHospitalType()+"'";
		}
		else if(request.getSpecialityId()==null&&request.getHospitalType()!=null)
		{
			nativeQuery=nativeQuery +"where hospitalType = '"+request.getHospitalType()+"'";
		}
		else if(request.getSpecialityId()!=null&&request.getHospitalType()==null)
		{
			nativeQuery=nativeQuery +"where specialities like '%"+ request.getSpecialityId()+",%'";
		}
		
		
		Query query = em.createNativeQuery(nativeQuery, SpecialitySearchHospitalResult.class);


		List<SpecialitySearchHospitalResult> searchResults = query.getResultList();		

		return searchResults;

	
	
}
}