package in.kpmg.ehs.portalsearch.dtos.common;
import javax.persistence.Entity;
import javax.persistence.Id;

	@Entity
public class MitraDistrictWiseCountResult {

	@Id
	private String stateId;
	private String state;
	private String district;
	private int mitraCount;
	public String getStateId() {
		return stateId;
	}
	public void setStateId(String stateId) {
		this.stateId = stateId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public int getMitraCount() {
		return mitraCount;
	}
	public void setMitraCount(int mitraCount) {
		this.mitraCount = mitraCount;
	}
	public MitraDistrictWiseCountResult() {
		
	}

}
