package in.kpmg.ehs.portalsearch.controllers;

import java.util.List;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.kpmg.ehs.portalsearch.dtos.common.AdvanceCountSpecialitySearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceDistrictCount;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceHospitalSearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceMitraDistrict;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceMitraDistrictCount;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceProcedureSearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.ehs.portalsearch.dtos.common.AdvanceSpecialitySearchHospital;
import in.kpmg.ehs.portalsearch.dtos.common.ApiResponse;
import in.kpmg.ehs.portalsearch.dtos.common.ApiResponse2;
import in.kpmg.ehs.portalsearch.dtos.common.CountSearchSpecialityResult;
import in.kpmg.ehs.portalsearch.dtos.common.DisplayResult;
import in.kpmg.ehs.portalsearch.dtos.common.DistrictCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictWiseCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.MitraSearchResult;
//import in.kpmg.ehs.portalsearch.dtos.common.MitraDistrictCountResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchHospitalResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchProcedureResult;
import in.kpmg.ehs.portalsearch.dtos.common.SearchSpecialityResult;
import in.kpmg.ehs.portalsearch.dtos.common.SpecialitySearchHospitalResult;
import in.kpmg.ehs.portalsearch.dtos.common.StateCountResult;
import in.kpmg.ehs.portalsearch.services.ErrorService;
import in.kpmg.ehs.portalsearch.services.PublicService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/public")
public class PublicController {
    
    @Autowired
    private PublicService pubServ;
    

    @Autowired
    private ErrorService eService;
    
    @GetMapping("/ehs-checkconn")
    public ApiResponse<?> checkconn() {
        //userServ.updateAllPassword()
        return new ApiResponse<>(true, "Connection is successfull.",null );
    } 
    //done
	@PostMapping("/ehs-hospitalsearch-districtwise")
	public ApiResponse<?> advanceHospitalSearch(@RequestBody AdvanceHospitalSearch request) {

		try {

			List<SearchHospitalResult> results = pubServ.advanceHospitalSearch(request);
			//System.out.println(results.size());
			if (results.size() > 0) {
				
				JSONArray jsonData = new JSONArray();
	            for(SearchHospitalResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getHospitalName());
	                if(position.getHospitalType().equalsIgnoreCase("C")) {
	                	jsonArray.put("Private");
	                }
	                else if(position.getHospitalType().equalsIgnoreCase("G")) {
	                	jsonArray.put("Government");
	                }
	                else {
	                	jsonArray.put("NA");
	                }
	                //jsonArray.put(position.getHospitalType());
	                jsonArray.put(position.getDistrictName());
	               // jsonArray.put(position.getHospitalAddress());          
	                jsonArray.put(position.getSpecialities());
	               // jsonArray.put(position.getEmpanalledDate());
	                jsonArray.put(position.getMedcoName());
	                jsonArray.put(position.getMedcoContactNo());
	                jsonArray.put(position.getMitraName());
	                jsonArray.put(position.getMitraContactNo());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	        }
	        
			else {
				return new ApiResponse<>(false,"Search result not found", null);
			}
				
			} 

		 catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
//	
//	
	@GetMapping("/ehs-searchprocedure")
	public ApiResponse<?> advanceProcedureSearch() {

		try {

			List<SearchProcedureResult> results = pubServ.advanceProcedureSearch();
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(SearchProcedureResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getSpecialityCode());
	                jsonArray.put(position.getSpecialityName());
	                jsonArray.put(position.getProcedureType());
//	                jsonArray.put(position.getPreInvestigations());
//	                jsonArray.put(position.getMedInvestigations()); 
//	                jsonArray.put(position.getAasaraAmt());
	                jsonArray.put(position.getPackageAmount());
//	                jsonArray.put(position.getPostInvestigations());
//	                jsonArray.put(position.getHospstayAmt());
//	                jsonArray.put(position.getDissubId());
//	                jsonArray.put(position.getDissubName());
//	                jsonArray.put(position.getSurgeryId());
//	                jsonArray.put(position.getSurgdispCode());
//	                jsonArray.put(position.getProcedureName());
//	                jsonArray.put(position.getHospstayAmt());
//	                jsonArray.put(position.getCommoncatAmt());
//	                jsonArray.put(position.getIcdAmt());
//	                jsonArray.put(position.getDuration());
//	                jsonArray.put(position.getIsPerdm());
//	                jsonArray.put(position.getCount());
//	                jsonArray.put(position.getHospstayamtGovt());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	            
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
//	
	@GetMapping("/ehs-searchspeciality")
	public ApiResponse<?> advanceSpecialitySearch() {

		try {

			List<SearchSpecialityResult> results = pubServ.advanceSpecialitySearch();
			if (results.size() > 0) {

				JSONArray jsonData = new JSONArray();
	            for(SearchSpecialityResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getSpeciality());
	                jsonArray.put(position.getSpecialit_code());
	                jsonArray.put(position.getSub_category_code());
	                jsonArray.put(position.getSub_category_name());
	                jsonArray.put(position.getProcedure_code());
	                jsonArray.put(position.getProcedure_name());
	                jsonArray.put(position.getDuration_of_stay());
	                jsonArray.put(position.getPackageEhs());
	                jsonArray.put(position.getInvestigationId());
	                jsonArray.put(position.getInvestDesc());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
				
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}

//    
//    @GetMapping("/display")
//	public ApiResponse<?> display() {
//
//		try {
//
//			List<DisplayResult> results = pubServ.display();
//			if (results.size() > 0) {
//				//return new ApiResponse<>(true, "Search Results found.", results);
//				return new ApiResponse<>(false, "Search Results Not found.", null);
//			} else {
//				return new ApiResponse<>(false, "Search Results Not found.", null);
//			}
//
//		} catch (Exception ex) {
//			return new ApiResponse<>(eService.reportError(ex));
//		}
//	}
    //done
	@GetMapping("/ehs-hospitalsearch-statewisecount")
	public ApiResponse<?> advanceStateCount() {

		try {

			List<StateCountResult> results = pubServ.advanceStateCount();
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(StateCountResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getState());
	                jsonArray.put(position.getStateid());
	                jsonArray.put(position.getGovt());
	                jsonArray.put(position.getPvt());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	            
				//return new ApiResponse2<>(true, "Search Results found.", results);
	            
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	//done
	@PostMapping("/ehs-hospital-districtwisecount")
	public ApiResponse<?> advanceDistrictCount(@RequestBody AdvanceDistrictCount request) {

		try {

			List<DistrictCountResult> results = pubServ.advanceDistrictCount(request);
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(DistrictCountResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getDistrict());
	                jsonArray.put(position.getGovt());
	                jsonArray.put(position.getPrivate());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
    //done
	@GetMapping("/ehs-mitra-statewisecount")
	public ApiResponse<?> advanceMitraSearch() {

		try {

			List<MitraSearchResult> results = pubServ.advanceMitraSearch();
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(MitraSearchResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getState());
	                jsonArray.put(position.getMitraCount());
	                jsonArray.put(position.getLocstateVal());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	            
				//return new ApiResponse2<>(true, "Search Results found.", results);
	            
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	
	@PostMapping("/ehs-mitra-districtwisecount")
	public ApiResponse<?> advanceMitraDistrictWiseCount(@RequestBody AdvanceMitraDistrictCount request) {

		try {

			List<MitraDistrictWiseCountResult> results = pubServ.advanceMitraDistrictWiseCount(request);
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(MitraDistrictWiseCountResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getStateId());
	                jsonArray.put(position.getState());
	                jsonArray.put(position.getDistrict());
	                jsonArray.put(position.getMitraCount());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
//	
	@GetMapping("/ehs-mitra-search-districtwise")
	public ApiResponse<?> advanceMitraDistrictCount() {

		try {

			List<MitraDistrictResult> results = pubServ.advanceMitraDistrictCount();
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(MitraDistrictResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getMitraName());
	                jsonArray.put(position.getMitraContact());
	                jsonArray.put(position.getDistrict());
	                jsonArray.put(position.getHospitalName());
	                jsonArray.put(position.getSpeciality());
	                //jsonArray.put(position.getDistrictid());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	//done
	@PostMapping("/ehs-specialitysearch-count")
	public ApiResponse<?> advanceCountSpecialitySearch(@RequestBody AdvanceCountSpecialitySearch request) {

		try {

			List<CountSearchSpecialityResult> results = pubServ.advanceCountSpecialitySearch(request);
			if (results.size() > 0) {

				JSONArray jsonData = new JSONArray();
	            for(CountSearchSpecialityResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	            	jsonArray.put(position.getSpeciality());
	                jsonArray.put(position.getProceduresCount());
	                jsonArray.put(position.getHospitalsCount());
//	                jsonArray.put(position.getDismainId());
	                
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
				
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	
	
	@PostMapping("/ehs-specialitysearchhospital")
	public ApiResponse<?> advanceSpecialitySearchHospital(@RequestBody AdvanceSpecialitySearchHospital request) {

		try {

			List<SpecialitySearchHospitalResult> results = pubServ.advanceSpecialitySearchHospital(request);
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(SpecialitySearchHospitalResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getHospitalName());
	                jsonArray.put(position.getHospitalType());
	                jsonArray.put(position.getDistrict());
	                jsonArray.put(position.getSpecialities());
	                jsonArray.put(position.getHospitalEmpDate());
	                jsonArray.put(position.getMedcoName());
	                jsonArray.put(position.getMedcoContact());
	                jsonArray.put(position.getMitraName());
	                jsonArray.put(position.getMitraContact());
	                //jsonArray.put(position.getDistrictid());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	
	
}
