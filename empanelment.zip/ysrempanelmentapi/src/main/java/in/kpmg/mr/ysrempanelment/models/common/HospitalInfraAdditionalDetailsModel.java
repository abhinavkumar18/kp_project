package in.kpmg.mr.ysrempanelment.models.common;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;

@Entity
@Table(name="EMPNL_HOSP_INFRA_DETAILS_ADDITIONAL")
@Data
public class HospitalInfraAdditionalDetailsModel {

	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "EMPNL_HOSP_INFRA_DETAILS_ADDITIONAL_SEQ")
	@SequenceGenerator(name = "EMPNL_HOSP_INFRA_DETAILS_ADDITIONAL_SEQ",sequenceName = "EMPNL_HOSP_INFRA_DETAILS_ADDITIONAL_SEQ",allocationSize = 1)
	private Long ADD_INFRA_ID;
	private Long EMPANL_ID;
	private String L_VALUE;
	private String LABLE_DOC;
	@CreationTimestamp
	private Timestamp CREATED_ON;
	private String CREATED_BY;
	@CreationTimestamp
	private Timestamp UPDATED_ON;
	private String UPDATED_BY;
	private Long LABEL_ID;
}
