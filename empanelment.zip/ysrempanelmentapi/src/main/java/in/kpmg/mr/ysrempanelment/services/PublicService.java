package in.kpmg.mr.ysrempanelment.services;
/**
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import java.util.ArrayList;
import org.springframework.web.bind.annotation.RequestBody;

//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceCountSpecialitySearch;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceDistrictCount;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceDistrictList;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceHospitalSearch;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceMandalList;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceMitraDistrict;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceMitraDistrictCount;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceProcedureSearch;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceProcedureSpecialitySearch;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceSpecialitySearch;
//import in.kpmg.mr.nonempanelment.dtos.common.AdvanceSpecialitySearchHospital;
//import in.kpmg.mr.nonempanelment.dtos.common.CountSearchSpecialityResult;
//import in.kpmg.mr.nonempanelment.dtos.common.DisplayResult;
//import in.kpmg.mr.nonempanelment.dtos.common.DistrictCountResult;
//import in.kpmg.mr.nonempanelment.dtos.common.DistrictListResult;
import in.kpmg.mr.nonempanelment.dtos.common.MandalListResult;
import in.kpmg.mr.nonempanelment.dtos.common.MitraDistrictResult;
import in.kpmg.mr.nonempanelment.dtos.common.MitraDistrictWiseCountResult;
import in.kpmg.mr.nonempanelment.dtos.common.MitraSearchResult;
import in.kpmg.mr.nonempanelment.dtos.common.SearchHospitalResult;
import in.kpmg.mr.nonempanelment.dtos.common.SearchProcedureResult;
//import in.kpmg.mr.nonempanelment.dtos.common.SearchProcedureSpecialityResult;
//import in.kpmg.mr.nonempanelment.dtos.common.SearchSpecialityResult;
//import in.kpmg.mr.nonempanelment.dtos.common.SpecialitySearchHospitalResult;
//import in.kpmg.mr.nonempanelment.dtos.common.StateCountResult;
//import in.kpmg.mr.nonempanelment.dtos.common.StateListResult;

@Service
public class PublicService {

	@PersistenceContext
	private EntityManager em;
	//old
	@SuppressWarnings("unchecked")
	public List<SearchHospitalResult> advanceHospitalSearch(AdvanceHospitalSearch request) {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    es.hosp_name hospitalName,\n"
				+ "    es.hosp_type hospitalType,\n"
				+ "    el.loc_name AS districtName,\n"
				+ "	   replace(es.HOUSE_NO\n"
				+ "    ||','\n"
				+ "    || es.STREET,',','<br/>') hospitalAddress,\n"
				+ "    replace(specialities,',','<br/>') specialities,\n"
				+ "    replace(name_of_medco,',','<br/>') medcoName,\n"
				+ "    replace(medco_contact_number,',','<br/>') medcoContactNo,\n"
				+ "    replace(name_of_mitra,',','<br/>') mitraName,\n"
				+ "    replace(mitra_contact_number,',','<br/>') mitraContactNo\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "            || ' '\n"
				+ "            || eu.middle_name\n"
				+ "            || ' '\n"
				+ "            || eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                || ' '\n"
				+ "                || eu.middle_name\n"
				+ "                || ' '\n"
				+ "                || eu.last_name\n"
				+ "            ) AS name_of_mitra,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS mitra_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.mithra_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN ('G','C')\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) ehmd,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "            || ' '\n"
				+ "            || eu.middle_name\n"
				+ "            || ' '\n"
				+ "            || eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                || ' '\n"
				+ "                || eu.middle_name\n"
				+ "                || ' '\n"
				+ "                || eu.last_name\n"
				+ "            ) AS name_of_medco,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS medco_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_medco_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.medco_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN ('G','C')\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) emd,\n"
				+ "    (SELECT HOSP_ID,LISTAGG(ess.DIS_MAIN_NAME,',') WITHIN GROUP(ORDER BY ess.DIS_MAIN_NAME) AS specialities FROM ehfm_hosp_speciality ehs,\n"
				+ "    EHFM_SPECIALITIES ESS\n"
				+ "    WHERE is_active_flg = 'Y' AND phase_id = '1' AND renewal = '1' \n"
				+ "    AND scheme_id = 'CD201' \n"
				+ "    AND ESS.DIS_MAIN_ID=ehs.icd_cat_code\n"
				+ "    AND ess.DIS_ACTIVE_YN='Y'\n"
				+ "    --AND ICD_CAT_CODE='S8'\n"
				+ "    GROUP BY HOSP_ID\n"
				+ "    ) ehs\n"
				+ "WHERE\n"
				+ "          es.hosp_dist = el.loc_id\n"
				+ "    AND   es.hosp_active_yn = 'Y'\n"
				+ "    AND   es.scheme = 'CD201'\n"
				+ "    AND   loc_hdr_id = 'LH6'\n"
				+ "    AND   es.hosp_type IN ('G','C')\n"
				+ "    and   ehs.hosp_id=es.hosp_id\n"
				+ "    AND   es.hosp_id = ehmd.hosp_id (+)\n"
				+ "    AND   es.hosp_id = emd.hosp_id (+)";
				if(request.getDistrictid() != null)
				nativeQuery = nativeQuery + " AND el.loc_id='"+request.getDistrictid()+"'";
				

		Query query = em.createNativeQuery(nativeQuery, SearchHospitalResult.class);

		List<SearchHospitalResult> searchResults = query.getResultList();
					
				
		return searchResults;
	}

//	
	@SuppressWarnings("unchecked")
	public List<SearchSpecialityResult> advanceSpecialitySearch() {

		String nativeQuery = "SELECT DISTINCT\n"
				+ "    c.dis_main_id AS specialit_code,\n"
				+ "    c.dis_main_name AS speciality ,\n"
				+ "    a.icd_proc_code AS procedure_code,\n"
				+ "    a.proc_name AS procedure_name,\n"
				+ "    a.hosp_stay_amt + a.common_cat_amt + a.icd_amt AS packageEhs,\n"
				+ "    invest_name investDesc\n"
				+ "\n"
				+ "FROM\n"
				+ "    ehfm_main_therapy a,\n"
				+ "    ehfm_specialities c,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            eti.icd_proc_code,LISTAGG(invest_desc,',') within group (order by invest_desc) as invest_name\n"
				+ "        FROM\n"
				+ "            ehfm_therapy_invest eti\n"
				+ "        WHERE\n"
				+ "            active_yn = 'Y'\n"
				+ "            AND   scheme_id = 'CD201'\n"
				+ "            group by eti.icd_proc_code\n"
				+ "    ) eti\n"
				+ "WHERE\n"
				+ "          a.active_yn = 'Y'\n"
				+ "    AND   a.state = 'CD201'\n"
				+ "    --AND   a.asri_code = 'S4'\n"
				+ "    AND   c.dis_main_id = a.asri_code\n"
				+ "    AND   c.dis_active_yn = 'Y'\n"
				+ "    AND   a.icd_cat_code = eti.icd_proc_code(+)\n"
				+ "	   ORDER BY speciality";

		Query query = em.createNativeQuery(nativeQuery, SearchSpecialityResult.class);


		List<SearchSpecialityResult> searchResults = query.getResultList();		

		return searchResults;

	}
//	
	@SuppressWarnings("unchecked")
	public List<SearchProcedureResult> advanceProcedureSearch() {

		String nativeQuery ="SELECT DISTINCT\r\n"
				+ "    c.dis_main_id AS specialityCode,\r\n"
				+ "    c.dis_main_name AS specialityName,\r\n"
				+ "    a.icd_proc_code AS procedureType,\r\n"
				+ "    a.proc_name AS procedureName,\r\n"
				+ "    a.hosp_stay_amt + a.common_cat_amt + a.icd_amt AS packageAmount,\r\n"
				+ "    replace(invest_name,',','<br/>') AS preInvestigations\r\n"
				+ "FROM\r\n"
				+ "    ehfm_main_therapy a,\r\n"
				+ "    ehfm_specialities c,\r\n"
				+ "    (\r\n"
				+ "        SELECT\r\n"
				+ "            eti.icd_proc_code,\r\n"
				+ "            LISTAGG(invest_desc,\r\n"
				+ "            ',') WITHIN GROUP(\r\n"
				+ "            ORDER BY\r\n"
				+ "                invest_desc\r\n"
				+ "            ) AS invest_name\r\n"
				+ "        FROM\r\n"
				+ "            ehfm_therapy_invest eti\r\n"
				+ "        WHERE\r\n"
				+ "            active_yn = 'Y'\r\n"
				+ "            AND   scheme_id = 'CD201'\r\n"
				+ "        GROUP BY\r\n"
				+ "            eti.icd_proc_code\r\n"
				+ "    ) eti\r\n"
				+ "WHERE\r\n"
				+ "    a.active_yn = 'Y'\r\n"
				+ "    AND   a.state = 'CD201'\r\n"
				+ "\r\n"
				+ "    --AND   a.asri_code = 'S4'\r\n"
				+ "    AND   c.dis_main_id = a.asri_code\r\n"
				+ "    AND   c.dis_active_yn = 'Y'\r\n"
				+ "    and   PROCESS ='IP'\r\n"
				+ "    AND   a.icd_cat_code = eti.icd_proc_code (+)\r\n"
				+ "ORDER BY\r\n"
				+ "    c.dis_main_name";


		Query query = em.createNativeQuery(nativeQuery);
		List<Object[]> searchResults=query.getResultList();
		List<SearchProcedureResult> searchResults1 = new ArrayList<>();
		for(int i=0;i<searchResults.size();i++)
		{
			SearchProcedureResult res=new SearchProcedureResult();
			if(null != searchResults.get(i)[0]) {
			res.setSpecialityCode(searchResults.get(i)[0].toString());}//Speciality code
			if(null != searchResults.get(i)[1]) {
			res.setSpecialityName(searchResults.get(i)[1].toString());}//Speciality Name
			if(null != searchResults.get(i)[2]) {
			res.setProcedureType(searchResults.get(i)[2].toString());}//Procedure Code
			if(null != searchResults.get(i)[3]) {
			res.setProcedureName(searchResults.get(i)[3].toString());}//Procedure Name
			if(null != searchResults.get(i)[4]) {
				res.setPackageAmount(searchResults.get(i)[4].toString());}// Packages
			if(null != searchResults.get(i)[5]) {
				res.setPreInvestigations(searchResults.get(i)[5].toString());}//Investigation Name
			searchResults1.add(res);
		}
		return searchResults1;
		//List<SearchProcedureResult> searchResults = query.getResultList();		

		//return searchResults;
		

	}
	@SuppressWarnings("unchecked")
	public List<StateCountResult> advanceStateCount() {
		
		String nativeQuery ="SELECT state_code stateId,state_name stateName,SUM(govt_hospitals_count) AS govt,\n"
				+ "SUM(Pvt_Hospitals_Count) AS pvt FROM\n"
				+ "(\n"
				+ "SELECT\n"
				+ "    els.loc_id as state_code,\n"
				+ "    els.loc_name as state_name,\n"
				+ "    COUNT(DISTINCT hosp_id) AS govt_hospitals_count,\n"
				+ "    0 Pvt_Hospitals_Count\n"
				+ "FROM\n"
				+ "    ehfm_hospitals eh,\n"
				+ "    ehfm_locations el,\n"
				+ "    ehfm_locations els\n"
				+ "WHERE\n"
				+ "    hosp_active_yn = 'Y'\n"
				+ "    AND   scheme = 'CD201'\n"
				+ "    AND   hosp_type = 'G'\n"
				+ "    AND   eh.hosp_dist = el.loc_id\n"
				+ "    AND   el.loc_hdr_id = 'LH6'\n"
				+ "    AND   eh.state_code = els.loc_id\n"
				+ "    AND   els.loc_hdr_id = 'LH1'\n"
				+ "GROUP BY\n"
				+ "    els.loc_id,\n"
				+ "    els.loc_name\n"
				+ "    union\n"
				+ "    SELECT\n"
				+ "    els.loc_id as state_code,\n"
				+ "    els.loc_name as state_name,\n"
				+ "    0 govt_hospitals_count,\n"
				+ "    COUNT(DISTINCT hosp_id) AS Pvt_Hospitals_Count\n"
				+ "FROM\n"
				+ "    ehfm_hospitals eh,\n"
				+ "    ehfm_locations el,\n"
				+ "    ehfm_locations els\n"
				+ "WHERE\n"
				+ "    hosp_active_yn = 'Y'\n"
				+ "    AND   scheme = 'CD201'\n"
				+ "    AND   hosp_type = 'C'\n"
				+ "    AND   eh.hosp_dist = el.loc_id\n"
				+ "    AND   el.loc_hdr_id = 'LH6'\n"
				+ "    AND   eh.state_code = els.loc_id\n"
				+ "    AND   els.loc_hdr_id = 'LH1'\n"
				+ "GROUP BY\n"
				+ "    els.loc_id,\n"
				+ "    els.loc_name)\n"
				+ "    GROUP BY state_code,state_name";
		
		Query query = em.createNativeQuery(nativeQuery, StateCountResult.class);
		List<StateCountResult> searchResults = query.getResultList();
		return searchResults;
	}
	//updated
	@SuppressWarnings("unchecked")
	public List<DistrictCountResult> advanceDistrictCount(AdvanceDistrictCount request) {

		String nativeQuery="SELECT district_code districtId,district_name districtName,SUM(govt_hospitals_count) AS govt,\r\n"
				+ "SUM(Pvt_Hospitals_Count) AS pvt FROM\r\n"
				+ "(\r\n"
				+ "SELECT\r\n"
				+ "    el.loc_id as district_code,\r\n"
				+ "    el.loc_name as district_name,\r\n"
				+ "    COUNT(DISTINCT hosp_id) AS govt_hospitals_count,\r\n"
				+ "    0 Pvt_Hospitals_Count\r\n"
				+ "FROM\r\n"
				+ "    ehfm_hospitals eh,\r\n"
				+ "    ehfm_locations el\r\n"
				+ "WHERE\r\n"
				+ "          hosp_active_yn = 'Y'\r\n"
				+ "    AND   scheme = 'CD201'\r\n"
				+ "    AND   hosp_type = 'G'\r\n"
				+ "    AND   eh.hosp_dist = el.loc_id\r\n"
				+ "    AND   el.loc_hdr_id = 'LH6'\r\n";
			if(request.getStateVal()!=null)
				nativeQuery=nativeQuery+"AND   eh.state_code='"+request.getStateVal()+"'"
				+ "GROUP BY\r\n"
				+ "    el.loc_id,\r\n"
				+ "    el.loc_name\r\n"
				+ "    union\r\n"
				+ "    SELECT\r\n"
				+ "    el.loc_id as district_code,\r\n"
				+ "    el.loc_name as district_name,\r\n"
				+ "    0 govt_hospitals_count,\r\n"
				+ "    COUNT(DISTINCT hosp_id) AS Pvt_Hospitals_Count\r\n"
				+ "FROM\r\n"
				+ "    ehfm_hospitals eh,\r\n"
				+ "    ehfm_locations el\r\n"
				+ "WHERE\r\n"
				+ "          hosp_active_yn = 'Y'\r\n"
				+ "    AND   scheme = 'CD201'\r\n"
				+ "    AND   hosp_type = 'C'\r\n"
				+ "    AND   eh.hosp_dist = el.loc_id\r\n"
				+ "    AND   el.loc_hdr_id = 'LH6'\r\n";
			if(request.getStateVal()!=null)
				nativeQuery=nativeQuery+"AND   eh.state_code='"+request.getStateVal()+"'"
				+ "GROUP BY\r\n"
				+ "    el.loc_id,\r\n"
				+ "    el.loc_name)\r\n"
				+ "    GROUP BY district_code,district_name";
		Query query = em.createNativeQuery(nativeQuery, DistrictCountResult.class);

		List<DistrictCountResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	//done
	@SuppressWarnings("unchecked")
	public List<MitraSearchResult> advanceMitraSearch() {

		String nativeQuery = "SELECT distinct\n"
				+ "    el.loc_ID AS locstateVal,\n"
				+ "    el.loc_name AS state,\n"
				+ "    COUNT(USER_ID) AS mitraCount\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            DISTINCT HOSP_ID,USER_ID\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,EHFM_USERS EU\n"
				+ "        WHERE\n"
				+ "                ehmd.end_dt IS NULL\n"
				+ "            AND ehmd.scheme = 'CD201'\n"
				+ "            AND eu.SERVICE_FLG='Y'\n"
				+ "            AND eu.USER_TYPE='CD201'\n"
				+ "            AND ehmd.MITHRA_ID=EU.USER_ID\n"
				+ "    ) ehmd\n"
				+ "WHERE\n"
				+ "          es.state_code = el.loc_id\n"
				+ "    AND   el.loc_hdr_id = 'LH1'\n"
				+ "    AND   es.hosp_active_yn = 'Y'\n"
				+ "    AND   ES.scheme = 'CD201'\n"
				+ "    AND   es.HOSP_ID=EHMD.HOSP_ID\n"
				+ "    --and   es.STATE_CODE='S35'\n"
				+ "    GROUP BY el.loc_name,el.loc_ID";
		Query query = em.createNativeQuery(nativeQuery, MitraSearchResult.class);
		List<MitraSearchResult> searchResults = query.getResultList();
		return searchResults;
	}
	
	@SuppressWarnings("unchecked")
	public List<MitraDistrictWiseCountResult> advanceMitraDistrictWiseCount(AdvanceMitraDistrictCount request) {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    el.loc_id districtId,\n"
				+ "    loc_name district,\n"
				+ "    count(ehmd.mithra_id) as mitraCount\n"
				+ "FROM\n"
				+ "    ehfm_hosp_mithra_dtls ehmd,\n"
				+ "    ehfm_users eu,\n"
				+ "    ehfm_hospitals eh,\n"
				+ "    ehfm_locations el\n"
				+ "WHERE\n"
				+ "    ehmd.end_dt IS NULL\n"
				+ "    AND   ehmd.scheme = 'CD201'\n"
				+ "    AND   service_flg = 'Y'\n"
				+ "    AND   user_type = 'CD201'\n"
				+ "    AND   ehmd.mithra_id = eu.user_id\n"
				+ "    AND   ehmd.hosp_id = eh.hosp_id\n"
				+ "    AND   eh.hosp_active_yn = 'Y'\n"
				+ "    AND   eh.scheme = 'CD201'\n";
		if(request.getStateid()!=null) {
				nativeQuery=nativeQuery+" AND eh.state_code='"+request.getStateid()+"'";
		}
		nativeQuery = nativeQuery+"AND   eh.hosp_dist = el.loc_id\n"
				+ "    group by  el.loc_id,loc_name ";
		
		
		Query query = em.createNativeQuery(nativeQuery, MitraDistrictWiseCountResult.class);

		List<MitraDistrictWiseCountResult> searchResults = query.getResultList();
				
		return searchResults;
				

	}
	
	@SuppressWarnings("unchecked")
	public List<MitraDistrictResult> advanceMitraDistrictCount() {

		String nativeQuery ="SELECT DISTINCT\n"
				+ "    replace(eu.first_name\n"
				+ "    || ' '\n"
				+ "    || eu.middle_name\n"
				+ "    || ' '\n"
				+ "    || eu.last_name,',','<br/>') AS mitraName,\n"
				+ "    replace(eu.mobile_no,',','<br/>') AS mitraContact,\n"
				+ "    es.loc_name AS district,\n"
				+ "    es.hosp_id hospitalId,\n"
				+ "    esu.hosp_name hospitalName,\n"
				+ "    replace(esu.specialities,',','<br/>') Speciality\n"
				+ "FROM\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            *\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,\n"
				+ "            ehfm_users eu\n"
				+ "        WHERE\n"
				+ "            end_dt IS NULL\n"
				+ "            AND   scheme = 'CD201'\n"
				+ "            AND   service_flg = 'Y'\n"
				+ "            AND   user_type = 'CD201'\n"
				+ "            AND   ehmd.mithra_id = eu.user_id\n"
				+ "    ) eu,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            *\n"
				+ "        FROM\n"
				+ "            ehfm_hospitals es,\n"
				+ "            ehfm_locations el\n"
				+ "        WHERE\n"
				+ "            es.hosp_dist = el.loc_id\n"
				+ "            AND   es.hosp_active_yn = 'Y'\n"
				+ "            AND   es.scheme = 'CD201'\n"
				+ "            AND   loc_hdr_id = 'LH6'\n"
				+ "    ) es,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            es.hosp_id,\n"
				+ "            es.hosp_name,\n"
				+ "            LISTAGG(ehs.icd_cat_code,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                ehs.icd_cat_code\n"
				+ "            ) AS specialities\n"
				+ "        FROM\n"
				+ "            ehfm_hospitals es,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    *\n"
				+ "                FROM\n"
				+ "                    ehfm_hosp_speciality\n"
				+ "                WHERE\n"
				+ "                    is_active_flg = 'Y'\n"
				+ "                    AND   phase_id = '1'\n"
				+ "                    AND   renewal = '1'\n"
				+ "                    AND   scheme_id = 'CD201'\n"
				+ "            ) ehs\n"
				+ "        WHERE\n"
				+ "            es.hosp_active_yn = 'Y'\n"
				+ "            AND   es.scheme = 'CD201'\n"
				+ "            AND   es.hosp_id = ehs.hosp_id (+)\n"
				+ "        GROUP BY\n"
				+ "            es.hosp_id,es.hosp_name\n"
				+ "    ) esu\n"
				+ "WHERE\n"
				+ "    es.hosp_id = eu.hosp_id\n"
				+ "    AND   es.hosp_id = esu.hosp_id";
		
		Query query = em.createNativeQuery(nativeQuery, MitraDistrictResult.class);

		List<MitraDistrictResult> searchResults = query.getResultList();
				
		return searchResults;

	}
	//done
	@SuppressWarnings("unchecked")
	public List<CountSearchSpecialityResult> advanceCountSpecialitySearch(AdvanceCountSpecialitySearch request) {


		String nativeQuery = "SELECT\r\n"
				+ "    DISTINCT\r\n"
				+ "    upper(b.dis_main_name|| ' ( '|| b.dis_main_id|| ' )') speciality,\r\n"
				+ "    SUM(a.procedures_count) proceduresCount,\r\n"
				+ "    SUM(b.hospitals_count) hospitalsCount\r\n"
				+ "FROM\r\n"
				+ "    (\r\n"
				+ "        SELECT\r\n"
				+ "            asri_code,\r\n"
				+ "            COUNT(DISTINCT icd_proc_code) AS procedures_count\r\n"
				+ "        FROM\r\n"
				+ "            ehfm_main_therapy\r\n"
				+ "        WHERE\r\n"
				+ "            active_yn = 'Y'\r\n"
				+ "            AND   state = 'CD201'\r\n"
				+ "        GROUP BY\r\n"
				+ "            asri_code\r\n"
				+ "    ) a,\r\n"
				+ "    (\r\n"
				+ "        SELECT\r\n"
				+ "            dis_main_id,\r\n"
				+ "            dis_main_name,\r\n"
				+ "            COUNT(DISTINCT ehs.hosp_id) AS hospitals_count\r\n"
				+ "        FROM\r\n"
				+ "            ehfm_hosp_speciality ehs,\r\n"
				+ "            ehfm_specialities es,\r\n"
				+ "            ehfm_hospitals eh\r\n"
				+ "        WHERE\r\n"
				+ "            is_active_flg = 'Y'\r\n"
				+ "            AND scheme_id = 'CD201'\r\n"
				+ "            AND ehs.icd_cat_code = es.dis_main_id\r\n"
				+ "            and eh.hosp_id=ehs.hosp_id\r\n"
				+ "            and eh.HOSP_ACTIVE_YN='Y'\r\n"
				+ "            AND eh.SCHEME='CD201'\r\n"
				+ "            AND eh.hosp_type IN ('G','C')\r\n";
				if(request.getSpecialityId()!=null)
				nativeQuery=nativeQuery+ " and es.dis_main_id='"+request.getSpecialityId()+"'\n";
				nativeQuery=nativeQuery+"        GROUP BY\r\n"
				+ "            dis_main_id,\r\n"
				+ "            dis_main_name\r\n"
				+ "    ) b\r\n"
				+ "WHERE\r\n"
				+ "    a.asri_code = b.dis_main_id\r\n"
				+ "    group by upper(b.dis_main_name|| ' ( '|| b.dis_main_id|| ' )')";

		Query query = em.createNativeQuery(nativeQuery);
		List<Object[]> searchResults=query.getResultList();
		List<CountSearchSpecialityResult> searchResults1 = new ArrayList<>();
		for(int i=0;i<searchResults.size();i++) {
			
			CountSearchSpecialityResult res=new CountSearchSpecialityResult();
			if(null != searchResults.get(i)[0]) {
			res.setSpeciality(searchResults.get(i)[0].toString());}
			if(null != searchResults.get(i)[1]) {
			res.setProceduresCount(searchResults.get(i)[1].toString());}
			if(null != searchResults.get(i)[2]) {
			res.setHospitalsCount(searchResults.get(i)[2].toString());}
			searchResults1.add(res);
		}

		return searchResults1;


	}
	@SuppressWarnings("unchecked")
	public List<SpecialitySearchHospitalResult> advanceHospitalSearch(@RequestBody AdvanceSpecialitySearchHospital request){
		
//		String nativeQuery="SELECT DISTINCT\n"
//				+ "    es.hosp_name hospitalName,\n"
//				+ "    es.hosp_type hospitalType,\n"
//				+ "    el.loc_name AS district,\n"
//				+ "    es.HOUSE_NO||','|| es.STREET  address,\n"
//				+ "    replace(LISTAGG(dis_main_name,',') WITHIN GROUP(ORDER BY dis_main_name),',','<br/>') AS specialities,\n"
//				+ "    replace(name_of_medco ,',','<br/>') medcoName,\n"
//				+ "    replace(medco_contact_number ,',','<br/>') medcoContact,\n"
//				+ "    replace(name_of_mitra ,',','<br/>') mitraName,\n"
//				+ "    replace(mitra_contact_number ,',','<br/>') mitraContact\n"
//				+ "FROM\n"
//				+ "    ehfm_hospitals es,\n"
//				+ "    ehfm_locations el,\n"
//				+ "    (\n"
//				+ "        SELECT DISTINCT\n"
//				+ "            ehs.hosp_id,\n"
//				+ "            LISTAGG(eu.first_name\n"
//				+ "            || ' '\n"
//				+ "            || eu.middle_name\n"
//				+ "            || ' '\n"
//				+ "            || eu.last_name,\n"
//				+ "            ',') WITHIN GROUP(\n"
//				+ "            ORDER BY\n"
//				+ "                eu.first_name\n"
//				+ "                || ' '\n"
//				+ "                || eu.middle_name\n"
//				+ "                || ' '\n"
//				+ "                || eu.last_name\n"
//				+ "            ) AS name_of_mitra,\n"
//				+ "            LISTAGG(eu.mobile_no,\n"
//				+ "            ',') WITHIN GROUP(\n"
//				+ "            ORDER BY\n"
//				+ "                eu.mobile_no\n"
//				+ "            ) AS mitra_contact_number\n"
//				+ "        FROM\n"
//				+ "            ehfm_hosp_mithra_dtls ehmd,\n"
//				+ "            ehfm_users eu,\n"
//				+ "            ehfm_hospitals ehs\n"
//				+ "        WHERE\n"
//				+ "            ehmd.end_dt IS NULL\n"
//				+ "            AND   ehmd.scheme = 'CD201'\n"
//				+ "            AND   eu.service_flg = 'Y'\n"
//				+ "            AND   eu.user_type = 'CD201'\n"
//				+ "            AND   ehmd.mithra_id = eu.user_id\n"
//				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
//				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
//				+ "            AND   ehs.scheme = 'CD201'\n"
//				+ "            AND   ehs.hosp_type IN (\n"
//				+ "                'G',\n"
//				+ "                'C'\n"
//				+ "            )\n"
//				+ "        GROUP BY\n"
//				+ "            ehs.hosp_id\n"
//				+ "    ) ehmd,\n"
//				+ "    (\n"
//				+ "        SELECT DISTINCT\n"
//				+ "            ehs.hosp_id,\n"
//				+ "            LISTAGG(eu.first_name\n"
//				+ "            || ' '\n"
//				+ "            || eu.middle_name\n"
//				+ "            || ' '\n"
//				+ "            || eu.last_name,\n"
//				+ "            ',') WITHIN GROUP(\n"
//				+ "            ORDER BY\n"
//				+ "                eu.first_name\n"
//				+ "                || ' '\n"
//				+ "                || eu.middle_name\n"
//				+ "                || ' '\n"
//				+ "                || eu.last_name\n"
//				+ "            ) AS name_of_medco,\n"
//				+ "            LISTAGG(eu.mobile_no,\n"
//				+ "            ',') WITHIN GROUP(\n"
//				+ "            ORDER BY\n"
//				+ "                eu.mobile_no\n"
//				+ "            ) AS medco_contact_number\n"
//				+ "        FROM\n"
//				+ "            ehfm_medco_dtls ehmd,\n"
//				+ "            ehfm_users eu,\n"
//				+ "            ehfm_hospitals ehs\n"
//				+ "        WHERE\n"
//				+ "            ehmd.end_dt IS NULL\n"
//				+ "            AND   ehmd.scheme = 'CD201'\n"
//				+ "            AND   eu.service_flg = 'Y'\n"
//				+ "            AND   eu.user_type = 'CD201'\n"
//				+ "            AND   ehmd.medco_id = eu.user_id\n"
//				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
//				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
//				+ "            AND   ehs.scheme = 'CD201'\n"
//				+ "            AND   ehs.hosp_type IN (\n"
//				+ "                'G',\n"
//				+ "                'C'\n"
//				+ "            )\n"
//				+ "        GROUP BY\n"
//				+ "            ehs.hosp_id\n"
//				+ "    ) emd,\n"
//				+ "    (\n"
//				+ "        SELECT DISTINCT\n"
//				+ "            ehs.hosp_id,\n"
//				+ "            ess.dis_main_name,\n"
//				+ "            ess.dis_main_id\n"
//				+ "        FROM\n"
//				+ "            ehfm_hosp_speciality ehs,\n"
//				+ "            ehfm_specialities ess,\n"
//				+ "            ehfm_hospitals eh\n"
//				+ "        WHERE\n"
//				+ "            ehs.is_active_flg = 'Y'\n"
//				+ "            AND   ehs.phase_id = '1'\n"
//				+ "            AND   ehs.renewal = '1'\n"
//				+ "            AND   ehs.scheme_id = 'CD201'\n"
//				+ "            AND   ess.dis_main_id = ehs.icd_cat_code\n"
//				+ "            AND   ess.dis_active_yn = 'Y'\n"
//				+ "            AND   ehs.hosp_id = eh.hosp_id\n"
//				+ "            AND   eh.hosp_active_yn = 'Y'\n"
//				+ "            AND   eh.scheme = 'CD201'\n"
//				+ "            AND   eh.hosp_type IN (\n"
//				+ "                'G',\n"
//				+ "                'C'\n"
//				+ "            )\n"
//				+ "    ) ehs\n"
//				+ "WHERE\n"
//				+ "    es.hosp_dist = el.loc_id\n"
//				+ "    AND   es.hosp_active_yn = 'Y'\n"
//				+ "    AND   es.scheme = 'CD201'\n"
//				+ "    AND   loc_hdr_id = 'LH6'\n"
//				+ "    AND   es.hosp_type IN (\n"
//				+ "        'G',\n"
//				+ "        'C'\n"
//				+ "    )\n"
//				+ "    AND   ehs.hosp_id (+) = es.hosp_id\n"
//				+ "    AND   es.hosp_id = ehmd.hosp_id (+)\n"
//				+ "    AND   es.hosp_id = emd.hosp_id (+)\n"
//				+ "    --AND   dis_main_id='S18'\n"
//				+ "GROUP BY\n"
//				+ "    es.hosp_name,\n"
//				+ "    es.hosp_type,\n"
//				+ "    el.loc_name,\n"
//				+ "    es.house_no||','|| es.street,\n"
//				+ "    name_of_medco,\n"
//				+ "    medco_contact_number,\n"
//				+ "    name_of_mitra,\n"
//				+ "    mitra_contact_number";
		
		String nativeQuery="SELECT DISTINCT\n"
				+ "    es.hosp_name hospitalName,\n"
				+ "    es.hosp_type hospitalType,\n"
				+ "    els.loc_name as state,\n"
				+ "    el.loc_name AS district,\n"
				+ "    elss.loc_name as mandal,\n"
				+ "    es.HOUSE_NO||','|| es.STREET  address,\n"
				+ "    replace(LISTAGG(dis_main_name,',') WITHIN GROUP(ORDER BY dis_main_name) ,',','<br/>') AS specialities,\n"
				+ "    replace(name_of_medco ,',','<br/>') medcoName,\n"
				+ "    replace(medco_contact_number ,',','<br/>') medcoContact,\n"
				+ "    replace(name_of_mitra ,',','<br/>') mitraName,\n"
				+ "    replace(mitra_contact_number ,',','<br/>') mitraContact\n"
				+ "FROM\n"
				+ "    ehfm_hospitals es,\n"
				+ "    ehfm_locations el,\n"
				+ "    EHFM_LOCATIONS els,\n"
				+ "    ehf_empnl_hospinfo eeh,\n"
				+ "    EHFM_LOCATIONS elss,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "             ||' '||\n"
				+ "             eu.middle_name\n"
				+ "             ||' '||\n"
				+ "             eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                 ||' '||\n"
				+ "                 eu.middle_name\n"
				+ "                 ||' '||\n"
				+ "                 eu.last_name\n"
				+ "            ) AS name_of_mitra,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS mitra_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_mithra_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.mithra_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN (\n"
				+ "                'G',\n"
				+ "                'C'\n"
				+ "            )\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) ehmd,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            LISTAGG(eu.first_name\n"
				+ "             ||' '||\n"
				+ "             eu.middle_name\n"
				+ "             ||' '||\n"
				+ "             eu.last_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.first_name\n"
				+ "                 ||' '||\n"
				+ "                 eu.middle_name\n"
				+ "                 ||' '||\n"
				+ "                 eu.last_name\n"
				+ "            ) AS name_of_medco,\n"
				+ "            LISTAGG(eu.mobile_no,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                eu.mobile_no\n"
				+ "            ) AS medco_contact_number\n"
				+ "        FROM\n"
				+ "            ehfm_medco_dtls ehmd,\n"
				+ "            ehfm_users eu,\n"
				+ "            ehfm_hospitals ehs\n"
				+ "        WHERE\n"
				+ "            ehmd.end_dt IS NULL\n"
				+ "            AND   ehmd.scheme = 'CD201'\n"
				+ "            AND   eu.service_flg = 'Y'\n"
				+ "            AND   eu.user_type = 'CD201'\n"
				+ "            AND   ehmd.medco_id = eu.user_id\n"
				+ "            AND   ehs.hosp_id = ehmd.hosp_id\n"
				+ "            AND   ehs.hosp_active_yn = 'Y'\n"
				+ "            AND   ehs.scheme = 'CD201'\n"
				+ "            AND   ehs.hosp_type IN (\n"
				+ "                'G',\n"
				+ "                'C'\n"
				+ "            )\n"
				+ "        GROUP BY\n"
				+ "            ehs.hosp_id\n"
				+ "    ) emd,\n"
				+ "    (\n"
				+ "        SELECT DISTINCT\n"
				+ "            ehs.hosp_id,\n"
				+ "            ess.dis_main_name,\n"
				+ "            ess.dis_main_id\n"
				+ "        FROM\n"
				+ "            ehfm_hosp_speciality ehs,\n"
				+ "            ehfm_specialities ess,\n"
				+ "            ehfm_hospitals eh\n"
				+ "        WHERE\n"
				+ "            ehs.is_active_flg = 'Y'\n"
				+ "            AND   ehs.phase_id = '1'\n"
				+ "            AND   ehs.renewal = '1'\n"
				+ "            AND   ehs.scheme_id = 'CD201'\n"
				+ "            AND   ess.dis_main_id = ehs.icd_cat_code\n"
				+ "            AND   ess.dis_active_yn = 'Y'\n"
				+ "            AND   ehs.hosp_id = eh.hosp_id\n"
				+ "            AND   eh.hosp_active_yn = 'Y'\n"
				+ "            AND   eh.scheme = 'CD201'\n"
				+ "            AND   eh.hosp_type IN (\n"
				+ "                'G',\n"
				+ "                'C'\n"
				+ "            )\n"
				+ "    ) ehs\n"
				+ "WHERE\n"
				+ "    es.hosp_dist = el.loc_id\n"
				+ "    AND   es.hosp_active_yn = 'Y'\n"
				+ "    AND   es.scheme = 'CD201'\n"
				+ "    AND   el.loc_hdr_id = 'LH6'\n"
				+ "    AND   es.hosp_type IN (\n"
				+ "        'G',\n"
				+ "        'C'\n"
				+ "    )\n"
				+ "    AND   ehs.hosp_id (+) = es.hosp_id\n"
				+ "    AND   es.hosp_id = ehmd.hosp_id (+)\n"
				+ "    AND   es.hosp_id = emd.hosp_id (+)\n"
				+ "    --AND   dis_main_id='S18'\n"
				+ "    and es.STATE_CODE=els.loc_id\n"
				+ "    and es.HOSP_EMPNL_REF_NUM=eeh.HOSPINFO_ID\n"
				+ "    and eeh.MANDAL=elss.loc_id(+)\n"
				+ "GROUP BY\n"
				+ "    es.hosp_name,\n"
				+ "    es.hosp_type,\n"
				+ "    el.loc_name,\n"
				+ "    es.house_no||','|| es.street,\n"
				+ "    name_of_medco,\n"
				+ "    medco_contact_number,\n"
				+ "    name_of_mitra,\n"
				+ "    mitra_contact_number,\n"
				+ "    els.loc_name,\n"
				+ "    elss.loc_name";
		
				Query query = em.createNativeQuery(nativeQuery);
				List<Object[]> searchResults=query.getResultList();
				List<SpecialitySearchHospitalResult> searchResults1 = new ArrayList<>();
				for(int i=0;i<searchResults.size();i++)
				{
					//searchResults.get(i)[1].toString()
					SpecialitySearchHospitalResult res=new SpecialitySearchHospitalResult();
					if(null != searchResults.get(i)[0]) {
					res.setHospitalName(searchResults.get(i)[0].toString());}
					if(null != searchResults.get(i)[1]) {
					res.setHospitalType(searchResults.get(i)[1].toString());}
					if(null != searchResults.get(i)[2]) {
						res.setState(searchResults.get(i)[2].toString());}
					if(null != searchResults.get(i)[3]) {
					res.setDistrict(searchResults.get(i)[3].toString());}
					if(null != searchResults.get(i)[4]) {
						res.setMandal(searchResults.get(i)[4].toString());}
					if(null != searchResults.get(i)[5]) {
					res.setAddress(searchResults.get(i)[5].toString());}
					if(null != searchResults.get(i)[6]) {
						res.setSpecialities(searchResults.get(i)[6].toString());}
					if(null != searchResults.get(i)[7]) {
						res.setMedcoName(searchResults.get(i)[7].toString());}
					if(null != searchResults.get(i)[8]) {
						res.setMedcoContact(searchResults.get(i)[8].toString());}
					if(null != searchResults.get(i)[9]) {
						res.setMitraName(searchResults.get(i)[9].toString());}
					if(null != searchResults.get(i)[10]) {
						res.setMitraContact(searchResults.get(i)[10].toString());}
					searchResults1.add(res);
				}
				return searchResults1;

	
	
}
	@SuppressWarnings("unchecked")
	public List<StateListResult> displayStateList() {

		String nativeQuery ="SELECT LOC_ID AS stateId, LOC_NAME AS stateName from EHFM_LOCATIONS where LOC_HDR_ID = 'LH1' ";

		Query query = em.createNativeQuery(nativeQuery);
		List<Object[]> searchResults=query.getResultList();
		List<StateListResult> searchResults1 = new ArrayList<>();
		for(int i=0;i<searchResults.size();i++)
		{
			StateListResult res=new StateListResult();
			if(null != searchResults.get(i)[0]) {
			res.setStateId(searchResults.get(i)[0].toString());}	
			if(null != searchResults.get(i)[1]) {
			res.setStateName(searchResults.get(i)[1].toString());}//Procedure Code
			searchResults1.add(res);
		}
		return searchResults1;
		//List<StateListResult> searchResults = query.getResultList();		

		//return searchResults;
		

	}
	
	@SuppressWarnings("unchecked")
	public List<DistrictListResult> displayDistrictList(AdvanceDistrictList request) {

		String nativeQuery = "select * from (\n"
				+ "SELECT DISTINCT STATE_CODE AS stateId, LOC_ID AS districtId,  EL.LOC_NAME AS districtName FROM EHFM_HOSPITALS EH, EHFM_LOCATIONS EL\n"
				+ "\n"
				+ "WHERE HOSP_ACTIVE_YN='Y'   --- Fetch Districts\n"
				+ "\n"
				+ "AND EH.HOSP_DIST = EL.LOC_ID AND  EL.LOC_HDR_ID='LH6' AND EH.SCHEME IN ('CD201','CD202') ORDER BY STATE_CODE)";
			 if(request.getStateId()!=null) {
				 nativeQuery=nativeQuery+"  where stateId='"+request.getStateId()+"'";
				 }
			
		//Query query = em.createNativeQuery(nativeQuery, DistrictListResult.class);


		//List<DistrictListResult> searchResults = query.getResultList();		

		//return searchResults;
				Query query = em.createNativeQuery(nativeQuery);
				List<Object[]> searchResults=query.getResultList();
				List<DistrictListResult> searchResults1 = new ArrayList<>();
				for(int i=0;i<searchResults.size();i++)
				{
					DistrictListResult res=new DistrictListResult();
					if(null != searchResults.get(i)[0]) {
					res.setStateId(searchResults.get(i)[0].toString());}	
					if(null != searchResults.get(i)[1]) {
					res.setDistrictId(searchResults.get(i)[1].toString());}//Procedure Code
					if(null != searchResults.get(i)[2]) {
					res.setDistrictName(searchResults.get(i)[2].toString());}//Procedure Code
					searchResults1.add(res);
				}
				return searchResults1;

	}
	@SuppressWarnings("unchecked")
	public List<MandalListResult> displayMandalList(AdvanceMandalList request) {
		// TODO Auto-generated method stub
		
		String nativeQuery="Select * from(\r\n"
				+ "SELECT DISTINCT  STATE_CODE AS stateId, LOC_ID AS mandalId, DISTRICT_CODE AS districtId, EL.LOC_NAME AS mandal FROM EHF_EMPNL_HOSPINFO EH, EHFM_LOCATIONS EL\r\n"
				+ "WHERE EH.MANDAL = EL.LOC_ID\r\n"
				+ "AND LOC_HDR_ID = 'LH7')\r\n";
				if(request.getDistrictId()!=null)
				nativeQuery=nativeQuery+"where districtId='"+request.getDistrictId()+"'";
				
				
		
				Query query = em.createNativeQuery(nativeQuery);
				List<Object[]> searchResults=query.getResultList();
				List<MandalListResult> searchResults1 = new ArrayList<>();
				for(int i=0;i<searchResults.size();i++)
				{
					MandalListResult res=new MandalListResult();
					if(null != searchResults.get(i)[0]) {
					res.setStateId(searchResults.get(i)[0].toString());}	
					if(null != searchResults.get(i)[1]) {
					res.setMandalId(searchResults.get(i)[1].toString());}
					if(null != searchResults.get(i)[2]) {
					res.setDistrictId(searchResults.get(i)[2].toString());}
					if(null != searchResults.get(i)[3]) {
						res.setMandal(searchResults.get(i)[3].toString());}
					searchResults1.add(res);
				}
				return searchResults1;
	}
	
	@SuppressWarnings("unchecked")
	public List<SearchProcedureSpecialityResult> advanceProcedureSpecialitySearch(AdvanceProcedureSpecialitySearch request){
		
		String nativeQuery ="SELECT DISTINCT\r\n"
				+ "    c.dis_main_id AS specialitycode,\r\n"
				+ "    c.dis_main_name AS specialityname,\r\n"
				+ "    a.icd_proc_code AS proceduretype,\r\n"
				+ "    a.proc_name AS procedurename,\r\n"
				+ "    a.hosp_stay_amt + a.common_cat_amt + a.icd_amt AS packageamount,\r\n"
				+ "    replace(invest_name,',','<br/>') AS preinvestigations\r\n"
				+ "FROM\r\n"
				+ "    ehfm_main_therapy a,\r\n"
				+ "    ehfm_specialities c,\r\n"
				+ "    (\r\n"
				+ "        SELECT\r\n"
				+ "            eti.icd_proc_code,\r\n"
				+ "            LISTAGG(invest_desc,\r\n"
				+ "            ',') WITHIN GROUP(\r\n"
				+ "            ORDER BY\r\n"
				+ "                invest_desc\r\n"
				+ "            ) AS invest_name\r\n"
				+ "        FROM\r\n"
				+ "            ehfm_therapy_invest eti\r\n"
				+ "        WHERE\r\n"
				+ "            active_yn = 'Y'\r\n"
				+ "            AND   scheme_id = 'CD201'\r\n"
				+ "        GROUP BY\r\n"
				+ "            eti.icd_proc_code\r\n"
				+ "    ) eti\r\n"
				+ "    WHERE\r\n"
				+ "    a.active_yn = 'Y'\r\n"
				+ "    AND   a.state = 'CD201'\r\n";
				if(request.getSpecialityId()!=null)
					nativeQuery=nativeQuery+ " AND   a.asri_code = '"+request.getSpecialityId()+"' \n"
				+ "    AND   c.dis_main_id = a.asri_code\r\n"
				+ "    AND   c.dis_active_yn = 'Y'\r\n"
				+ "    and   PROCESS ='IP'\r\n"
				+ "    AND   a.icd_cat_code = eti.icd_proc_code (+)\r\n"
				+ "ORDER BY\r\n"
				+ "    c.dis_main_name";
			

		Query query = em.createNativeQuery(nativeQuery);
		List<Object[]> searchResults=query.getResultList();
		List<SearchProcedureSpecialityResult> searchResults1 = new ArrayList<>();
		for(int i=0;i<searchResults.size();i++)
		{
			SearchProcedureSpecialityResult res=new SearchProcedureSpecialityResult();
			if(null != searchResults.get(i)[0]) {
			res.setSpecialityCode(searchResults.get(i)[0].toString());}//Speciality code
			if(null != searchResults.get(i)[1]) {
			res.setSpecialityName(searchResults.get(i)[1].toString());}//Speciality Name
			if(null != searchResults.get(i)[2]) {
			res.setProcedureType(searchResults.get(i)[2].toString());}//Procedure Code
			if(null != searchResults.get(i)[3]) {
			res.setProcedureName(searchResults.get(i)[3].toString());}//Procedure Name
			if(null != searchResults.get(i)[4]) {
				res.setPackageAmount(searchResults.get(i)[4].toString());}// Packages
			if(null != searchResults.get(i)[5]) {
				res.setPreInvestigations(searchResults.get(i)[5].toString());}//Investigation Name
			searchResults1.add(res);
		}
		return searchResults1;
	}
	
}
*/