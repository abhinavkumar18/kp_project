package in.kpmg.mr.ysrempanelment.dtos.common;

public interface SpecialityCodeResult {
    String getSpecialityCode();
    String getSpecialityName();
    Long getSpecialityId();
}
