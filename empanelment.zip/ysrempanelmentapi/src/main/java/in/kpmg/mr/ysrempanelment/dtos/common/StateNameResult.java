package in.kpmg.mr.ysrempanelment.dtos.common;

public interface StateNameResult {
    Number getValueId();
    String getValueName();
}
