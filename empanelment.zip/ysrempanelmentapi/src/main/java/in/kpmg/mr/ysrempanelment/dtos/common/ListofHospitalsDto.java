package in.kpmg.mr.ysrempanelment.dtos.common;

public interface ListofHospitalsDto {
	String getHospRegId();
	String getHospName();

}
