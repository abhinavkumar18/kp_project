package in.kpmg.mr.ysrempanelment.models.common;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;
@Entity
@Data
@Table(name="empnl_general_infrastructure")
public class EmpnlGeneralInfrastructure {
	@Id 
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="infra_id")
    private Integer infraId;
    
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "qst_id", referencedColumnName = "qst_id")
    private EmpnlQstMaster qstId;
    
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "empanl_id", referencedColumnName = "empanl_id") 
//    @Column(name="empanl_id")
    private GeneralDetails empanlId;
   
    @Column(name="numbers")
    private Long numbers;
    
    @Column(name="area")
    private Long area;
    
    @Column(name="avalability")
    private Character availability;
    
    @Column(name="is_active")
    private Boolean isActive;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "crt_by", referencedColumnName = "user_id")
    private YsrUserMaster crtBy;
    
    @Column(name = "crt_on")
    @CreationTimestamp
    private Timestamp crtOn;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "upd_by", referencedColumnName = "user_id")
    private YsrUserMaster updBy;
    
    @Column(name = "upd_on")
    @UpdateTimestamp
    private Timestamp updOn;
    
}
