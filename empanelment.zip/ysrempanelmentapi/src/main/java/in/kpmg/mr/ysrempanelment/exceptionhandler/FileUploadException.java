package in.kpmg.mr.ysrempanelment.exceptionhandler;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

    @ControllerAdvice
    public class FileUploadException extends ResponseEntityExceptionHandler {

        @ExceptionHandler(MaxUploadSizeExceededException.class)
        public ApiResponse handleMaxSizeException(MaxUploadSizeExceededException exc) {
            return new ApiResponse(false, "File size is too large!", "failure", 400);
        }
    }

