package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "EMPNL_DOC_TYPE_MASTER")
public class DocTypeMaster {
    @Id
    @Column(name = "DOC_ID")
    private long id;
    @Column(name = "DOC_NAME")
    private String nameOfDocuments;
    @Column(name = "ISSUING_AUTHORITY")
    private String issuingAuthority;
    @Column(name = "IS_MANDATORY")
    private Boolean isMandatory;
    @Column(name = "EXPIRY_DT_APPLI_YN")
    private char expiryDateOfApplication;
    @Column(name = "SAMPLE_FILE")
    private String sampleFile;
    @Column(name = "IS_ACTIVE_YN")
    private Boolean isActive;
}
