package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import java.sql.Timestamp;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;


@Entity
@Data
@Table(name="ysr_user_mst")
public class YsrUserMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Integer userId;

	@Column(name = "login_name")
	private String userName;

	@Column(name = "emp_code")
	private String empCode;

	@Column(name = "pswd")
	@JsonIgnore
	private String password;

	@Column(name = "user_name")
	private String fullname;

	@Column(name = "email_id")
	private String email;

	@Column(name = "mobile_no")
	private Long mobileNo;

	@Column(name = "crt_by")
	private Integer createdBy;
	
	@Column(name = "crt_on")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm aa", timezone = "Asia/Kolkata")
	@CreationTimestamp
	private Timestamp createdOn;

	@Column(name = "upd_by")
	private Integer updatedBy;

	@Column(name = "upd_on")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm aa", timezone = "Asia/Kolkata")
	@UpdateTimestamp
	private Timestamp updatedOn;

	@Column(name = "is_active")
	private Boolean isActive;

	@Column(name = "reporting_person_id")
	private Integer managerId;

	@Column(name = "cfms_id")
	private String cfmsId;
	
	@Column(name = "pan_card")
	private String pancard;
}
