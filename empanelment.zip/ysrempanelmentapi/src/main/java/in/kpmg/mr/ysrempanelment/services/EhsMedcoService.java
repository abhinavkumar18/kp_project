//package in.kpmg.mr.ysrempanelment.services;
//
//import in.kpmg.mr.ysrempanelment.dtos.common.*;
//import in.kpmg.mr.ysrempanelment.models.common.EhsAisMrMaster;
//import in.kpmg.mr.ysrempanelment.models.common.EhsClaimDetailsModel;
//import in.kpmg.mr.ysrempanelment.models.common.EhsClaimDocModel;
//import in.kpmg.mr.ysrempanelment.repositories.common.EhsAisMrRepo;
//import in.kpmg.mr.ysrempanelment.repositories.common.EhsClaimDetailsRepo;
//import in.kpmg.mr.ysrempanelment.repositories.common.EhsClaimDocRepo;
//import in.kpmg.mr.ysrempanelment.util.SaveDocumentsUtil;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//import org.springframework.util.StringUtils;
//import org.springframework.web.multipart.MultipartFile;
//
//import javax.validation.constraints.Max;
//import java.sql.Date;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.CONTENT_TYPE;
//
//@Service
//@Slf4j
//public class EhsMedcoService {
//
//
//    @Autowired
//    SaveDocumentsUtil saveDocuments;
//    @Autowired
//    EhsAisMrRepo ehsAisMrRepo;
//
//    @Autowired
//    EhsClaimDocRepo ehsClaimDocRepo;
//
//    @Autowired
//    EhsClaimDetailsRepo ehsClaimDetailsRepo;
//    public ApiResponseDto fetchdatawithid(String trustId) {
//        try {
//            EHsMedcoDTO eHsMedcoDTO = new EHsMedcoDTO();
//            EhsAisMrMaster ehsAisMrMaster = ehsAisMrRepo.findById(Long.valueOf(trustId)).get();
////            if(ehsAisMrMaster.getIS_INITIATED().equals('N')) {
//
//                eHsMedcoDTO.setLocNo(ehsAisMrMaster.getLOC_NUMBER());
//                eHsMedcoDTO.setLocAmount(String.valueOf(ehsAisMrMaster.getLOC_AMOUNT()));
//                eHsMedcoDTO.setLocPhoto(ehsAisMrMaster.getLOC_PHOTO());
//                eHsMedcoDTO.setEmployeeType("AIS Officer");
//                eHsMedcoDTO.setDateofRegistration(String.valueOf(ehsAisMrMaster.getDATE_OF_REGISTRATION()).substring(0, 10));
//                eHsMedcoDTO.setEmployeeName(ehsAisMrMaster.getEMPLOYEE_NAME());
//                eHsMedcoDTO.setMobileNumber(String.valueOf(ehsAisMrMaster.getCONTACT_NO()));
//                eHsMedcoDTO.setPatientName(ehsAisMrMaster.getPATIENT_NAME());
//                eHsMedcoDTO.setRelationWithEmployee(ehsAisMrMaster.getRELATION());
//                eHsMedcoDTO.setDOB(String.valueOf(ehsAisMrMaster.getPATIENT_DOB()).substring(0, 10));
//                eHsMedcoDTO.setAge(String.valueOf(ehsAisMrMaster.getAGE()));
//                eHsMedcoDTO.setGender(ehsAisMrMaster.getGENDER());
//                eHsMedcoDTO.setDistrict(ehsAisMrMaster.getDISTRICT());
//                eHsMedcoDTO.setState(ehsAisMrMaster.getSTATE());
//                eHsMedcoDTO.setEmployeeID(String.valueOf(ehsAisMrMaster.getEMP_ID()));
//                eHsMedcoDTO.setEmployeeDesignation(ehsAisMrMaster.getEMPLOYEE_DESIGNATION());
//                eHsMedcoDTO.setDepartmentName(ehsAisMrMaster.getDEPARTMENT_NAME());
//                eHsMedcoDTO.setPlaceOfWork(ehsAisMrMaster.getPLACE_OF_WORK());
//                eHsMedcoDTO.setPLaceOfDistrict(ehsAisMrMaster.getPLACE_OF_DISTRICT());
//
//
//            return new ApiResponseDto(true, "fetched Sucessfully", eHsMedcoDTO, HttpStatus.OK.value());
//        }catch (Exception e)
//        {
//            e.printStackTrace();
//            return new ApiResponseDto(false,"failed to fetch",e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR.value());
//        }
//    }
//
//    public ApiResponse<?> uploadfiles(List<MultipartFile> files, List<PayloadDTO> payloadDTOList) {
//
//        Boolean MaxSize = true;
//        Boolean MinSize = true;
//        Integer size = files.size();
//
////        if(payloadDTOList.get(0).getDocId().equals("0"))
////        {
////            if( files.size()>3)
////                MaxSize = false;
////            if(files.size()==0)
////                MinSize = false;
////        }
//        if(payloadDTOList.get(0).getDocId().equals("1"))
//            {
//                if( files.size()>3)
//                    MaxSize = false;
//                if(files.size()==0)
//                    MinSize = false;
//            }
//        if(payloadDTOList.get(0).getDocId().equals("2"))
//        {
//            if( files.size()>3)
//                MaxSize = false;
//            if(files.size()==0)
//                MinSize = false;
//        }
//        if(payloadDTOList.get(0).getDocId().equals("3"))
//        {
//            if( files.size()>3)
//                MaxSize = false;
//
//        }
//        if(payloadDTOList.get(0).getDocId().equals("4"))
//        {
//            if( files.size()>3)
//                MaxSize = false;
//            if(files.size()==0)
//                MinSize = false;
//        }
//        if(payloadDTOList.get(0).getDocId().equals("5"))
//        {
//            if( files.size()>3)
//                MaxSize = false;
//            if(files.size()==0)
//                MinSize = false;
//        }
//        if(payloadDTOList.get(0).getDocId().equals("7"))
//        {
//            if( files.size()>3)
//                MaxSize = false;
//            if(files.size()==0)
//                MinSize = false;
//        }
//        if(payloadDTOList.get(0).getDocId().equals("8")){
//            if( files.size()>3)
//                MaxSize = false;
//            if(files.size()==0)
//                MinSize = false;
//        }
//        if(MinSize==false)
//            return new ApiResponse<>(false,"Please attach Mandatory files","",HttpStatus.NO_CONTENT.value());
//        if(MaxSize==false)
//            return new ApiResponse<>(false,"Files Max limit exceeded","",HttpStatus.NO_CONTENT.value());
//
//        for (int i=0;i<files.size();i++) {
//            if(files.get(i).isEmpty() || payloadDTOList.get(i).getTrustId()==null)
//                return new ApiResponse<>(false,"Incorrect Payload","",HttpStatus.NO_CONTENT.value());
//            Boolean status;
//                 PayloadDTO payloadDTO = payloadDTOList.get(i);
////                 String Location = "C:\\multipartfile\\"+payloadDTOList.get(i).getTrustId()+"\\";
//                   String Location = "/storageNAS-AP-Production/OnlineMedicalReimbursementAttachment/"
//                   +payloadDTOList.get(i).getTrustId()+"/";
//            if (!CONTENT_TYPE.contains(files.get(i).getContentType()))
//                return new ApiResponse<>(false,"Incorrect File Format","",HttpStatus.NO_CONTENT.value());
//             if (CONTENT_TYPE.contains(files.get(i).getContentType())) {
//
//                 if(payloadDTO.getDocId().equals("5"))
//                     Location = Location+"Diagnosis-Reports";
//                 if(payloadDTO.getDocId().equals("1"))
//                     Location = Location+"Case-Sheet";
//                 if(payloadDTO.getDocId().equals("7"))
//                     Location = Location+"Discharge-Summary";
//                 if(payloadDTO.getDocId().equals("4"))
//                     Location = Location+"Detailed-Bill";
//                 if(payloadDTO.getDocId().equals("2"))
//                     Location = Location+"Consolidated-Bill";
//                 if(payloadDTO.getDocId().equals("8"))
//                     Location = Location+"Self-declaration-Of-Non-drawl";
//                 if(payloadDTO.getDocId().equals("3"))
//                     Location = Location+"Dependent-Declaration";
//                String fileName = saveDocuments.saveDocuments(files.get(i),payloadDTOList.get(i).getTrustId(),Location);
//                if (StringUtils.hasText(fileName)) {
//                    status = savemedcodocs(payloadDTOList.get(i),fileName);
//
//                   if(status)
//                       continue;
//                    if (!status)
//                       return new ApiResponse<>(false,"Error saving info","",500);
//                    break;}}}
//        return new ApiResponse<>(true,"Saved","",HttpStatus.OK.value());
//    }
//
//    public Boolean savemedcodocs(PayloadDTO payloadDTO, String fileName) {
//
//        try {
//            EhsClaimDocModel ehsClaimDocModel = new EhsClaimDocModel();
//            ehsClaimDocModel.setCLAIM_ID(Long.valueOf(payloadDTO.getTrustId()));
//            ehsClaimDocModel.setDOC_TYPE_ID(Long.valueOf(payloadDTO.getDocId()));
//            ehsClaimDocModel.setCREATED_BY(payloadDTO.getTrustId());
//            ehsClaimDocModel.setUPDATED_BY(null);
//            ehsClaimDocModel.setUPDATED_ON(null);
//            ehsClaimDocModel.setDOC_FILE_PATH(fileName);
//            ehsClaimDocRepo.save(ehsClaimDocModel);
//            return true;
//        }catch (Exception e)
//        {
//            e.printStackTrace();
//            log.info(e.getMessage());
//            return false;
//        }
//
//    }
//
//
//    public ApiResponse<?> savedata(EhsClaimDTO ehsClaimDTO) {
//        try {
//            EhsClaimDetailsModel ehsClaimDetailsModel = new EhsClaimDetailsModel();
//            ehsClaimDetailsModel.setDATE_OF_ADMISSION(Date.valueOf(ehsClaimDTO.getDateOfAdmission()));
//            ehsClaimDetailsModel.setDATE_OF_SURGERY_OR_TREATMENT(Date.valueOf(ehsClaimDTO.getDateOfTreatment()));
//            ehsClaimDetailsModel.setDATE_OF_DISCHARGE(Date.valueOf(ehsClaimDTO.getDateOfDischarge()));
//            ehsClaimDetailsModel.setTREATMENT_TYPE(ehsClaimDTO.getTreatmentType());
//            ehsClaimDetailsModel.setSPECIALITY_ID(ehsClaimDTO.getSpeciality());
//            ehsClaimDetailsModel.setPATIENT_TYPE(ehsClaimDTO.getPatientType());
//            ehsClaimDetailsModel.setTOTAL_AMOUNT_CLAIMED(Long.valueOf(ehsClaimDTO.getAmountClaimed()));
//            ehsClaimDetailsModel.setREMARKS(ehsClaimDTO.getRemarks());
//            ehsClaimDetailsModel.setCLAIM_ID(Long.valueOf(ehsClaimDTO.getTrustId()));
//            ehsClaimDetailsModel.setCREATED_BY(ehsClaimDTO.getTrustId());
//            ehsClaimDetailsModel.setUPDATED_BY(null);
////            if(ehsClaimDetailsModel.getEhsAisMrMaster().getID().equals(Long.valueOf(ehsClaimDTO.getTrustId())))
////            {
////                ehsClaimDetailsModel.getEhsAisMrMaster().setIS_INITIATED('Y');
////            }
////            EhsAisMrMaster ehsAisMrMaster = ehsAisMrRepo.findById(Long.valueOf(ehsClaimDTO.getTrustId())).get();
////            ehsAisMrMaster.setIS_INITIATED('Y');
//            ehsClaimDetailsRepo.save(ehsClaimDetailsModel);
//            return new ApiResponse<>(true,"Savedo","",HttpStatus.OK.value());
//
//        }catch(Exception e) {
//            e.printStackTrace();
//            return new ApiResponse<>(false,"Error saving info","",500);
//
//        }
//
//    }
//
//    public ApiResponseDto fetchspecialities() {
//        Map<String, Object> response = new HashMap<>();
//        response.put("specialities", ehsClaimDetailsRepo.getspecialities());
//        return new ApiResponseDto (true,"fetched",response,HttpStatus.OK.value());
//    }
//
//}
