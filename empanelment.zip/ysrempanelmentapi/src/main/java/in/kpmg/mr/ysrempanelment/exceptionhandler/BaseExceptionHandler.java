package in.kpmg.mr.ysrempanelment.exceptionhandler;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class BaseExceptionHandler {

	@ExceptionHandler(UnsupportedException.class)
	public ApiResponse DocNotSupportedException(UnsupportedException ex) {
		
		return  new ApiResponse(ex.getErrorMessage());
		
	}
}
