package in.kpmg.mr.ysrempanelment.dtos.common;

public interface BranchNameResult {
	
	Number getBranchId();
	String getBranchName();
	String getIfscCode();
}
