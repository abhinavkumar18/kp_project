package in.kpmg.mr.ysrempanelment.controllers;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse2;
import in.kpmg.mr.ysrempanelment.dtos.common.DocInfoDTO;
import in.kpmg.mr.ysrempanelment.dtos.common.HospitalInfraDetailsDTO;
import in.kpmg.mr.ysrempanelment.services.HospitalInfraDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class HospitalInfraDetailsController {

    @Autowired
    HospitalInfraDetailsService hospitalInfraDetailsService;


    @GetMapping("/infra-initiate-application")
    public ApiResponse2<?> initiateApplication() {
        return new ApiResponse2<>(true, "Details fetched successfully", hospitalInfraDetailsService.infraInitiateApplication());
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping(value = "/saveHospitalInfraDetails",
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
    public ApiResponse<?> saveHospitalinfra(@RequestPart(value = "files") List<MultipartFile> files,
                                            @RequestPart(value = "docInfoDTOS") List<DocInfoDTO> docInfoDTOS,
                                            @RequestPart(value = "hospitalInfraDetailsDTO") List<HospitalInfraDetailsDTO> hospitalInfraDetailsDTO) throws IOException {
        return hospitalInfraDetailsService.uploadfiles(files, docInfoDTOS, hospitalInfraDetailsDTO);
    }
}






