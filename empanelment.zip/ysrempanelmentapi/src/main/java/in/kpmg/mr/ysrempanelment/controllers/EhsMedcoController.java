//package in.kpmg.mr.ysrempanelment.controllers;
//
//import in.kpmg.mr.ysrempanelment.dtos.common.*;
//import in.kpmg.mr.ysrempanelment.services.EhsMedcoService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.MediaType;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.IOException;
//import java.util.List;
//
//@RestController
//@CrossOrigin(origins = "*", allowedHeaders = "*")
//public class EhsMedcoController {
//    @Autowired
//    private EhsMedcoService ehsMedcoService;
//
//
//    @PostMapping("/fetch-data-with-trustid")
//    @CrossOrigin(origins = "*", allowedHeaders = "*")
//    public ApiResponseDto fetchdata(@RequestBody PayloadDTO payloadDTO) {
//        return ehsMedcoService.fetchdatawithid(payloadDTO.getTrustId());
//    }
//
//    @CrossOrigin(origins = "*", allowedHeaders = "*")
//    @PostMapping(value = "/save-docs",
//            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
//    public ApiResponse<?> saveHospitalinfo(@RequestPart(value = "files") List<MultipartFile> files,
//                                           @RequestPart(value = "payloadDTOList") List<PayloadDTO> payloadDTOList) throws IOException {
//        return ehsMedcoService.uploadfiles(files,payloadDTOList);
//    }
//    @PostMapping("/save-data-with-trustid")
//    @CrossOrigin(origins = "*", allowedHeaders = "*")
//    public ApiResponse<?> savedata(@RequestBody EhsClaimDTO ehsClaimDTO) {
//        return ehsMedcoService.savedata(ehsClaimDTO);
//    }
//    @GetMapping("/specialitylist")
//    public ApiResponseDto List() {
//        return ehsMedcoService.fetchspecialities();
//    }
//}