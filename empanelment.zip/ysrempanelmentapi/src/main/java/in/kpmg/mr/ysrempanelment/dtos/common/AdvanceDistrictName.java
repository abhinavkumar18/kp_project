package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.Data;

@Data
public class AdvanceDistrictName {
	public String stateId;
}
