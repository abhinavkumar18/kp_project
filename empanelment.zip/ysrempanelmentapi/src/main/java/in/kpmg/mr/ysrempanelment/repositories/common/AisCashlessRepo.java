//package in.kpmg.mr.ysrempanelment.repositories.common;
//import java.util.List;
//
//import javax.transaction.Transactional;
//
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import in.kpmg.mr.ysrempanelment.dtos.common.ListofHospitalsDto;
//import in.kpmg.mr.ysrempanelment.dtos.common.SearchAisDetailsCashlessDTO;
//import in.kpmg.mr.ysrempanelment.models.common.UpdateRegID;
//
//
//public interface AisCashlessRepo extends CrudRepository <UpdateRegID, Long>{
//
//	@Query(value="Select EMPANL_ID as hospRegId,hosp_name as hospName from EMPNL_GENERAL_DETAILS",nativeQuery=true)
//	List<ListofHospitalsDto> getNonEmpnlHospital();
//
//
//	//@Query(value="Select CONTACT_NO as contactNo, HOSP_NAME as hospName, HOSP_MAIL_ID as hospMailId, HOSP_CONTACT_NO as hospContactNo,ID as id,EMP_ID as empId,LOC_NUMBER as locNumber,PATIENT_NAME as patientName, RELATION as relation,TREATMENT_DESCRIPTION as treatmentDescription,LOC_AMOUNT as locAmount,LOC_PHOTO as locPhoto,PHOTO as photo,EMPLOYEE_NAME as employeeName from EHS_AIS_MR where CONTACT_NO=:value", nativeQuery=true)
//	@Query(value="Select CONTACT_NO as contactNo, HOSP_NAME as hospName, HOSP_MAIL_ID as hospMailId, HOSP_CONTACT_NO as hospContactNo,ID as id,EMP_ID as empId,LOC_NUMBER as locNumber,PATIENT_NAME as patientName, RELATION as relation,TREATMENT_DESCRIPTION as treatmentDescription,LOC_AMOUNT as locAmount,LOC_PHOTO as locPhoto,PHOTO as photo,EMPLOYEE_NAME as employeeName, IS_REGISTERED as isHospitalReg from EHS_AIS_MR where NWH='N' and IS_REGISTERED='N' and NON_EMPANL_ID is null and(CONTACT_NO like %:value% or lower(LOC_NUMBER) like %:value% or EMP_ID  like %:value% or lower(PATIENT_NAME) like %:value%) ", nativeQuery=true)
//	List<SearchAisDetailsCashlessDTO> searchAisDetailsCashless(@PathVariable("value") String value);
//
//    @Query(value="Select CONTACT_NO as contactNo, HOSP_NAME as hospName, HOSP_MAIL_ID as hospMailId, HOSP_CONTACT_NO as hospContactNo,ID as id,EMP_ID as empId,LOC_NUMBER as locNumber,PATIENT_NAME as patientName, RELATION as relation,TREATMENT_DESCRIPTION as treatmentDescription,LOC_AMOUNT as locAmount,LOC_PHOTO as locPhoto,PHOTO as photo,EMPLOYEE_NAME as employeeName, IS_REGISTERED as isHospitalReg from EHS_AIS_MR where NON_EMPANL_ID=:hospitalRegId and initiated_id is null", nativeQuery=true)
//	List<SearchAisDetailsCashlessDTO> fetchRegHospInbox(@PathVariable("hospitslRegId") String hospitalRegId);
//
//    @Transactional
//	@Modifying
//	@Query(value="Update EHS_AIS_MR set initiated_id=:initiateId where id=:claimID ", nativeQuery=true)
//	void updateAisInitiateID(@PathVariable("initiateId") Long initiateId,@PathVariable("claimID") Long claimID);
//
//
//
//    //@Query(value="Select CONTACT_NO as contactNo, HOSP_NAME as hospName, HOSP_MAIL_ID as hospMailId, HOSP_CONTACT_NO as hospContactNo,ID as id,EMP_ID as empId,LOC_NUMBER as locNumber,PATIENT_NAME as patientName, RELATION as relation,TREATMENT_DESCRIPTION as treatmentDescription,LOC_AMOUNT as locAmount,LOC_PHOTO as locPhoto,PHOTO as photo,EMPLOYEE_NAME as employeeName from EHS_AIS_MR where IS_REGISTERED=:isHospitalReg and EMPANL_ID=:hospitslRegId ", nativeQuery=true)
//
////lower(EMP_ID)  like lower(%:value%))
////	@Query(value="Select CONTACT_NO as contactNo, HOSP_NAME as hospName, HOSP_MAIL_ID as hospMailId, HOSP_CONTACT_NO as hospContactNo,ID as id,EMP_ID as empId,LOC_NUMBER as locNumber,PATIENT_NAME as patientName, RELATION as relation,TREATMENT_DESCRIPTION as treatmentDescription,LOC_AMOUNT as locAmount,LOC_PHOTO as locPhoto,PHOTO as photo,EMPLOYEE_NAME as employeeName from EHS_AIS_MR where LOC_NUMBER=:value", nativeQuery=true)
////	List<SearchAisDetailsCashlessDTO> searchAisDetailsCashlessByLocNo(@PathVariable("value") String value);
////
////	@Query(value="Select CONTACT_NO as contactNo, HOSP_NAME as hospName, HOSP_MAIL_ID as hospMailId, HOSP_CONTACT_NO as hospContactNo,ID as id,EMP_ID as empId,LOC_NUMBER as locNumber,PATIENT_NAME as patientName, RELATION as relation,TREATMENT_DESCRIPTION as treatmentDescription,LOC_AMOUNT as locAmount,LOC_PHOTO as locPhoto,PHOTO as photo,EMPLOYEE_NAME as employeeName from EHS_AIS_MR where EMP_ID=:value", nativeQuery=true)
////	List<SearchAisDetailsCashlessDTO> searchAisDetailsCashlessByEmpId(@PathVariable("value") String value);
//
//}
