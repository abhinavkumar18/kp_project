package in.kpmg.mr.ysrempanelment.repositories.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.kpmg.mr.ysrempanelment.models.common.EmpnlGeneralInfrastructure;

@Repository
public interface EmpnlGeneralInfrastructureRepo extends JpaRepository<EmpnlGeneralInfrastructure,Integer> {

}
