package in.kpmg.mr.ysrempanelment.repositories.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.kpmg.mr.ysrempanelment.models.common.EmpnlGeneralAttachmentMain;

@Repository
public interface EmpnlGeneralAttachmentMainRepo extends JpaRepository<EmpnlGeneralAttachmentMain,Integer>{

}
