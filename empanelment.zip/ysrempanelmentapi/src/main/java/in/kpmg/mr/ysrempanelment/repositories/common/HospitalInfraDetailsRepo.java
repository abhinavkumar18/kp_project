package in.kpmg.mr.ysrempanelment.repositories.common;

import java.util.List;

import in.kpmg.mr.ysrempanelment.dtos.common.InfraDropdown;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.kpmg.mr.ysrempanelment.dtos.common.CodeValueResult;
import in.kpmg.mr.ysrempanelment.models.common.HospitalInfraDetailsModel;

@Repository
public interface HospitalInfraDetailsRepo extends JpaRepository<HospitalInfraDetailsModel,Long> {


	@Query(value = "SELECT value.VALUE_ID valueId, value.LABEL_VALUE valueName FROM ysr.empnl_hosp_infra_label_mst master join ysr.empnl_hosp_infra_label_value value on master.LABEL_ID=value.LABEL_ID and master.IS_ACTIVE=true and value.LABEL_ID=:id order by value.LABEL_ID ",nativeQuery = true)
	  List<InfraDropdown> getAllCodeValueList(@Param("id") Integer labelId);

}
