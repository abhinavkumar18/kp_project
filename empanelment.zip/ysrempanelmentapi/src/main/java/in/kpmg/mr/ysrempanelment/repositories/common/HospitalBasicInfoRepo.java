package in.kpmg.mr.ysrempanelment.repositories.common;
import in.kpmg.mr.ysrempanelment.dtos.common.StateNameResult;
import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import in.kpmg.mr.ysrempanelment.dtos.common.CodeValueResult;
import in.kpmg.mr.ysrempanelment.dtos.common.BranchNameResult;
import in.kpmg.mr.ysrempanelment.dtos.common.CodeNameResult;

import java.util.List;

@Repository
public interface HospitalBasicInfoRepo extends JpaRepository<HospitalBasicInfoModel,Long> {



    HospitalBasicInfoModel findByHospitalPan(String HospitalPan);

    HospitalBasicInfoModel findByHospitalEmail(String HospitalName);

    @Query(value="select state_id valueId,upper(state_name) valueName from ysr.ysr_state_mst order by state_name",nativeQuery = true)
	List<StateNameResult> getStateList();

	@Query(value = "select type_id typeId,type_name typeName from ysr.ysr_general_type_mst where type_desc =:id ",nativeQuery = true)
	  List<CodeValueResult> getAllCodeValueList(@Param("id") String typeDesc);

	@Query(value = "SELECT BRANCH_ID branchId, upper(BRANCH_NAME) branchName, ifsc_code ifscCode FROM ysr.ysr_branch_mst where bank_id=:codeValueId order by BRANCH_NAME",nativeQuery = true)
	  List<BranchNameResult> getBranchList(Integer codeValueId);

	@Query(value="select dist_id typeId,upper(district_name) typeName from ysr.ysr_district_mst where state_id=:stateId order by district_name",nativeQuery = true)
	List<CodeValueResult> getDistrictList(Long stateId);

	@Query(value="select mandal_id valueId,upper(mandal_name) valueName from ysr.ysr_mandal_mst where dist_id=:districtId order by mandal_name",nativeQuery = true)
	List<CodeNameResult> getMandalList(Long districtId);

	@Query(value = "select count(*) counter from ehf_empnl_hospinfo where pannumber =:panNumber",nativeQuery = true)
	public int checkPanList(String panNumber);

	@Query(value = "select bank_id valueId,bank_name valueName from ysr.ysr_bank_mst",nativeQuery = true)
	List<StateNameResult> getBankList();
}


