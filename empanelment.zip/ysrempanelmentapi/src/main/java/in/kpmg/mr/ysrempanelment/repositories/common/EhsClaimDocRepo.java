//package in.kpmg.mr.ysrempanelment.repositories.common;
//
//import in.kpmg.mr.ysrempanelment.models.common.EhsClaimDocModel;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//@Repository
//public interface EhsClaimDocRepo extends JpaRepository<EhsClaimDocModel,Long> {
//}
