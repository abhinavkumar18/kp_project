package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApiResponseDto {
        private Boolean status;
        private String message;
        private Object result;
//        private HttpStatus status;
        private int code;


    }

