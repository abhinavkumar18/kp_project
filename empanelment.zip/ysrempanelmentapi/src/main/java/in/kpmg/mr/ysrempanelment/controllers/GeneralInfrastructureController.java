package in.kpmg.mr.ysrempanelment.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.GeneralInfrastructureDto;
import in.kpmg.mr.ysrempanelment.services.GeneralInfrastructureService;
import lombok.extern.slf4j.Slf4j;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
public class GeneralInfrastructureController {
	
	@Autowired
	GeneralInfrastructureService generalInfrastructureService;

	@PostMapping(value = "/save-general-infrastructure-details",
   		 consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	public ApiResponse<?> saveEnrollDetails(
			@RequestPart(value = "files") List<MultipartFile> files,
          @RequestPart(value = "generalInfrastructureDto") List<GeneralInfrastructureDto> generalInfrastructureDto){

		log.info("Request received to save details");
		return generalInfrastructureService.saveGeneralInfrastructure(files,generalInfrastructureDto);
	}
}
