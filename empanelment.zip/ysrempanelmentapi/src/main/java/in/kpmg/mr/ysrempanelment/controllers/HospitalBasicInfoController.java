package in.kpmg.mr.ysrempanelment.controllers;

import in.kpmg.mr.ysrempanelment.dtos.common.*;
import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;
import in.kpmg.mr.ysrempanelment.services.HospitalBasicInfoService;
import in.kpmg.mr.ysrempanelment.services.UserService;
import in.kpmg.mr.ysrempanelment.util.JWTUtility;
import in.kpmg.mr.ysrempanelment.util.SaveDocumentsUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.CONTENT_TYPE;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class HospitalBasicInfoController {
    @Autowired
    JWTUtility jwtUtility;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserService userService;
    @Autowired
    HospitalBasicInfoService hospitalBasicInfoService;
    @Autowired
    SaveDocumentsUtil saveDocumentsUtil;


    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping(value = "/saveHospitalBasicInfo",
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
    public ApiResponse<?> saveHospitalinfo(@RequestPart(value = "files") List<MultipartFile> files,
                                           @RequestPart(value = "hospitalBasicInfoDTO") HospitalBasicInfoDTO hospitalBasicInfoDTO) throws IOException {
        if (files == null || files.size() == 0) {
            return new ApiResponse(false, "Please Add File", "", HttpStatus.BAD_REQUEST.value());
        }
        for (MultipartFile multipartFile : files) {
            if (multipartFile.isEmpty()) {
                return new ApiResponse(false, "File Not Found", "failure", 400);
            }
            if (CONTENT_TYPE.contains(multipartFile.getContentType())) {
                // String fileName = ( hospitalBasicInfoDTO.getHospitalPan() + "-" + StringUtils.cleanPath(multipartFile.getOriginalFilename()));
                String fileName = saveDocumentsUtil.getFileName(multipartFile, hospitalBasicInfoDTO.getHospitalPan());
                //  String fileName = saveDocumentsUtil.saveDocuments(multipartFile,hospitalBasicInfoDTO.getHospitalPan());
                if (StringUtils.hasText(fileName)) {
                    ApiResponse<?> store = hospitalBasicInfoService.savehospitalinfo(hospitalBasicInfoDTO, fileName);
                    if (store.getStatus()) {
                        saveDocumentsUtil.saveDocuments(multipartFile, hospitalBasicInfoDTO.getHospitalPan());
                    }
                    return store;
                }
            } else {
                return new ApiResponse(false, "unsupported format", "failure", 400);
            }

        }
        return new ApiResponse(true, "Saved Successfully", "", 200);
    }

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping(value = "/savefinancialdetails",
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
    public ApiResponse<?> savefinancialdetails(@RequestPart(value = "files") List<MultipartFile> files,
                                               @RequestPart(value = "hospitalBasicInfoDTO") HospitalBasicInfoDTO hospitalBasicInfoDTO) throws IOException {
        if (files == null || files.size() == 0)
            return new ApiResponse(false, "Please Add File", "", HttpStatus.BAD_REQUEST.value());
        if (hospitalBasicInfoDTO.getHospRegId() == null)
            return new ApiResponse(false, "Please Fill Hospital Basic Information Form First", "", HttpStatus.BAD_REQUEST.value());
        for (MultipartFile multipartFile : files) {
            if (multipartFile.isEmpty()) {
                return new ApiResponse(false, "File Not Found", "failure", 400);
            }
            if (CONTENT_TYPE.contains(multipartFile.getContentType())) {
                //    String fileName = saveDocumentsUtil.saveDocuments(multipartFile,hospitalBasicInfoDTO.getHospRegId());
                String panNo = saveDocumentsUtil.getPanNo(hospitalBasicInfoDTO.getHospRegId());
                String fileName = saveDocumentsUtil.getFileName(multipartFile, panNo);
                if (StringUtils.hasText(fileName)) {
                    ApiResponse store = hospitalBasicInfoService.savefinancialdetails(hospitalBasicInfoDTO, fileName);
                    if (store.getStatus()) {
                        saveDocumentsUtil.saveDocuments(multipartFile, panNo);
                    }
                    return store;
                }

            } else {
                return new ApiResponse(false, "unsupported format", "failure", 400);
            }

        }
        return new ApiResponse(true, "Saved Successfully", "", 200);
    }

    @GetMapping("/initiate-application")
    public ApiResponse2<?> initiateApplication() {
        return new ApiResponse2<>(true, "Details fetched successfully", hospitalBasicInfoService.initiateApplication());
    }

    @PostMapping("/districtlist")
    public ApiResponse2<?> districtList(@RequestBody AdvanceDistrictName stateid) {
        return new ApiResponse2<>(true, "Search result found", hospitalBasicInfoService.districtList(stateid.getStateId()));
    }

    @PostMapping("/branchlist")
    public ApiResponse2<?> branchList(@RequestBody AdvanceBranchName bankid) {
        return new ApiResponse2<>(true, "Search result found", hospitalBasicInfoService.branchList(bankid.getCodeValueId()));
    }

    @PostMapping("/mandallist")
    public ApiResponse2<?> mandalList(@RequestBody AdvanceMandalName districtid) {
        return new ApiResponse2<>(true, "Search result found", hospitalBasicInfoService.mandalList(districtid.getDistrictId()));
    }

    @PostMapping("/emailtest")
    public ApiResponse2<?> TestEmail(@RequestBody HospitalBasicInfoDTO hospitalBasicInfoDTO) {
        return new ApiResponse2<>(true, "Search result found", hospitalBasicInfoService.test(hospitalBasicInfoDTO.getHospitalEmailId()));
    }
}
