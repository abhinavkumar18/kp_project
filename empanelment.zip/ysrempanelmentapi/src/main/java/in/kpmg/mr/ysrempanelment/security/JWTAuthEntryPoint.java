package in.kpmg.mr.ysrempanelment.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
public class JWTAuthEntryPoint implements AuthenticationEntryPoint {

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

        String com = "";
        final Map<String, Object> body = new HashMap<>();
        if (request.getAttribute("authnpnl") != null) {
            com = (String) request.getAttribute("authnpnl");
            if ("expired".equalsIgnoreCase(com)) {
                //body.put("status", HttpServletResponse.SC_REQUEST_TIMEOUT);
                body.put("code", HttpServletResponse.SC_UNAUTHORIZED);
                body.put("status", "Expired");
                body.put("data", "Your Session Expired. Please validate input requests");
            } else if ("invalid".equalsIgnoreCase(com)) {
                body.put("code", HttpServletResponse.SC_BAD_REQUEST);
                body.put("status", "Wrong Credentials");
                body.put("data", "Invalid request. You are not authorized.");
            } else {
                body.put("code", HttpServletResponse.SC_UNAUTHORIZED);
                body.put("status", "Unauthorized request is prohibited. You are not authorized");
                body.put("data", authException.getMessage());
            }
        } else {

            body.put("code", HttpServletResponse.SC_UNAUTHORIZED);
            body.put("status", "Unauthentized access detected. Please authorize your request");
            body.put("data", authException.getMessage());
        }
        //body.put("path", request.getServletPath());
        final ObjectMapper mapper = new ObjectMapper();
        mapper.writeValue(response.getOutputStream(), body);
    }
}



