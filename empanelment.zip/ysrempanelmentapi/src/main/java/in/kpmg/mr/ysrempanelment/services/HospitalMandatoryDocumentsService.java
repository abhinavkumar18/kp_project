package in.kpmg.mr.ysrempanelment.services;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.HospitalMandatoryDocumentsDto;
import in.kpmg.mr.ysrempanelment.models.common.DocTypeMaster;
import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;
import in.kpmg.mr.ysrempanelment.models.common.HospitalMandatoryDocumentsModel;
import in.kpmg.mr.ysrempanelment.repositories.common.DocTypeMasterRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.HospitalBasicInfoRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.HospitalMandatoryDocumentsRepo;
import in.kpmg.mr.ysrempanelment.util.GetEmpanelUtil;
import in.kpmg.mr.ysrempanelment.util.SaveDocumentsUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.CONTENT_TYPE;
import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.FILE_STORAGE_LOCATION;

@Service
public class HospitalMandatoryDocumentsService {

    @Autowired
    HospitalMandatoryDocumentsRepo hospitalMandatoryDocumentsRepo;
    @Autowired
    HospitalBasicInfoRepo hospitalBasicInfoRepo;
    @Autowired
    SaveDocumentsUtil saveDocumentsUtil;
    @Autowired
    DocTypeMasterRepo docTypeMasterRepo;
    @Autowired
    GetEmpanelUtil getEmpanelUtil;

    public Boolean insertHospitalDocumentFields(HospitalMandatoryDocumentsDto hospitalMandatoryDocumentsDto, String fileName) {
        try {
            HospitalMandatoryDocumentsModel hospitalMandatoryDocumentsModel = new HospitalMandatoryDocumentsModel();
            hospitalMandatoryDocumentsModel.setDateOfIssue(hospitalMandatoryDocumentsDto.getDateOfIssue());
            String filePath = FILE_STORAGE_LOCATION + "/" + fileName;
            hospitalMandatoryDocumentsModel.setFilePath(filePath.replace("\\\\", "\\/"));
            String panNo = saveDocumentsUtil.getPanNo(hospitalMandatoryDocumentsDto.getHospRegId());
            hospitalMandatoryDocumentsModel.setCreatedBy(3L);
            hospitalMandatoryDocumentsModel.setUpdatedBy(null);
            hospitalMandatoryDocumentsModel.setDateOfExpiry(hospitalMandatoryDocumentsDto.getDateOfExpiry());
            HospitalBasicInfoModel hospitalBasicInfoModel = getEmpanelUtil.getEmpanelIdModelWithPan(panNo);
            hospitalMandatoryDocumentsModel.setHospitalBasicInfoModel(hospitalBasicInfoModel);
            DocTypeMaster docTypeMaster = docTypeMasterRepo.findBynameOfDocuments(hospitalMandatoryDocumentsDto.getNameOfDocuments());
            if (docTypeMaster != null) {
                hospitalMandatoryDocumentsModel.setDocTypeMaster(docTypeMaster);
            }
            hospitalMandatoryDocumentsRepo.save(hospitalMandatoryDocumentsModel);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public ApiResponse<?> hospitalMandtoryDoc(List<MultipartFile> files, HospitalMandatoryDocumentsDto hospitalMandatoryDocumentsDto) {
        if (files.size() == 0 || files == null)
            return new ApiResponse<>(false, "File not found", "", HttpStatus.NO_CONTENT.value());
        Boolean status;
        for (MultipartFile multipartFile : files) {
            if (multipartFile.isEmpty()) {
                return new ApiResponse(false, "File not found", "failure", 400);
            }
            if (CONTENT_TYPE.contains(multipartFile.getContentType())) {
                String panNo = saveDocumentsUtil.getPanNo(hospitalMandatoryDocumentsDto.getHospRegId());

                String fileName = saveDocumentsUtil.saveDocuments(multipartFile, panNo); //to be changed
                if (StringUtils.hasText(fileName)) {
                    status = insertHospitalDocumentFields(hospitalMandatoryDocumentsDto, fileName);
                    if (status == false) {
                        return new ApiResponse<>(false, "Error saving your information", "", HttpStatus.NO_CONTENT.value());

                    }
                }
            }
        }


        return new ApiResponse(true, "Saved successfully", "Success", 200);

    }

}
