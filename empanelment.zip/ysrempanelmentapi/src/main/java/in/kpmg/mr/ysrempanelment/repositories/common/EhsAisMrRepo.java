//package in.kpmg.mr.ysrempanelment.repositories.common;
//
//import in.kpmg.mr.ysrempanelment.models.common.EhsAisMrMaster;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import java.util.List;
//
//public interface EhsAisMrRepo extends JpaRepository<EhsAisMrMaster,Long> {
//
//}
