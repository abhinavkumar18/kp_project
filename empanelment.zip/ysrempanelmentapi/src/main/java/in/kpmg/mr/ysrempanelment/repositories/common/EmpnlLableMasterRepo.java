package in.kpmg.mr.ysrempanelment.repositories.common;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import in.kpmg.mr.ysrempanelment.models.common.EmpnlLableMaster;

@Repository
public interface EmpnlLableMasterRepo extends JpaRepository<EmpnlLableMaster,Integer> {

}
