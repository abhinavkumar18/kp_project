//package in.kpmg.mr.ysrempanelment.repositories.common;
//import in.kpmg.mr.ysrempanelment.dtos.common.SpecialitiesResult;
//import in.kpmg.mr.ysrempanelment.models.common.EhsClaimDetailsModel;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface EhsClaimDetailsRepo extends JpaRepository<EhsClaimDetailsModel,Long> {
//    @Query(value = "SELECT DIS_MAIN_ID disMainId, DIS_MAIN_NAME disMainName FROM EHFM_SPECIALITIES where DIS_ACTIVE_YN='Y' order by DIS_MAIN_NAME",nativeQuery = true)
//    List<SpecialitiesResult> getspecialities();
//}
