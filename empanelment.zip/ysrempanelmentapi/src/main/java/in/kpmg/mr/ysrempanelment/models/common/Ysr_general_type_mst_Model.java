package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "ysr_general_type_mst")
@Data
@Entity
public class Ysr_general_type_mst_Model {
    @Id
    @Column(name = "type_id")
   private Long typeId;
    @Column(name = "type_name")
            private String typeName;
    private String type_desc;
           private Boolean is_active;
    private Long type_order;
}
