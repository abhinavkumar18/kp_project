package in.kpmg.mr.ysrempanelment.repositories.common;

import org.springframework.stereotype.Repository;

import in.kpmg.mr.ysrempanelment.models.common.EmpnlQstMaster;

import org.springframework.data.jpa.repository.JpaRepository;


@Repository
public interface EmpnlQstMasterRepo extends JpaRepository<EmpnlQstMaster,Integer> {

}
