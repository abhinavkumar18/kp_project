package in.kpmg.mr.ysrempanelment.dtos.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocInfoDTO {
    private Long hosRegId;
    private String labelValueId;
    private String labelValue;
}
