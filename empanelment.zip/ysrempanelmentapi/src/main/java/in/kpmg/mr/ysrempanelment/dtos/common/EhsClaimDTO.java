package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.Data;

@Data
public class EhsClaimDTO {
    private String amountClaimed;
    private String patientType;
    private String dateOfAdmission;
    private String dateOfTreatment;
    private String dateOfDischarge;
    private String speciality;
    private String treatmentType;
    private String remarks;
    private String trustId;

}
