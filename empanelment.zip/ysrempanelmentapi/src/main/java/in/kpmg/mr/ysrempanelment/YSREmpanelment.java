package in.kpmg.mr.ysrempanelment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@SpringBootApplication
@EnableScheduling
@ComponentScan("in.kpmg.mr.ysrempanelment")
public class YSREmpanelment {

	// @PostConstruct
	// void started() {
	//   TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
	//   System.out.println("Spring boot application running in UTC timezone :"+new Date());
	// }
	public static void main(String[] args) {
		SpringApplication.run(YSREmpanelment.class, args);
	}

	@SuppressWarnings("deprecation")
	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("*").allowedOrigins("*");
			}
		};
	}


}
