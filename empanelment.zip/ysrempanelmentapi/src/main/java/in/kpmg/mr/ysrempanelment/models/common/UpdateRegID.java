//package in.kpmg.mr.ysrempanelment.models.common;
//
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@Entity
//@NoArgsConstructor
//@AllArgsConstructor
//@Table(name="EHS_AIS_MR")
//public class UpdateRegID {
//
//	@Id
//	private Long ID;
//
//	private String IS_REGISTERED;
//
//	private String NWH;
//
//	private String NON_EMPANL_ID;
//
//}
