package in.kpmg.mr.ysrempanelment.models.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@Table(name = "empnl_general_details")
@NoArgsConstructor
@AllArgsConstructor
public class GeneralDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "empanl_id")
    private Integer empanlId;

    @Column (name = "hosp_type_id")
    private Integer hospTypeId;

    @Column (name = " hosp_name")
    private String hospName;

}
