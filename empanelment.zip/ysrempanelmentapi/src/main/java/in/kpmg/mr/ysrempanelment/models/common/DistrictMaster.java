package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "EMPNL_DISTRICT_MASTER")
public class DistrictMaster {
    @Id
    private Long DIST_ID;
    private Long DISTRICT_CODE;
    private String DISTRICT_NAME;
    private Boolean IS_DISTRICT_ACTIVE;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "STATE_ID",referencedColumnName ="STATE_ID")
    private StateMaster stateMaster;

}
