package in.kpmg.mr.ysrempanelment.services;

import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;
import in.kpmg.mr.ysrempanelment.repositories.common.HospitalBasicInfoRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class UserService implements UserDetailsService {
    @Autowired
    HospitalBasicInfoRepo hospitalBasicInfoRepo;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

        HospitalBasicInfoModel hospitalBasicInfoModel = hospitalBasicInfoRepo.findByHospitalEmail(userName);

//        return new User("admin","admin",new ArrayList<>());


        return new User(hospitalBasicInfoModel.getHospitalEmail(), hospitalBasicInfoModel.getPassword(), new ArrayList<>());


    }
}

