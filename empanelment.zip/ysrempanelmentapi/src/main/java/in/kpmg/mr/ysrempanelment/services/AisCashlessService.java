//package in.kpmg.mr.ysrempanelment.services;
//
//import java.sql.Date;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.stereotype.Service;
//
//import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
//import in.kpmg.mr.ysrempanelment.dtos.common.EhsClaimDTO;
//import in.kpmg.mr.ysrempanelment.dtos.common.ListofHospitalsDto;
//import in.kpmg.mr.ysrempanelment.dtos.common.SearchAisDetailsCashlessDTO;
//import in.kpmg.mr.ysrempanelment.exceptionhandler.UnsupportedException;
//import in.kpmg.mr.ysrempanelment.models.common.EhsClaimDetailsModel;
//import in.kpmg.mr.ysrempanelment.models.common.FetchRegHospInboxParameter;
//import in.kpmg.mr.ysrempanelment.models.common.SearchAisParameter;
//import in.kpmg.mr.ysrempanelment.models.common.UpdateRegID;
//import in.kpmg.mr.ysrempanelment.models.common.UpdateRegIDParam;
//import in.kpmg.mr.ysrempanelment.repositories.common.AisCashlessRepo;
//import in.kpmg.mr.ysrempanelment.repositories.common.EhsClaimDetailsRepo;
//import in.kpmg.mr.ysrempanelment.repositories.common.UpdateRegIDRepo;
//import lombok.extern.slf4j.Slf4j;
//
//@Service
//@Slf4j
//public class AisCashlessService {
//	@Autowired
//	AisCashlessRepo aisCashlessRepo;
//
//	@Autowired
//	UpdateRegIDRepo updateRegIDRepo;
//
//	@Autowired
//	EhsClaimDetailsRepo ehsClaimDetailsRepo;
//
//
//	public List<ListofHospitalsDto> getNonEmpnlHospital() {
//
//		return aisCashlessRepo.getNonEmpnlHospital();
//	}
//
//	public List<SearchAisDetailsCashlessDTO> searchAisDetailsCashless(SearchAisParameter searchAisParameter) {
//
//		List<SearchAisDetailsCashlessDTO> list = aisCashlessRepo.searchAisDetailsCashless(searchAisParameter.getValue().toLowerCase());
//
//		if (list.isEmpty()) {
//			throw new UnsupportedException("No matching result found");
//		}
//		return list;
//	}
//
//	public ApiResponse<String> UpdateRegID(UpdateRegIDParam UpdateRegIDParam) {
//
//		UpdateRegID updateRegIDinDb = updateRegIDRepo.findAisById("N", "N", UpdateRegIDParam.getId());
//
//		if (updateRegIDinDb == null) {
//			log.info("It is null");
//			return new ApiResponse<String>("Cannot complete this operation. Maybe it is already mapped!");
//		}
//		else {
//			updateRegIDinDb.setNON_EMPANL_ID(UpdateRegIDParam.getHospRegId());
//
//			updateRegIDRepo.save(updateRegIDinDb);
//			log.info("updated regn id for " + updateRegIDinDb.toString());
//
//			return new ApiResponse<String>(true, "Updated the detail succesfully!!", null, 200);
//		}
//
//	}
//	public List<SearchAisDetailsCashlessDTO> fetchRegHospInbox(FetchRegHospInboxParameter fetchRegHospInboxParameter) {
//
//		//check if the input is not null and should be numeric value
//	if(fetchRegHospInboxParameter.getHospitalRegId()!=null && fetchRegHospInboxParameter.getHospitalRegId().toString().chars().allMatch( Character::isDigit )) {
//		List<SearchAisDetailsCashlessDTO> list = aisCashlessRepo.fetchRegHospInbox(fetchRegHospInboxParameter.getHospitalRegId());
//
//		if (list.isEmpty()) {
//			throw new UnsupportedException("No matching result found");
//		}
//		return list;
//	}
//	throw new UnsupportedException("Not a valid hospital registration id!");
//	}
//
//	public ApiResponse<String> initiateClaims(EhsClaimDTO ehsClaimDTO){
//
//		try {
//			EhsClaimDetailsModel ehsClaimDetailsModel = new EhsClaimDetailsModel();
//			ehsClaimDetailsModel.setDATE_OF_ADMISSION(Date.valueOf(ehsClaimDTO.getDateOfAdmission()));
//			ehsClaimDetailsModel.setDATE_OF_SURGERY_OR_TREATMENT(Date.valueOf(ehsClaimDTO.getDateOfTreatment()));
//			ehsClaimDetailsModel.setDATE_OF_DISCHARGE(Date.valueOf(ehsClaimDTO.getDateOfDischarge()));
//			ehsClaimDetailsModel.setTREATMENT_TYPE(ehsClaimDTO.getTreatmentType());
//			ehsClaimDetailsModel.setSPECIALITY_ID(ehsClaimDTO.getSpeciality());
//			ehsClaimDetailsModel.setPATIENT_TYPE(ehsClaimDTO.getPatientType());
//			ehsClaimDetailsModel.setTOTAL_AMOUNT_CLAIMED(Long.valueOf(ehsClaimDTO.getAmountClaimed()));
//			ehsClaimDetailsModel.setREMARKS(ehsClaimDTO.getRemarks());
//			ehsClaimDetailsModel.setCLAIM_ID(Long.valueOf(ehsClaimDTO.getTrustId()));
//			ehsClaimDetailsModel.setCREATED_BY(ehsClaimDTO.getTrustId());
//			ehsClaimDetailsModel.setUPDATED_BY(null);
//
//			log.info("Saving claim Details in service");
//			EhsClaimDetailsModel savedClaim =ehsClaimDetailsRepo.save(ehsClaimDetailsModel);
//
//			log.info("Saved claim Details in service. initiateID: "+savedClaim.getID() +" claimID: "+savedClaim.getCLAIM_ID());
//
//
//			aisCashlessRepo.updateAisInitiateID(savedClaim.getID(),savedClaim.getCLAIM_ID());
//
//			log.info("Updated Initiate Details in EHS_AIS");
//
//
//			return new ApiResponse<>(true,"Details Saved!","", HttpStatus.OK.value());
//
//		}catch(Exception e) {
//			e.printStackTrace();
//			return new ApiResponse<>(false,"Error saving info","",HttpStatus.NO_CONTENT.value());
//
//		}
//
//	}
//
//}
