package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "EMPNL_HOSP_MANDATORY_DOC")
public class HospitalMandatoryDocumentsModel {
    @Id
    @Column(name = "M_DOC_ID")
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "empnl_hosp_mandatory_doc_m_doc_id_seq")
    @SequenceGenerator(name = "empnl_hosp_mandatory_doc_m_doc_id_seq", sequenceName = "empnl_hosp_mandatory_doc_m_doc_id_seq", allocationSize = 1)
    private Long mDocId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DOC_ID", referencedColumnName = "DOC_ID")
    private DocTypeMaster docTypeMaster;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPANL_ID", referencedColumnName = "EMPANL_ID")
    private HospitalBasicInfoModel hospitalBasicInfoModel;
    @Column(name = "File_Path")
    private String filePath;
    @Column(name = "ISSUE_DATE")
    private Date dateOfIssue;
    @Column(name = "EXPIRY_DATE")
    private Date dateOfExpiry;

    @Column(name = "CREATED_BY")
    private Long createdBy;

    @CreationTimestamp
    private Timestamp CREATED_ON;
    @UpdateTimestamp
    private Timestamp UPDATED_ON;
    @Column(name = "UPDATED_BY")
    private Long updatedBy;


}
