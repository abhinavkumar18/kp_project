package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;


@Entity
@Data
@Table(name = "EMPNL_CODE_VALUE_MASTER")
public class CodeValueMaster {
    @Id
    private Long CODE_VALUE_ID;
    @Column(name = "CODE_VALUE")
    private String value;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CODE_TYPE_ID",referencedColumnName = "CODE_TYPE_ID")
    private CodeTypeMaster CODE_TYPE_ID;
    private Boolean IS_ACTIVE;

}
