package in.kpmg.mr.ysrempanelment.models.common;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "empnl_qst_mst")
public class EmpnlQstMaster {
	@Id 
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="qst_id")
    private Integer qstId;
    
	@Column(name = "sub_item_no")
    private String subItemNo;
    
    @Column(name = "qst_desc")
    private String qstDesc;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lable_id", referencedColumnName = "lable_id")
    private EmpnlLableMaster lableId;
    
    @Column(name = "is_normal_optho")
    private String isNormalOptho;
    
    @Column(name = "is_mandatory_optho")
    private Boolean isMandatoryOptho;
    
    @Column(name = "is_mandatory_normal")
    private Boolean isMandatoryNormal;
    
    @Column(name = "is_agree")
    private String isAgree;
    
    @Column(name = "numbers")
    private String numbers;
    
    @Column(name = "area")
    private String area;
    
    @Column(name = "availability")
    private String availability;
    
    @Column(name = "attachments")
    private String attachments;    @Column(name = "make")
    private String make;
    
    @Column(name = "date_of_purchase")
    private String dateOfPurchase;
    
    @Column(name = "serial_no")
    private String serialNo;
    
    @Column(name = "amc_coverage_expiry_date")
    private String amcCoverageExpiryDate;
    
    @Column(name = "in_house_tie_up")
    private String inHouseTieUp;
    //tie_up_facility_name
    //basic_qualification
    //diploma
    //pg
    //super_speciality
    //registration_no
    //experience
    //in_house_on_call
    //contact_no
    //email_id
    @Column(name = "tie_up_facility_name")
    private String tieUpFacilityName;
    
    @Column(name = "basic_qualification")
    private String basicQualification;
    
    @Column(name = "diploma")
    private String diploma;
    
    @Column(name = "pg")
    private String pg;
    
    @Column(name = "super_speciality")
    private String superSpeciality;
    
    @Column(name = "registration_no")
    private String registrationNo;
  
    @Column(name = "experience")
    private String experience;
    
    @Column(name = "in_house_on_call")
    private String inHouseOnCall;
    
    @Column(name = "contact_no")
    private String contactNo;
    
    @Column(name = "email_id")
    private String emailId;
   
    @Column(name="is_active")
    private Boolean isActive;
    
    @Column(name = "name")
    private String name;
	
	
}
