package in.kpmg.mr.ysrempanelment.util;

import org.springframework.stereotype.Component;


import java.util.HashMap;
import java.util.Map;

@Component
public class MasterDataCache {

    public static Map<String, Integer> masterEditLimit = new HashMap<>();

    public static Map<String, String[]> smsCache = new HashMap<>();

    public static Map<String,  String[]> emailCache = new HashMap<>();

    public static Map<String, String> tokenCache = new HashMap<>();
}
