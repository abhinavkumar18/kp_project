package in.kpmg.mr.ysrempanelment.dtos.common;

public interface CodeNameResult {
	String getValueId();
	String getValueName();
}
