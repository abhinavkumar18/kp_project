package in.kpmg.mr.ysrempanelment.dtos.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.sql.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class HospitalMandatoryDocumentsDto implements Serializable {
   // private String panNo;
    private Long hospRegId;

    private String nameOfDocuments;
//    @JsonFormat(pattern = "yyyy-mm-dd")
//    private Timestamp createdOn;
//    @JsonFormat(pattern = "yyyy-mm-dd")
//    private Timestamp updatedOn;
    private Date dateOfIssue;
    private Date dateOfExpiry;

}
