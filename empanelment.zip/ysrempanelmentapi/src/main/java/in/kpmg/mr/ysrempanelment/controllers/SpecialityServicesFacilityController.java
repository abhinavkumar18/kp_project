package in.kpmg.mr.ysrempanelment.controllers;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse2;
import in.kpmg.mr.ysrempanelment.dtos.common.CombinationSpecialityDto;
import in.kpmg.mr.ysrempanelment.dtos.common.SpecialityServicesFacilityDto;
import in.kpmg.mr.ysrempanelment.services.SpecialityServicesFacilityService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SpecialityServicesFacilityController {
    @Autowired
    SpecialityServicesFacilityService specialityServicesFacilityService;

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping("/specialityServicesFacility")
    public ApiResponse<?> saveSpecialityServices(@RequestBody SpecialityServicesFacilityDto specialityServicesFacilityDto) {
        ApiResponse<?> response = specialityServicesFacilityService.saveSpecialityServices(specialityServicesFacilityDto);
        if (response.getStatus()) {
            return new ApiResponse(true, "Saved Successfully", "Success", 200);
        } else {
            return new ApiResponse(false, "unexpected exception", "failure", 400);

        }
    }
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @GetMapping("/initiate-speciality-application")
    public ApiResponse2<?> initiateApplication() {
        return new ApiResponse2<>(true, "Details fetched successfully", specialityServicesFacilityService.initiateApplication());
    }
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping("/initiate-combinationspeciality-application")
    public ApiResponse2<?> initiateCombinationSpecApplication(@RequestBody CombinationSpecialityDto dto) {
        return new ApiResponse2<>(true, "Details fetched successfully", specialityServicesFacilityService.initiateCombinationSpecApplication(dto.getSpecialityId()));
    }
}
