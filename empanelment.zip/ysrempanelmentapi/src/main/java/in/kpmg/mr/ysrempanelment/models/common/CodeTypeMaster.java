package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "EMPNL_CODE_TYPE_MASTER")
@Data
public class CodeTypeMaster {
    @Id
    private Long CODE_TYPE_ID;
    private String CODE_TYPE;
    private Boolean IS_ACTIVE;
}

