package in.kpmg.mr.ysrempanelment.exceptionhandler;

public class UnsupportedException extends RuntimeException {


	private static final long serialVersionUID = 1L;
	
	private String errorMessage;
	
	public UnsupportedException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}


}
