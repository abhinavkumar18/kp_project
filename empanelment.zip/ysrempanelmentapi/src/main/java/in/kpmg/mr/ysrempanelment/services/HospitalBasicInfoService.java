package in.kpmg.mr.ysrempanelment.services;

import in.kpmg.mr.ysrempanelment.dtos.common.*;
import in.kpmg.mr.ysrempanelment.models.common.*;
import in.kpmg.mr.ysrempanelment.repositories.common.*;
import in.kpmg.mr.ysrempanelment.util.EmailVerificationUtil;
import in.kpmg.mr.ysrempanelment.util.GetEmpanelUtil;
import in.kpmg.mr.ysrempanelment.util.JWTUtility;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.FILE_STORAGE_LOCATION;

@Service
@Slf4j
public class HospitalBasicInfoService {

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserService userService;
    @Autowired
    HospitalBasicInfoRepo hospitalBasicInfoRepo;
    @Autowired
    FinancialDtlsRepo financialDtlsRepo;

    @Autowired
    EmailVerificationUtil emailVerificationUtil;
    @Autowired
    BankMasterRepo bankMasterRepo;


    @Autowired
    CodeValueRepo codeValueRepo;

    @Autowired
    GetEmpanelUtil getEmpanelUtil;

    @Autowired
    JWTUtility jwtUtility;

    //
    @Autowired
    EmailService emailService;


    public JwtResponse getloginverification(JwtRequest jwtRequest) throws Exception {


        try {

            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            jwtRequest.getUsername(),
                            jwtRequest.getPassword()
                    )
            );
        } catch (BadCredentialsException e) {
//            throw new Exception("INVALID_CREDENTIALS", e);
            return new JwtResponse(false, "", "Invalid Credentials",null, HttpStatus.BAD_REQUEST.value());


        }

        final UserDetails userDetails
                = userService.loadUserByUsername(jwtRequest.getUsername());

        final String token =
                jwtUtility.generateToken(userDetails);
        HospitalBasicInfoModel hospitalBasicInfoModel1 = getEmpanelUtil.getEmpanelIdModelWithEmail(jwtRequest.getUsername());


        return new JwtResponse(true, "EMPANEL" + token, "Login Sucessfull",String.valueOf(hospitalBasicInfoModel1.getEMPANL_ID()), HttpStatus.OK.value());

    }

    public ApiResponse savefinancialdetails(HospitalBasicInfoDTO hospitalBasicInfoDTO, String fileName) {
//        if (hospitalBasicInfoDTO.getBankName().isEmpty() || hospitalBasicInfoDTO.getBankName() == null)
//            return new ApiResponse<>(false, "Bank Name is mandatory", null, HttpStatus.BAD_REQUEST.value());
        try {
            FinancialDetailsModel financialDetailsModel = new FinancialDetailsModel();
//            BankMasterModel bankMasterModel = new BankMasterModel();
            BankMasterModel bankMasterModel = bankMasterRepo.findById(hospitalBasicInfoDTO.getBranchId()).get();
//            CodeValueMaster codeValueMaster = codeValueRepo.findByValue(hospitalBasicInfoDTO.getBankName());
//            bankMasterModel.setBankName(codeValueMaster.getCODE_TYPE_ID());
//            bankMasterModel.setBRANCH_NAME(hospitalBasicInfoDTO.getBranchName());
//            bankMasterModel.setIFSC_CODE(hospitalBasicInfoDTO.getIfscCode());
//            bankMasterModel.setIS_ACTIVE('Y');
//            bankMasterRepo.save(bankMasterModel); removed save

            HospitalBasicInfoModel hospitalBasicInfoModel1 = getEmpanelUtil.getModelwithId(hospitalBasicInfoDTO.getHospRegId());
            financialDetailsModel.setHospitalBasicInfoModel(hospitalBasicInfoModel1);

            financialDetailsModel.setBankMasterModel(bankMasterModel);
            financialDetailsModel.setHOSP_ACC_NUM(hospitalBasicInfoDTO.getHospitalAccountnumber());
            financialDetailsModel.setACC_HOLDER_NAME(hospitalBasicInfoDTO.getNameoftheAccountHolder());
//            CodeValueMaster codeValueMaster1 = codeValueRepo.findByValue(hospitalBasicInfoDTO.getHospitalOwnershipType());
            financialDetailsModel.setHOSPITAL_OWNERSHIP_ID(Long.valueOf(hospitalBasicInfoDTO.getHospitalOwnershipType()));
//            CodeValueMaster codeValueMaster2 = codeValueRepo.findByValue(hospitalBasicInfoDTO.getBankAccountType());
//            financialDetailsModel.setBANK_ACCOUNT_TYPE(Long.valueOf(hospitalBasicInfoDTO.getBankAccountType()));
            String filePath=FILE_STORAGE_LOCATION +"/"+fileName;

            financialDetailsModel.setHOSP_ACC_PATH(filePath.replaceAll("\\\\","\\/"));

            financialDtlsRepo.save(financialDetailsModel);

        } catch (Exception e) {
            e.printStackTrace();
            return new ApiResponse<>(false, "Unexpected Exception", null, HttpStatus.BAD_REQUEST.value());
        }

        return new ApiResponse<>(true, "Saved Succesfully", null, HttpStatus.OK.value());
    }

    public ApiResponse<?> savehospitalinfo(HospitalBasicInfoDTO hospitalBasicInfoDTO, String fileName) {
        try {
            if (!hospitalBasicInfoDTO.getHospitalPan().isEmpty()) {
                if (hospitalBasicInfoDTO.getHospitalPan().length() != 10)
                    return new ApiResponse<>(false, "Incorrect PAN Format", null, HttpStatus.BAD_REQUEST.value());

                HospitalBasicInfoModel hospitalBasicInfoModel1 = hospitalBasicInfoRepo.findByHospitalPan(hospitalBasicInfoDTO.getHospitalPan());
                if (hospitalBasicInfoModel1 != null)
                    return new ApiResponse<>(false, "PAN Already Exists , please Log in", null, HttpStatus.BAD_REQUEST.value());
            }

//            if (checkPanList(hospitalBasicInfoDTO.getHospitalPan()) != 0) {
//                return new ApiResponse<>(false, "PAN Exists in Empaneled Hospitals , Please Re-Direct", null, HttpStatus.BAD_REQUEST.value());
//            }

            HospitalBasicInfoModel hospitalBasicInfoModel = HospitalBasicInfoDTO.dtoToModel(hospitalBasicInfoDTO);

            if (emailVerificationUtil.isEmailValid(hospitalBasicInfoDTO.getHospitalEmailId())) {
                HospitalBasicInfoModel hospitalBasicInfoModel1 = hospitalBasicInfoRepo.findByHospitalEmail(hospitalBasicInfoDTO.getHospitalEmailId());
                if (hospitalBasicInfoModel1 != null) {
                    return new ApiResponse<>(false, "Email Already Exists , please Log in", null, HttpStatus.BAD_REQUEST.value());
                }
                hospitalBasicInfoModel.setHospitalEmail(hospitalBasicInfoDTO.getHospitalEmailId());
            } else {
                return new ApiResponse<>(false, "Incorrect Email Format", null, HttpStatus.BAD_REQUEST.value());
            }
//
            String filePath=FILE_STORAGE_LOCATION +"/"+fileName;
            hospitalBasicInfoModel.setPAN_FILE_PATH(filePath.replaceAll("\\\\","\\/"));
//            CodeValueMaster codeValueMaster = codeValueRepo.findByValue(hospitalBasicInfoDTO.getHospitalType());
            hospitalBasicInfoModel.setHOSP_TYPE_ID(Long.valueOf(hospitalBasicInfoDTO.getHospitalType()));
            StringBuilder password = passwordBuilder(hospitalBasicInfoDTO);
            hospitalBasicInfoModel.setPassword(String.valueOf(password));
            hospitalBasicInfoRepo.save(hospitalBasicInfoModel);
        } catch (Exception e) {
            e.printStackTrace();
            return new ApiResponse<>(false, e.getMessage(), null, HttpStatus.BAD_REQUEST.value());
        }
        HospitalBasicInfoModel hospitalBasicInfoModel1 = hospitalBasicInfoRepo.findByHospitalEmail(hospitalBasicInfoDTO.getHospitalEmailId());
       generateEmail(hospitalBasicInfoModel1.getHospitalEmail());

        return new ApiResponse<>(true, "Saved Succesfully",String.valueOf(hospitalBasicInfoModel1.getEMPANL_ID()), HttpStatus.OK.value());

    }

    public Boolean test(String email) {
        generateEmail(email);

        return true;
    }

    public Map<String, Object> branchList(int codeValueId) {
        Map<String, Object> response = new HashMap<>();
        response.put("branchList", hospitalBasicInfoRepo.getBranchList(codeValueId));
        return response;
    }

    public Map<String, Object> districtList(String stateId) {
        Map<String, Object> response = new HashMap<>();
        response.put("districtList", hospitalBasicInfoRepo.getDistrictList(Long.valueOf(stateId)));
        return response;
    }

    public Map<String, Object> mandalList(String districtId) {
        Map<String, Object> response = new HashMap<>();
        response.put("mandalList", hospitalBasicInfoRepo.getMandalList(Long.valueOf(districtId)));
        return response;
    }

    public Map<String, Object> initiateApplication() {
        Map<String, Object> response = new HashMap<>();
        response.put("hospitalType", hospitalBasicInfoRepo.getAllCodeValueList("HOSPITAL_TYPE"));
        response.put("hospitalParentType", hospitalBasicInfoRepo.getAllCodeValueList("HOSPITAL_PARENT_TYPE"));
        response.put("stateList", hospitalBasicInfoRepo.getStateList());
        response.put("hospitalOwnershipType", hospitalBasicInfoRepo.getAllCodeValueList("HOSPITAL_OWNERSHIP_TYPE"));
        response.put("bankList", hospitalBasicInfoRepo.getBankList());
        response.put("accountType", hospitalBasicInfoRepo.getAllCodeValueList("ACCOUNT_TYPE"));
        return response;
    }

    public StringBuilder passwordBuilder(HospitalBasicInfoDTO hospitalBasicInfoDTO) {
        String pwd = "";
        String pwd1 = "";
        pwd = hospitalBasicInfoDTO.getHospitalContactNumber().substring(0, 5);
        pwd1 = hospitalBasicInfoDTO.getHospitalPan().substring(0,5);
//        StringBuilder password = new StringBuilder();
        StringBuilder password1 = new StringBuilder();
//        password.append(hospitalBasicInfoDTO.getHospitalPan());
//        password.reverse();
        password1.append(pwd + pwd1);
        return password1;
    }

//    public int checkPanList(String pan) {
//        int c = hospitalBasicInfoRepo.checkPanList(pan);
//        return c;
  //  }


    private void generateEmail(String hospitalEmailId) {
        String subject = "Successfully Registered in YSR Aarogyasri";
       String body = ( "<b>Dear User</b>, <br><br><i>Thank you! for registering in the YSR Aarogyasri, you can now login using username : " + hospitalEmailId + "  and your password is first five numbers of your mobile number followed by 5 characters of your PAN.<br>For example, if your mobile number is 1234567890 and PAN is BQFPR0723J then your password is 12345BQFPR.<br><br><b>Best Regards,<br>YSR Aarogyasri</b><br><a href=\"https://www.ysraarogyasri.ap.gov.in/home\">Click here to visit the website.</a><br><img src='cid:qrImage'/>");

       emailService.sendmail(hospitalEmailId, body, subject);
    }
}
