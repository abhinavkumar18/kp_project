package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.Data;

import java.util.List;

@Data
public class SpecialityServicesFacilityDto {
    private Long hospRegId;
    private List<Integer> specialityId;
}
