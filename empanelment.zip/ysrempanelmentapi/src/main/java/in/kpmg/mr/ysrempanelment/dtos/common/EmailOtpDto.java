package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
    @Data
    @Setter
    @Getter
    public class EmailOtpDto implements Serializable {

        private static final long serialVersionUID = 1L;

        private String txn;
        private String userName;
        private String dob;
        private String aadharNo;
        private String otp;
        private String password;

        private String mod;

        private String err;
        private String error;
        private String kyc;

        private String message;
        private String mobileNo;
        private String language;

        private String emailId;
        private String idp;


    }

