package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "YSR_BRANCH_MST")
public class BankMasterModel {

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "BANK_SEQ")
    @SequenceGenerator(name = "BANK_SEQ",sequenceName = "BANK_SEQ",allocationSize = 1)
    private Long BRANCH_ID;
    private String BRANCH_NAME;
//    private String BRANCH_NAME;
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "CODE_VALUE_ID",referencedColumnName ="CODE_TYPE_ID")
//    private CodeTypeMaster bankName;
    private Long bank_id;
    private String IFSC_CODE;
    private Boolean IS_ACTIVE;


}