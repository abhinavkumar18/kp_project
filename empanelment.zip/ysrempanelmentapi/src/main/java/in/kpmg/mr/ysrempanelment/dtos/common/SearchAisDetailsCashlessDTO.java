package in.kpmg.mr.ysrempanelment.dtos.common;

public interface SearchAisDetailsCashlessDTO {
	
	public Long getId();
	public String getEmployeeName();
	public String getContactNo();
	public String getLocAmount();
	public String getEmpId();
	public String getLocNumber();
	public String getPatientName();
	public String getRelation();
	public String getTreatmentDescription();
	public String getLocPhoto();
	public String getPhoto();
	public String getHospName();
	public String getHospMailId();
	public String getHospContactNo();
	public String getIsHospitalReg();
	


}
