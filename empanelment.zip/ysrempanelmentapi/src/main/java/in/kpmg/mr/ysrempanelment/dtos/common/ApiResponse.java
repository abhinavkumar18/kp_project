package in.kpmg.mr.ysrempanelment.dtos.common;

public class ApiResponse<T> {
    private Boolean status;
    private String message;
    private String result;
    private Integer statusCode;



    public ApiResponse(Boolean status, String message, String result) {
        this.status = status;
        this.message = message;
        this.result = result;
    }


    
    public ApiResponse(Boolean status, String message, String result,Integer statusCode) {
        this.status = status;
        this.message = message;
        this.result = result;
        this.statusCode=statusCode;
    }


//    public ApiResponse(String message, String token,Integer statusCode) {
//        this.message = message;
//        this.token = token;
//        this.statusCode=statusCode;
//    }
    
    public ApiResponse(String errorMessage) {
        this.statusCode = 400;
        this.status = false;
        this.message = errorMessage;
    }


//    public ApiResponse(String ticketString) {
//        this.statusCode = 500;
//        this.status = false;
//        this.message = "Error Occured during processing Request$" + ticketString;
//    }

    public ApiResponse(Boolean status, String message) {
        this.status = status;
        this.message = message;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getResult() {
        return result;
    }


    public void setResult(String result) {
        this.result = result;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }
}
