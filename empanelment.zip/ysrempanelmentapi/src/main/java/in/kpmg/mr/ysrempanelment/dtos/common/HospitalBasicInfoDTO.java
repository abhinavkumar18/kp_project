package in.kpmg.mr.ysrempanelment.dtos.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import in.kpmg.mr.ysrempanelment.models.common.DistrictMaster;
import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;
import in.kpmg.mr.ysrempanelment.models.common.MandalMaster;
import in.kpmg.mr.ysrempanelment.models.common.StateMaster;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Optional;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class HospitalBasicInfoDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    private String hospitalType;
    private Long hospRegId;
    private Long branchId;
    private String hospitalName;
    private String hospitalParentType;
    private String hospitalPan;
    private String alternateMobileNo;
    private String hospitalContactNumber;
    private String hospitalEmailId;
    private String yearofEstablishment;
    private String state;
    private String district;
    private String constituencyName;
    private String mandalOrMuncipalityName;
    private String nearestTownOrCityName;
    private String totalBedStrength;
    private String hospitalAddress;
    private String pinCode;
    private String mdOrCeoName;
    private String mdOrCeoMobileNumber;
    private String mdOrCeoAadharNumber;
    private String lattitude;
    private String longitude;
    private String password;
    private String hospitalOwnershipType;
    private String bankName;
    private String branchName;
    private String ifscCode;
    private String bankAccountType;
    private String hospitalAccountnumber;
    private String nameoftheAccountHolder;


    public static HospitalBasicInfoModel dtoToModel (HospitalBasicInfoDTO hospitalBasicInfoDTO)
    {
        HospitalBasicInfoModel hospitalBasicInfoModel = new HospitalBasicInfoModel();
        hospitalBasicInfoModel.setHOSP_NAME(hospitalBasicInfoDTO.getHospitalName());
        hospitalBasicInfoModel.setHospitalPan(hospitalBasicInfoDTO.getHospitalPan());
        hospitalBasicInfoModel.setHOSPITAL_CONTACT_NO(hospitalBasicInfoDTO.getHospitalContactNumber());
        hospitalBasicInfoModel.setALTERNATE_MOBILE_NO(Long.parseLong(hospitalBasicInfoDTO.getAlternateMobileNo()));
        hospitalBasicInfoModel.setESTD_YEAR(Integer.valueOf(hospitalBasicInfoDTO.getYearofEstablishment()));
        hospitalBasicInfoModel.setHOSP_DIST_ID(Long.valueOf(hospitalBasicInfoDTO.getDistrict()));
        hospitalBasicInfoModel.setHOSP_STATE_ID(Long.valueOf(hospitalBasicInfoDTO.getState()));
        if(hospitalBasicInfoDTO.getMandalOrMuncipalityName().equals("NULL") || hospitalBasicInfoDTO.getMandalOrMuncipalityName()==null){
            hospitalBasicInfoModel.setMANDAL_ID(null);}
        else
        {hospitalBasicInfoModel.setMANDAL_ID(Long.valueOf(hospitalBasicInfoDTO.getMandalOrMuncipalityName()));}
        hospitalBasicInfoModel.setCONSTITUENCY_ID(null);
        hospitalBasicInfoModel.setNRST_CITY(hospitalBasicInfoDTO.getNearestTownOrCityName());
        hospitalBasicInfoModel.setNRST_CITY("Null");
        hospitalBasicInfoModel.setHOSP_NAME(hospitalBasicInfoDTO.getHospitalName());
        hospitalBasicInfoModel.setHospitalPan(hospitalBasicInfoDTO.getHospitalPan());
        hospitalBasicInfoModel.setHOSPITAL_CONTACT_NO(hospitalBasicInfoDTO.getHospitalContactNumber());
        hospitalBasicInfoModel.setBED_STRENGTH(Long.parseLong(hospitalBasicInfoDTO.getTotalBedStrength()));
        hospitalBasicInfoModel.setHOSPITAL_ADDRESS(hospitalBasicInfoDTO.getHospitalAddress());
        hospitalBasicInfoModel.setHOSP_PIN(Long.parseLong(hospitalBasicInfoDTO.getPinCode()));
        hospitalBasicInfoModel.setCEO_NAME(hospitalBasicInfoDTO.getMdOrCeoName());
        hospitalBasicInfoModel.setCEO_MOB_NO(Long.parseLong(hospitalBasicInfoDTO.getMdOrCeoMobileNumber()));
        hospitalBasicInfoModel.setCEO_AADHR_NO(Long.parseLong(hospitalBasicInfoDTO.getMdOrCeoAadharNumber()));
        hospitalBasicInfoModel.setGEO_CODE_LATITUDE(hospitalBasicInfoDTO.getLattitude());
        hospitalBasicInfoModel.setGEO_CODE_LONGITUDE((hospitalBasicInfoDTO.getLongitude()));
        hospitalBasicInfoModel.setUPDATED_BY(null);
        hospitalBasicInfoModel.setIS_EMPNL("R");
        hospitalBasicInfoModel.setCREATED_BY(null);
        hospitalBasicInfoModel.setUPDATED_ON(null);
        Date date = new Date();
        Timestamp ts=new Timestamp(date.getTime());
        hospitalBasicInfoModel.setCREATED_ON(ts);
        return hospitalBasicInfoModel;
    }
}


