package in.kpmg.mr.ysrempanelment.dtos.common;

public interface SpecialitiesResult {
    String getDisMainId();

    String getDisMainName();
}
