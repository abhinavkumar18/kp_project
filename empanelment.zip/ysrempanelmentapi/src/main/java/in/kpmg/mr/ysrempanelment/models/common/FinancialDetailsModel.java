package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "EMPNL_FINANCIAL_MASTER")
public class FinancialDetailsModel {


    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "ysr.empnl_financial_master_id_seq")
    @SequenceGenerator(name = "ysr.empnl_financial_master_id_seq",sequenceName = "ysr.empnl_financial_master_id_seq", allocationSize = 1)
    private Long ID;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "BRANCH_ID",referencedColumnName ="BRANCH_ID")
    private BankMasterModel bankMasterModel;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPNL_ID",referencedColumnName ="EMPANL_ID")
    private HospitalBasicInfoModel hospitalBasicInfoModel;

//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "HOSPITAL_OWNERSHIP_ID",referencedColumnName ="CODE_TYPE_ID")
    private Long HOSPITAL_OWNERSHIP_ID;
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "BANK_ACCOUNT_TYPE",referencedColumnName = "CODE_TYPE_ID")
//    private Long BANK_ACCOUNT_TYPE;
    private String HOSP_ACC_NUM;
    private String HOSP_ACC_PATH;
    private String ACC_HOLDER_NAME;

}
