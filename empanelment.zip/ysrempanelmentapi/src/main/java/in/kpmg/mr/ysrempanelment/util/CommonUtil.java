package in.kpmg.mr.ysrempanelment.util;

import java.io.Reader;
import java.sql.Clob;

public class CommonUtil {
    public static String convertClobToString(Clob value) {
        try{
            if(value != null){
                Reader r = value.getCharacterStream();
                
                StringBuffer buffer = new StringBuffer();
                int ch;
                while ((ch = r.read())!=-1) {
                    buffer.append(""+(char)ch);
                }
                return buffer.toString();
            }else{
                return "";
            }
        }
        catch(Exception ex){
            return "";
        }
    }

    public static String checkNull(Object data){
        if(data != null){
            return data.toString();
        }
        return "";
    }

    public static Integer checkIntNull(Object data){
        if(data != null){
            return Integer.parseInt(data.toString());
        }
        return 0;
    }
    
    public static String populateQueryString(int counter){
    	StringBuilder str=new StringBuilder().append("?");
    	for(int i=1; i< counter; i++){
    		str.append(",").append("?");
    	}
    	return str.toString();
    }
    
}
