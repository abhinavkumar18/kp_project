//package in.kpmg.mr.ysrempanelment.models.common;
//
//import lombok.Data;
//import org.hibernate.annotations.CreationTimestamp;
//import org.hibernate.annotations.UpdateTimestamp;
//
//import javax.persistence.*;
//import java.sql.Timestamp;
//
//@Data
//@Entity
//@Table(name = "EHS_CLAIM_DOC_ATTACHMENT")
//public class EhsClaimDocModel {
//    @Id
//    @GeneratedValue(strategy = GenerationType.TABLE, generator = "EHS_CLAIM_DOC_ATTACHMENT_SEQ")
//    @SequenceGenerator(name = "EHS_CLAIM_DOC_ATTACHMENT_SEQ", sequenceName = "EHS_CLAIM_DOC_ATTACHMENT_SEQ", allocationSize = 1)
//    private Long ID;
//    private Long CLAIM_ID;
//    private Long DOC_TYPE_ID;
//    private String DOC_FILE_PATH;
//    private String CREATED_BY;
//    @CreationTimestamp
//    private Timestamp CREATED_ON;
//    private String UPDATED_BY;
//    @UpdateTimestamp
//    private Timestamp UPDATED_ON;
//
//}
