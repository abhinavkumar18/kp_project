package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.Data;

@Data
public class HospitalInfraAdditionalDetailsDTO {
	
	private Long EmpanlId;
	private String lvalue;
	private Long labelId;
	
}
