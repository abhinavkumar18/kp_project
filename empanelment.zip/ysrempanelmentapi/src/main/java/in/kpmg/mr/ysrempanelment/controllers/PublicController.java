package in.kpmg.mr.ysrempanelment.controllers;
/*
import java.util.List;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.kpmg.mr.nonempanelment.dtos.common.AdvanceCountSpecialitySearch;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceDistrictCount;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceDistrictList;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceHospitalSearch;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceMandalList;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceMitraDistrict;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceMitraDistrictCount;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceProcedureSearch;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceProcedureSpecialitySearch;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.mr.nonempanelment.dtos.common.AdvanceSpecialitySearchHospital;
import in.kpmg.mr.nonempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.nonempanelment.dtos.common.ApiResponse2;
import in.kpmg.mr.nonempanelment.dtos.common.CountSearchSpecialityResult;
import in.kpmg.mr.nonempanelment.dtos.common.DisplayResult;
import in.kpmg.mr.nonempanelment.dtos.common.DistrictCountResult;
import in.kpmg.mr.nonempanelment.dtos.common.DistrictListResult;
import in.kpmg.mr.nonempanelment.dtos.common.MandalListResult;
import in.kpmg.mr.nonempanelment.dtos.common.MitraDistrictResult;
import in.kpmg.mr.nonempanelment.dtos.common.MitraDistrictWiseCountResult;
import in.kpmg.mr.nonempanelment.dtos.common.MitraSearchResult;
import in.kpmg.mr.nonempanelment.dtos.common.SearchHospitalResult;
import in.kpmg.mr.nonempanelment.dtos.common.SearchProcedureResult;
import in.kpmg.mr.nonempanelment.dtos.common.SearchProcedureSpecialityResult;
import in.kpmg.mr.nonempanelment.dtos.common.SearchSpecialityResult;
import in.kpmg.mr.nonempanelment.dtos.common.SpecialitySearchHospitalResult;
import in.kpmg.mr.nonempanelment.dtos.common.StateCountResult;
import in.kpmg.mr.nonempanelment.dtos.common.StateListResult;
import in.kpmg.mr.nonempanelment.services.ErrorService;
import in.kpmg.mr.nonempanelment.services.PublicService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/public-ehs")
public class PublicController {
    
    @Autowired
    private PublicService pubServ;
    

    @Autowired
    private ErrorService eService;
    
    @GetMapping("/ehs-checkconn")
    public ApiResponse<?> checkconn() {
        //userServ.updateAllPassword()
        return new ApiResponse<>(true, "Connection is successfull.",null );
    } 
	@PostMapping("/searchHospital")
	public ApiResponse<?> advanceHospitalSearch(@RequestBody AdvanceSpecialitySearchHospital request) {

		try {

			List<SpecialitySearchHospitalResult> results = pubServ.advanceHospitalSearch(request);
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(SpecialitySearchHospitalResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getHospitalName());
	                if(position.getHospitalType().equalsIgnoreCase("C")) {
	                	jsonArray.put("Private");
	                }
	                else if(position.getHospitalType().equalsIgnoreCase("G")) {
	                	jsonArray.put("Government");
	                }
	                else {
	                	jsonArray.put("NA");
	                }
	                jsonArray.put(position.getState());
	                jsonArray.put(position.getDistrict());
	                jsonArray.put(position.getMandal());
	                jsonArray.put(position.getSpecialities());
	                jsonArray.put(position.getMitraContact());
	                jsonArray.put(position.getMitraName());
	                jsonArray.put(position.getMedcoContact());
	                jsonArray.put(position.getMedcoName());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}

    
//	updated
	@GetMapping("/searchProcedure")
	public ApiResponse<?> advanceProcedureSearch() {

		try {

			List<SearchProcedureResult> results = pubServ.advanceProcedureSearch();
			System.out.println(results.size());
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(SearchProcedureResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getSpecialityCode());
	                jsonArray.put(position.getSpecialityName());//surgdispCode is not there in EHS
	                jsonArray.put(position.getProcedureType());
	                jsonArray.put(position.getProcedureName());
	                jsonArray.put(position.getPackageAmount());//aasara amount not there in EHS
	                jsonArray.put(position.getPreInvestigations());//Post investigation not displayed in ehs
	                
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	            
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	
	@PostMapping("/procedurebyspeciality")
	public ApiResponse2<?> advanceProcedureSpecialitySearch(@RequestBody AdvanceProcedureSpecialitySearch request) {

		try {

			List<SearchProcedureSpecialityResult> results = pubServ.advanceProcedureSpecialitySearch(request);
			System.out.println(results.size());
			if (results.size() > 0) {
//				JSONArray jsonData = new JSONArray();
//	            for(SearchProcedureSpecialityResult position: results){
//	            	JSONArray jsonArray = new JSONArray();
//	                jsonArray.put(position.getSpecialityCode());
//	                jsonArray.put(position.getSpecialityName());//surgdispCode is not there in EHS
//	                jsonArray.put(position.getProcedureType());
//	                jsonArray.put(position.getProcedureName());
//	                jsonArray.put(position.getPackageAmount());//aasara amount not there in EHS
//	                jsonArray.put(position.getPreInvestigations());//Post investigation not displayed in ehs
//	                
//	                jsonData.put(jsonArray);
//	            }
	            return new ApiResponse2<>(true,"Search result found", results);
	            
			} else {
				return new ApiResponse2<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse2<>(eService.reportError(ex));
		}
	}

    //Updated 2-12-22
	@GetMapping("/hospital-statewisecount")
	public ApiResponse<?> advanceStateCount() {

		try {

			List<StateCountResult> results = pubServ.advanceStateCount();
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(StateCountResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	            	jsonArray.put(position.getStateId());
	                jsonArray.put(position.getStateName());
	                jsonArray.put(position.getGovt());
	                jsonArray.put(position.getPvt());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	            
				//return new ApiResponse2<>(true, "Search Results found.", results);
	            
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	//updated 7-12-22
	@PostMapping("/hospital-districtwisecount")
	public ApiResponse<?> advanceDistrictCount(@RequestBody AdvanceDistrictCount request) {

		try {

			List<DistrictCountResult> results = pubServ.advanceDistrictCount(request);
			//System.out.println(results.size());
			if (results.size() > 0) {
				JSONArray jsonData = new JSONArray();
	            for(DistrictCountResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	                jsonArray.put(position.getDistrictName());
	                jsonArray.put(position.getGovt());
	                jsonArray.put(position.getPvt());
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}

//	//updated 2-12-22
//	
//    //done
//	@GetMapping("/ehs-mitra-statewisecount")
//	public ApiResponse<?> advanceMitraSearch() {
//
//		try {
//
//			List<MitraSearchResult> results = pubServ.advanceMitraSearch();
//			if (results.size() > 0) {
//				JSONArray jsonData = new JSONArray();
//	            for(MitraSearchResult position: results){
//	            	JSONArray jsonArray = new JSONArray();
//	                jsonArray.put(position.getState());
//	                jsonArray.put(position.getMitraCount());
//	                jsonArray.put(position.getLocstateVal());
//	                jsonData.put(jsonArray);
//	            }
//	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
//	            
//				//return new ApiResponse2<>(true, "Search Results found.", results);
//	            
//			} else {
//				return new ApiResponse<>(false, "Search Results Not found.", null);
//			}
//
//		} catch (Exception ex) {
//			return new ApiResponse<>(eService.reportError(ex));
//		}
//	}
//	
//	@PostMapping("/ehs-mitra-districtwisecount")
//	public ApiResponse<?> advanceMitraDistrictWiseCount(@RequestBody AdvanceMitraDistrictCount request) {
//
//		try {
//
//			List<MitraDistrictWiseCountResult> results = pubServ.advanceMitraDistrictWiseCount(request);
//			if (results.size() > 0) {
//				JSONArray jsonData = new JSONArray();
//	            for(MitraDistrictWiseCountResult position: results){
//	            	JSONArray jsonArray = new JSONArray();
//	                jsonArray.put(position.getDistrictId());
//	                //jsonArray.put(position.getState());
//	                jsonArray.put(position.getDistrict());
//	                jsonArray.put(position.getMitraCount());
//	                jsonData.put(jsonArray);
//	            }
//	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
//	           // return new ApiResponse<>(true,"Search result found", results);
//			} else {
//				return new ApiResponse<>(false, "Search Results Not found.", null);
//			}
//
//		} catch (Exception ex) {
//			return new ApiResponse<>(eService.reportError(ex));
//		}
//	}
////	
//	@GetMapping("/ehs-mitra-search-districtwise")
//	public ApiResponse<?> advanceMitraDistrictCount() {
//
//		try {
//
//			List<MitraDistrictResult> results = pubServ.advanceMitraDistrictCount();
//			if (results.size() > 0) {
//				JSONArray jsonData = new JSONArray();
//	            for(MitraDistrictResult position: results){
//	            	JSONArray jsonArray = new JSONArray();
//	                jsonArray.put(position.getMitraName());
//	                jsonArray.put(position.getMitraContact());
//	                jsonArray.put(position.getDistrict());
//	                jsonArray.put(position.getHospitalId());
//	                jsonArray.put(position.getHospitalName());
//	                jsonArray.put(position.getSpeciality());
//	                jsonData.put(jsonArray);
//	            }
//	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
//	           // return new ApiResponse<>(true,"Search result found", results);
//			} else {
//				return new ApiResponse<>(false, "Search Results Not found.", null);
//			}
//
//		} catch (Exception ex) {
//			return new ApiResponse<>(eService.reportError(ex));
//		}
//	}
	//done
	@PostMapping("/specialitysearchcount")
	public ApiResponse<?> advanceCountSpecialitySearch(@RequestBody AdvanceCountSpecialitySearch request) {

		try {

			List<CountSearchSpecialityResult> results = pubServ.advanceCountSpecialitySearch(request);
			//System.out.println(results.size());
			if (results.size() > 0) {

				JSONArray jsonData = new JSONArray();
	            for(CountSearchSpecialityResult position: results){
	            	JSONArray jsonArray = new JSONArray();
	            	jsonArray.put(position.getSpeciality());
	                jsonArray.put(position.getProceduresCount());
	                jsonArray.put(position.getHospitalsCount());
//	                jsonArray.put(position.getDismainId()); 
	                
	                jsonData.put(jsonArray);
	            }
	            return new ApiResponse<>(true,"Search result found", jsonData.toString());
				
			} else {
				return new ApiResponse<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse<>(eService.reportError(ex));
		}
	}
	

	@GetMapping("/statelist")
	public ApiResponse2<?> displayStateList() {

		try {

			List<StateListResult> results = pubServ.displayStateList();
			System.out.println(results.size());
			if (results.size() > 0) {
//				JSONArray jsonData = new JSONArray();
//	            for(StateListResult position: results){
//	            	JSONArray jsonArray = new JSONArray();
//	                jsonArray.put(position.getStateId());
//	                jsonArray.put(position.getStateName());
//	                
//	                jsonData.put(jsonArray);
//	            }
	            return new ApiResponse2<>(true,"Search result found", results);
	            
			} else {
				return new ApiResponse2<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse2<>(eService.reportError(ex));
		}
	}
	
	@PostMapping("/districtlist")
	public ApiResponse2<?> displayDistrictList(@RequestBody AdvanceDistrictList request) {

		try {

			List<DistrictListResult> results = pubServ.displayDistrictList(request);
			System.out.println(results.size());
			if (results.size() > 0) {
//				JSONArray jsonData = new JSONArray();
//	            for(DistrictListResult position: results){	
//	            	JSONArray jsonArray = new JSONArray();
//	                jsonArray.put(position.getStateId());
//	                jsonArray.put(position.getDistrictId());
//	                jsonArray.put(position.getDistrictName());

	                
	                
	                //jsonArray.put(position.getDistrictid());
//	                jsonData.put(jsonArray);
//	            }
	            return new ApiResponse2<>(true,"Search result found", results);
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse2<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse2<>(eService.reportError(ex));
		}
		
	}
	
	
	@PostMapping("/mandallist")
	public ApiResponse2<?> displayMandalList(@RequestBody AdvanceMandalList request) {

		try {

			List<MandalListResult> results = pubServ.displayMandalList(request);
			System.out.println(results.size());
			if (results.size() > 0) {
//				JSONArray jsonData = new JSONArray();
//	            for(MandalListResult position: results){	
//	            	JSONArray jsonArray = new JSONArray();
//	                jsonArray.put(position.getStateId());
//	                jsonArray.put(position.getMandalId());
//	                jsonArray.put(position.getDistrictId());
//	                jsonArray.put(position.getMandal());
//	                //jsonArray.put(position.getDistrictid());
//	               jsonData.put(jsonArray);
//	            }
	            return new ApiResponse2<>(true,"Search result found", results);
	           // return new ApiResponse<>(true,"Search result found", results);
			} else {
				return new ApiResponse2<>(false, "Search Results Not found.", null);
			}

		} catch (Exception ex) {
			return new ApiResponse2<>(eService.reportError(ex));
		}
    }	
	
}
*/