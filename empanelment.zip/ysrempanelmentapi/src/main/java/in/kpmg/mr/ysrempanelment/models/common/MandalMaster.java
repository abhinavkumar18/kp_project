package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "YSR_MANDAL_MASTER")
public class MandalMaster {
    @Id
    private Long MANDAL_ID;
    private String MANDAL_NAME;
    private String MANDAL_CODE;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "DIST_ID",referencedColumnName ="DIST_ID")
    private DistrictMaster districtMaster;

}
