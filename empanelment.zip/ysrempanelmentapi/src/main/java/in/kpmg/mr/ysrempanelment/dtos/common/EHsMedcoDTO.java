package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EHsMedcoDTO {

    private String LocNo;
    private String LocAmount;
    private String LocPhoto;
    private String EmployeeType;
    private String DateofRegistration;
    private String EmployeeName;
    private String MobileNumber;
    private String PatientName;
    private String RelationWithEmployee;
    private String DOB;
    private String Age;
    private String Gender;
    private String District;
    private String State;
    private String EmployeeID;
    private String EmployeeDesignation;
    private String DepartmentName;
    private String PlaceOfWork;
    private String PLaceOfDistrict;



//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;
//    private String LocNo;

}
