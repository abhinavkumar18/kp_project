package in.kpmg.mr.ysrempanelment.services;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.SpecialityServicesFacilityDto;
import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;
import in.kpmg.mr.ysrempanelment.models.common.SpecialityServiceMappingModel;
import in.kpmg.mr.ysrempanelment.repositories.common.SpecialityServicesFacilityRepo;
import in.kpmg.mr.ysrempanelment.util.GetEmpanelUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class SpecialityServicesFacilityService {
    @Autowired
    GetEmpanelUtil getEmpanelUtil;
    @Autowired
    SpecialityServicesFacilityRepo specialityServicesFacilityRepo;

    public ApiResponse<?> saveSpecialityServices(SpecialityServicesFacilityDto specialityServicesFacilityDto) {
        try {

            for(int i=0;i<specialityServicesFacilityDto.getSpecialityId().size();i++) {
                SpecialityServiceMappingModel specialityServiceMappingModel = new SpecialityServiceMappingModel();
                HospitalBasicInfoModel hospitalBasicInfoModel = getEmpanelUtil.getModelwithId(specialityServicesFacilityDto.getHospRegId());
                specialityServiceMappingModel.setEMPANL_ID(hospitalBasicInfoModel);
                log.info("Speciality code : " + specialityServicesFacilityDto.getSpecialityId());
                specialityServiceMappingModel.setSpecialityId(specialityServicesFacilityDto.getSpecialityId().get(i));
                specialityServiceMappingModel.setIsActive(true);
                specialityServicesFacilityRepo.save(specialityServiceMappingModel);
            }

        } catch (Exception e) {
            e.printStackTrace();
            return new ApiResponse<>(false, "Unexpected Exception", null, HttpStatus.BAD_REQUEST.value());
        }

        return new ApiResponse<>(true, "Saved Succesfully", null, HttpStatus.OK.value());
    }

    public Map<String, Object> initiateApplication() {
        Map<String, Object> response = new HashMap<>();
        response.put("SpecialityCodes", specialityServicesFacilityRepo.getSpecialityCodeList());
        return response;
    }

    public Map<String, Object> initiateCombinationSpecApplication(Integer specialityId) {
        Map<String, Object> response = new HashMap<>();
        response.put("SpecialityCodes", specialityServicesFacilityRepo.getCombinationSpecialityCodeList(specialityId));
        return response;
    }
}
