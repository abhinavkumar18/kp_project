//package in.kpmg.mr.ysrempanelment.repositories.common;
//
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import in.kpmg.mr.ysrempanelment.models.common.UpdateRegID;
//
//public interface UpdateRegIDRepo extends CrudRepository<UpdateRegID, Long> {
//
//	@Query(value="Select ID, IS_REGISTERED,NWH,NON_EMPANL_ID from EHS_AIS_MR where ID= :id and NWH= :nwh and IS_REGISTERED= :RegisteredState " , nativeQuery=true )
//	public UpdateRegID findAisById(@PathVariable("nwh") String nwh,@PathVariable("RegisteredState") String RegisteredState, @PathVariable("id") Long id);
//
//}
