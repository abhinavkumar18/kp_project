//package in.kpmg.mr.ysrempanelment.models.common;
//
//import lombok.Data;
//
//import javax.persistence.*;
//import java.util.Date;
//
//@Data
//@Entity
//@Table(name = "EHS_AIS_MR")
//public class EhsAisMrMaster {
//    @Id
//    private Long ID;
//    private Long EMP_ID;
//    private String LOC_NUMBER;
//    private String PATIENT_NAME;
//    private Long AGE;
//    private String GENDER;
//    private String RELATION;
//    private Character NWH;
//    private String HOSPITAL_STATE;
//    private String HOSPITAL_DISTRICT;
//    private String HOSP_ID;
//    private Long CONTACT_NO;
//    private String TREATMENT_DESCRIPTION;
//    private Long LOC_AMOUNT;
//    private String LOC_PHOTO;
//    private String PHOTO;
//    private String EMPLOYEE_NAME;
//    private String  EMPLOYEE_DESIGNATION;
//    private String DEPARTMENT_NAME;
//    private String PLACE_OF_WORK;
//    private String PLACE_OF_DISTRICT;
//    private Date PATIENT_DOB;
//    private String STATE;
//    private String DISTRICT;
//    private String HOSP_NAME;
//    private String INWARD_ID;
//    private  Long  HOSP_CONTACT_NO;
//    private String HOSP_MAIL_ID;
//    private String HOSP_ADDRESS;
//    private String ESTIMATION_COPY;
//    private  Date  DATE_OF_REGISTRATION;
//    private Character IS_REGISTERED;
////    private Character IS_INITIATED;
//
//
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "NON_EMPANL_ID",referencedColumnName ="EMPANL_ID")
//    private HospitalBasicInfoModel hospitalBasicInfoModel;
//
//}
