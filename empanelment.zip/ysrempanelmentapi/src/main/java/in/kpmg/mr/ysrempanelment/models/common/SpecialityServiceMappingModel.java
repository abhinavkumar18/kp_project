package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table(name = "EMPNL_SPECIALITY_SERVICE_MAPPING")
public class SpecialityServiceMappingModel implements Serializable {
    @Id
    @Column(name="SPEC_ID",unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "empnl_speciality_service_mapping_spec_id_seq")
    @SequenceGenerator(name = "empnl_speciality_service_mapping_spec_id_seq",sequenceName = "empnl_speciality_service_mapping_spec_id_seq",initialValue = 1, allocationSize = 1)
    private Long SPEC_ID;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "EMPANL_ID",referencedColumnName ="EMPANL_ID")
   private HospitalBasicInfoModel EMPANL_ID;
    @Column(name = "SPECIALITY_ID")
    private Integer specialityId;
    @Column(name="IS_ACTIVE")
    private Boolean isActive ;
}
