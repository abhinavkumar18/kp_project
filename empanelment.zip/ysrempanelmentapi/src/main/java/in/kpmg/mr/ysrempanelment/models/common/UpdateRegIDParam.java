package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

@Data
public class UpdateRegIDParam {
	
	private Long id;
	private String hospRegId;

}
