package in.kpmg.mr.ysrempanelment.dtos.common;


public interface CodeValueResult {
	
	//Number getLabelId();
	Number getTypeId();
	String getTypeName();
}
