package in.kpmg.mr.ysrempanelment.repositories.common;

import in.kpmg.mr.ysrempanelment.models.common.DistrictMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DistrictMasterRepo extends JpaRepository<DistrictMaster,Long> {
}
