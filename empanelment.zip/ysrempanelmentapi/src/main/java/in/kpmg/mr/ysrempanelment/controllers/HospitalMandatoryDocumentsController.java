package in.kpmg.mr.ysrempanelment.controllers;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.HospitalMandatoryDocumentsDto;
import in.kpmg.mr.ysrempanelment.services.HospitalMandatoryDocumentsService;
import in.kpmg.mr.ysrempanelment.util.SaveDocumentsUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.CONTENT_TYPE;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
public class HospitalMandatoryDocumentsController {

    @Autowired
    HospitalMandatoryDocumentsService hospitalMandatoryDocumentsService;
    @Autowired
    SaveDocumentsUtil saveDocumentsUtil;

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping(value = "/uploadDocuments",
            consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE},
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE}
    )
    public ApiResponse<?> hospitalMandatoryDocument(@RequestPart(value = "files") List<MultipartFile> files,
                                                 @RequestPart(value = "hospitalMandatoryDocumentsDto") HospitalMandatoryDocumentsDto hospitalMandatoryDocumentsDto) throws IOException {

        return hospitalMandatoryDocumentsService.hospitalMandtoryDoc(files, hospitalMandatoryDocumentsDto);
    }
}



