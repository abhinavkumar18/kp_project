package in.kpmg.mr.ysrempanelment.repositories.common;

import in.kpmg.mr.ysrempanelment.models.common.CodeValueMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CodeValueRepo extends JpaRepository <CodeValueMaster,Long>{
    CodeValueMaster findByValue(String hospitalOwnershipType);
}
