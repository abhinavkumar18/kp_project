package in.kpmg.mr.ysrempanelment.services;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.GeneralInfrastructureDto;
import in.kpmg.mr.ysrempanelment.models.common.EmpnlGeneralInfrastructure;
import in.kpmg.mr.ysrempanelment.models.common.EmpnlLableMaster;
import in.kpmg.mr.ysrempanelment.models.common.EmpnlQstMaster;
import in.kpmg.mr.ysrempanelment.models.common.GeneralDetails;
import in.kpmg.mr.ysrempanelment.models.common.YsrUserMaster;
import in.kpmg.mr.ysrempanelment.models.common.EmpnlAttachmentTypes;
import in.kpmg.mr.ysrempanelment.models.common.EmpnlGeneralAttachmentMain;
import in.kpmg.mr.ysrempanelment.repositories.common.EmpnlAttachmentTypesRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.EmpnlGeneralAttachmentMainRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.EmpnlGeneralInfrastructureRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.EmpnlLableMasterRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.EmpnlQstMasterRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.GeneralDetailsRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.YsrUserMasterRepo;
import in.kpmg.mr.ysrempanelment.util.SaveDocumentsUtil;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GeneralInfrastructureService {
	public static final List<String> CONTENT_TYPE = Arrays.asList("application/pdf","image/jpeg", "image/png", "image/jpg");
	public static  final String APPLICATION= "data:application/pdf;base64,";
	public static final String IMAGE="data:image/jpeg;base64,";
	
	@Autowired
	EmpnlQstMasterRepo empnlQstMasterRepo;
	
	@Autowired
	YsrUserMasterRepo userRepo;
	
	@Autowired
	EmpnlGeneralInfrastructureRepo empnlGeneralInfrastructureRepo;
	
	@Autowired
	GeneralDetailsRepo generalDetailsRepo;
	
	@Autowired
	EmpnlLableMasterRepo empnlLableMasterRepo;
	
	@Autowired
	EmpnlAttachmentTypesRepo empnlAttachmentTypesRepo;
	
	@Autowired
	EmpnlGeneralAttachmentMainRepo empnlGeneralAttachmentMainRepo;
	
	@Autowired
    SaveDocumentsUtil saveDocuments;
	
	public ApiResponse<?> saveGeneralInfrastructure(List<MultipartFile> files,List<GeneralInfrastructureDto> generalInfrastructureDto){

		try {
			String location = "";
			location="/home/kpmg/jarwar/AsriDocs";
			for (int j = 0; j < files.size(); j++) {
			if (!CONTENT_TYPE.contains(files.get(j).getContentType()))
                return new ApiResponse<>(false, "Incorrect File Format", "", HttpStatus.NO_CONTENT.value());}
			for(int i=0;i<generalInfrastructureDto.size();i++) {

//			*******storing general Details********
			if(generalInfrastructureDto.get(i).getLabelId()==21 && generalInfrastructureDto.get(i).getQstId()==76) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
			Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
			if(qstId.isPresent())
				empnlGeneralInfrastructure.setQstId(qstId.get());
				
			Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
			if(empanlId.isPresent())
				empnlGeneralInfrastructure.setEmpanlId(empanlId.get());

			empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
			empnlGeneralInfrastructure.setNumbers(null);
			empnlGeneralInfrastructure.setAvailability(null);
			empnlGeneralInfrastructure.setIsActive(true);
			
			Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
			if(crtBy.isPresent())
				empnlGeneralInfrastructure.setCrtBy(crtBy.get());
			
			Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
			if(updBy.isPresent())
				empnlGeneralInfrastructure.setUpdBy(updBy.get());
			empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
			
			String fileName = saveDocuments.saveDocuments(files.get(0), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
			EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
			empnlGeneralAttachmentMain.setQstMst(qstId.get());
			empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
			
			Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
			if(lableId.isPresent())
				empnlGeneralAttachmentMain.setLableQst(lableId.get());
			
			Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
			if(typeId.isPresent())
				empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
			
			empnlGeneralAttachmentMain.setAttachmentPath(fileName);
			empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
			empnlGeneralAttachmentMain.setUpdBy(updBy.get());
			empnlGeneralAttachmentMain.setIsActive(true);
			empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
			
			}
//			********storing ward infrastructure Details********
			if(generalInfrastructureDto.get(i).getLabelId()==22 && generalInfrastructureDto.get(i).getQstId()==77) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==22 && generalInfrastructureDto.get(i).getQstId()==78) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==22 && generalInfrastructureDto.get(i).getQstId()==79) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==22 && generalInfrastructureDto.get(i).getQstId()==80) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(generalInfrastructureDto.get(i).getNumbers());
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==22 && generalInfrastructureDto.get(i).getQstId()==81) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
//			********Storing Operation Theatre Details*******
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==82) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(1), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==83) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==84) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==85) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==86) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==87) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==88) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(2), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==89) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(3), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==90) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(4), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==91) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(5), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==23 && generalInfrastructureDto.get(i).getQstId()==92) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(6), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
//			*******Diagnostic Centre Radiology Basic Details*******
			if(generalInfrastructureDto.get(i).getLabelId()==24 && generalInfrastructureDto.get(i).getQstId()==93) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(7), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==24 && generalInfrastructureDto.get(i).getQstId()==94) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==24 && generalInfrastructureDto.get(i).getQstId()==95) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==24 && generalInfrastructureDto.get(i).getQstId()==96) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==24 && generalInfrastructureDto.get(i).getQstId()==97) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==24 && generalInfrastructureDto.get(i).getQstId()==98) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==24 && generalInfrastructureDto.get(i).getQstId()==99) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(generalInfrastructureDto.get(i).getArea());
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(null);
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				}
//			*****Storing Diagnostic centre Radiology Advanced Details*****
			if(generalInfrastructureDto.get(i).getLabelId()==25 && generalInfrastructureDto.get(i).getQstId()==100) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(8), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==25 && generalInfrastructureDto.get(i).getQstId()==101) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(9), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==25 && generalInfrastructureDto.get(i).getQstId()==102) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(10), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
//			******Storing Diagnostic Centre Laboratory Basic Details*******
			if(generalInfrastructureDto.get(i).getLabelId()==26 && generalInfrastructureDto.get(i).getQstId()==103) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(11), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==26 && generalInfrastructureDto.get(i).getQstId()==104) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(12), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==26 && generalInfrastructureDto.get(i).getQstId()==105) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(13), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
//			******* Storing Diagnostic Centre Laboratory Advanced Details ********
			if(generalInfrastructureDto.get(i).getLabelId()==27 && generalInfrastructureDto.get(i).getQstId()==106) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(14), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==27 && generalInfrastructureDto.get(i).getQstId()==107) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(15), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==27 && generalInfrastructureDto.get(i).getQstId()==108) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(16), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			
			if(generalInfrastructureDto.get(i).getLabelId()==27 && generalInfrastructureDto.get(i).getQstId()==109) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(17), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			if(generalInfrastructureDto.get(i).getLabelId()==27 && generalInfrastructureDto.get(i).getQstId()==110) {
				EmpnlGeneralInfrastructure empnlGeneralInfrastructure = new EmpnlGeneralInfrastructure();
				Optional<EmpnlQstMaster> qstId = empnlQstMasterRepo.findById(generalInfrastructureDto.get(i).getQstId());
				if(qstId.isPresent())
					empnlGeneralInfrastructure.setQstId(qstId.get());
				
				Optional<GeneralDetails> empanlId = generalDetailsRepo.findById(generalInfrastructureDto.get(i).getEmpanlId());
				if(empanlId.isPresent())
					empnlGeneralInfrastructure.setEmpanlId(empanlId.get());
				empnlGeneralInfrastructure.setArea(null);
				empnlGeneralInfrastructure.setNumbers(null);
				empnlGeneralInfrastructure.setAvailability(generalInfrastructureDto.get(i).getAvailability());
				empnlGeneralInfrastructure.setIsActive(true);
				
				Optional<YsrUserMaster> crtBy = userRepo.findById(generalInfrastructureDto.get(i).getCrtBy());
				if(crtBy.isPresent())
					empnlGeneralInfrastructure.setCrtBy(crtBy.get());
				
				Optional<YsrUserMaster> updBy = userRepo.findById(generalInfrastructureDto.get(i).getUpdBy());
				if(updBy.isPresent())
					empnlGeneralInfrastructure.setUpdBy(updBy.get());
				empnlGeneralInfrastructureRepo.save(empnlGeneralInfrastructure);
				
				String fileName = saveDocuments.saveDocuments(files.get(18), String.valueOf(generalInfrastructureDto.get(i).getQstId()), location);
				EmpnlGeneralAttachmentMain empnlGeneralAttachmentMain=new EmpnlGeneralAttachmentMain();
				empnlGeneralAttachmentMain.setQstMst(qstId.get());
				empnlGeneralAttachmentMain.setGeneralDetails(empanlId.get());
				
				Optional<EmpnlLableMaster> lableId = empnlLableMasterRepo.findById(generalInfrastructureDto.get(i).getLabelId());
				if(lableId.isPresent())
					empnlGeneralAttachmentMain.setLableQst(lableId.get());
				
				Optional<EmpnlAttachmentTypes> typeId = empnlAttachmentTypesRepo.findById(generalInfrastructureDto.get(i).getTypeId());
				if(typeId.isPresent())
					empnlGeneralAttachmentMain.setAttachmentTypes(typeId.get());
				
				empnlGeneralAttachmentMain.setAttachmentPath(fileName);
				empnlGeneralAttachmentMain.setCrtBy(crtBy.get());
				empnlGeneralAttachmentMain.setUpdBy(updBy.get());
				empnlGeneralAttachmentMain.setIsActive(true);
				empnlGeneralAttachmentMainRepo.save(empnlGeneralAttachmentMain);
				}
			}
			log.info("Saving General Infrastructure Basic Units Details");

			return new ApiResponse<>(true,"General Infrastructure Basic Units Details Saved","", HttpStatus.OK.value());

		}catch(Exception e) {
			e.printStackTrace();
			return new ApiResponse<>(false,"Error saving info","",HttpStatus.NO_CONTENT.value());

		}
		
	}

}
