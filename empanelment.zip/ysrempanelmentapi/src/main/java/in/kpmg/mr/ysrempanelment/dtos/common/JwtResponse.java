package in.kpmg.mr.ysrempanelment.dtos.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class JwtResponse {
    private Boolean status;
    private String jwtToken;
    private String message;

    private String hospRegId;
    private Integer code;
}
