//package in.kpmg.mr.ysrempanelment.controllers;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
//import in.kpmg.mr.ysrempanelment.dtos.common.EhsClaimDTO;
//import in.kpmg.mr.ysrempanelment.dtos.common.ListofHospitalsDto;
//import in.kpmg.mr.ysrempanelment.dtos.common.SearchAisDetailsCashlessDTO;
//import in.kpmg.mr.ysrempanelment.models.common.FetchRegHospInboxParameter;
//import in.kpmg.mr.ysrempanelment.models.common.SearchAisParameter;
//import in.kpmg.mr.ysrempanelment.models.common.UpdateRegIDParam;
//import in.kpmg.mr.ysrempanelment.services.AisCashlessService;
//import in.kpmg.mr.ysrempanelment.services.UserService;
//import in.kpmg.mr.ysrempanelment.util.JWTUtility;
//import lombok.extern.slf4j.Slf4j;
//
//@RestController
//@Slf4j
//@RequestMapping()
//@CrossOrigin(origins = "*", allowedHeaders = "*")
//public class AisCashlessController {
//
//	@Autowired
//	AisCashlessService aisCashlessService;
//
//	@Autowired
//	private JWTUtility jwtUtility;
//
//	@Autowired
//	private AuthenticationManager authenticationManager;
//
//	@Autowired
//	private UserService userService;
//
//
//	@GetMapping("/registered-hospitals")
//	@CrossOrigin(origins = "*", allowedHeaders = "*")
//	public List<ListofHospitalsDto> listofHospitals() {
//		log.info("Request received to access registered hospital API");
//		return aisCashlessService.getNonEmpnlHospital();
//	}
//
//	@PostMapping("/search-ais-cashless")
//	@CrossOrigin(origins = "*", allowedHeaders = "*")
//	public List<SearchAisDetailsCashlessDTO> searchAisDetailsCashless(@RequestBody SearchAisParameter searchAisParameter){
//		log.info("Request received to search AisDetails forCashless API");
//		return aisCashlessService.searchAisDetailsCashless(searchAisParameter);
//	}
//
//	@PostMapping("/update-hospital-mapping")
//	@CrossOrigin(origins = "*", allowedHeaders = "*")
//	public ApiResponse<?> UpdateRegdID(@RequestBody UpdateRegIDParam updateRegID){
//		log.info("Request received to update: "+updateRegID.getId());
//		return aisCashlessService.UpdateRegID(updateRegID);
//	}
//
//	@PostMapping("/fetch/inbox")
//	@CrossOrigin(origins = "*", allowedHeaders = "*")
//	public List<SearchAisDetailsCashlessDTO> fetchRegHospInbox(@RequestBody FetchRegHospInboxParameter fetchRegHospInboxParameter){
//		log.info("Request received to search AisDetails forCashless API");
//		return aisCashlessService.fetchRegHospInbox(fetchRegHospInboxParameter);
//	}
//
//	@PostMapping("/initiate-claim")
//	@CrossOrigin(origins = "*", allowedHeaders = "*")
//	public ApiResponse<?> initiateClaims(@RequestBody EhsClaimDTO ehsClaimDTO){
//		log.info("Request received to search AisDetails forCashless API");
//		return aisCashlessService.initiateClaims(ehsClaimDTO);
//	}
//
//
//}
