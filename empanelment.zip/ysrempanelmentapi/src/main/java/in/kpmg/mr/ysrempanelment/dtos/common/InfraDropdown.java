package in.kpmg.mr.ysrempanelment.dtos.common;

public interface InfraDropdown {
    Number getValueId();
    String getValueName();
}
