package in.kpmg.mr.ysrempanelment.models.common;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;

@Entity
@Table(name="EMPNL_HOSP_INFRA_DETAILS")
@Data
public class HospitalInfraDetailsModel {
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "empnl_hosp_infra_details_infra_id_seq")
	@SequenceGenerator(name = "empnl_hosp_infra_details_infra_id_seq",sequenceName = "empnl_hosp_infra_details_infra_id_seq",allocationSize = 1)
	private Long INFRA_ID;
	private Long EMPANL_ID;
	private Long LABEL_VALUE_ID;
	private String ATTACHMENT_FILE_PATH;
	@CreationTimestamp
	private Timestamp CREATED_ON;
	private Long CREATED_BY;
	@CreationTimestamp
	private Timestamp UPDATED_ON;
	private Long UPDATED_BY;
	private String L_VALUES;
	
}
