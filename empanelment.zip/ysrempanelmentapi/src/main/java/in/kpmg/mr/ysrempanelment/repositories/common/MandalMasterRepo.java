package in.kpmg.mr.ysrempanelment.repositories.common;

import in.kpmg.mr.ysrempanelment.models.common.MandalMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MandalMasterRepo extends JpaRepository<MandalMaster,Long> {
}
