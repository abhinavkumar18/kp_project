package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "YSR_STATE_MASTER")
public class StateMaster {
    @Id
    private Long STATE_ID;
    private Long STATE_CODE;
    private String STATE_NAME;
    private Boolean IS_STATE_ACTIVE;

}
