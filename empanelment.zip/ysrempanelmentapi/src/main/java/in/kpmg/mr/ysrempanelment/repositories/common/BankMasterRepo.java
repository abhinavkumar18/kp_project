package in.kpmg.mr.ysrempanelment.repositories.common;

import in.kpmg.mr.ysrempanelment.models.common.BankMasterModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BankMasterRepo extends JpaRepository<BankMasterModel,Long> {
}
