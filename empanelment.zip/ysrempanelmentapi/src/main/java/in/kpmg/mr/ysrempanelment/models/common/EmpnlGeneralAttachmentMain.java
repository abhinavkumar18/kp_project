package in.kpmg.mr.ysrempanelment.models.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "empnl_general_attachments")
@NoArgsConstructor
@AllArgsConstructor
public class EmpnlGeneralAttachmentMain {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name = "attach_id")
    private Long attachId;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "qst_id", referencedColumnName = "qst_id")
    private EmpnlQstMaster qstMst;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "empanl_id", referencedColumnName = "empanl_id")
    private GeneralDetails generalDetails;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "lable_id", referencedColumnName = "lable_id")
    private EmpnlLableMaster lableQst;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "type_id", referencedColumnName = "type_id")
    private EmpnlAttachmentTypes attachmentTypes;

    @Column(name = "attachment_path")
    private String attachmentPath;

    @Column(name = "display_order")
    private Integer displayOrder;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "crt_by", referencedColumnName = "user_id")
    private YsrUserMaster crtBy;
    
    @Column(name = "crt_on")
    @CreationTimestamp
    private Timestamp crtOn;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "upd_by", referencedColumnName = "user_id")
    private YsrUserMaster updBy;
    
    @Column(name = "upd_on")
    @UpdateTimestamp
    private Timestamp updOn;

    @Column (name = "is_active")
    private Boolean isActive;


}
