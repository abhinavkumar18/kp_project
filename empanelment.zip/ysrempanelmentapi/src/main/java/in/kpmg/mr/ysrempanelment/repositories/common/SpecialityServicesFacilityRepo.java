package in.kpmg.mr.ysrempanelment.repositories.common;

import in.kpmg.mr.ysrempanelment.dtos.common.CodeNameResult;
import in.kpmg.mr.ysrempanelment.dtos.common.CodeValueResult;
import in.kpmg.mr.ysrempanelment.dtos.common.CombinationSpecialityResult;
import in.kpmg.mr.ysrempanelment.dtos.common.SpecialityCodeResult;
import in.kpmg.mr.ysrempanelment.models.common.SpecialityServiceMappingModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SpecialityServicesFacilityRepo extends JpaRepository<SpecialityServiceMappingModel,Long> {
    @Query(value="select speciality_code specialityCode,speciality_name specialityName ,speciality_id specialityId from ysr.ysr_SPECIALITIES order by display_order",nativeQuery = true)
    List<SpecialityCodeResult> getSpecialityCodeList();
    @Query(value = "select yscm.speciality_id as specialityId,yscm.combo_speciality_id as combinationSpecialityId,ys2.speciality_name  ||' ('||ys2.speciality_code||')'as specialityName\n" +
            "from ysr.ysr_speciality_combination_mapping yscm  \n" +
            "join ysr.ysr_specialities ys2  on yscm.combo_speciality_id = ys2.speciality_id\n" +
            "where yscm.speciality_id =:specialityId",nativeQuery = true)
    List<CombinationSpecialityResult> getCombinationSpecialityCodeList(Integer specialityId);
}
