package in.kpmg.mr.ysrempanelment.services;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.DocInfoDTO;
import in.kpmg.mr.ysrempanelment.dtos.common.HospitalInfraDetailsDTO;
import in.kpmg.mr.ysrempanelment.dtos.common.PayloadDTO;
import in.kpmg.mr.ysrempanelment.models.common.HospitalInfraAdditionalDetailsModel;
import in.kpmg.mr.ysrempanelment.models.common.HospitalInfraDetailsModel;
import in.kpmg.mr.ysrempanelment.repositories.common.HospitalInfraAdditionalDetailsRepo;
import in.kpmg.mr.ysrempanelment.repositories.common.HospitalInfraDetailsRepo;
import in.kpmg.mr.ysrempanelment.util.SaveDocumentsUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.sql.Timestamp;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.CONTENT_TYPE;
import static in.kpmg.mr.ysrempanelment.dtos.common.EmpanelConstants.FILE_STORAGE_LOCATION;


@Service
public class HospitalInfraDetailsService {
    @Autowired
    HospitalInfraDetailsRepo hospitalInfraDetailsRepo;
    @Autowired
    HospitalInfraAdditionalDetailsRepo hospitalInfraAdditionalDetailsRepo;

    @Autowired
    SaveDocumentsUtil saveDocuments;

//    public ApiResponse<?> savehospitalinfra(HospitalInfraDetailsDTO hospitalInfraDetailsDTOList, String fileName) {
////		List<HospitalInfraDetailsModel> result=new ArrayList<>();
////		List<HospitalInfraAdditionalDetailsModel> result2=new ArrayList<>();
//        try {
//
//            Date date = new Date();
//            Timestamp ts = new Timestamp(date.getTime());
//            HospitalInfraDetailsModel hospitalInfraDetailsModel = new HospitalInfraDetailsModel();
//            HospitalInfraAdditionalDetailsModel hospitalInfraAdditionalDetailsModel = new HospitalInfraAdditionalDetailsModel();
//            HospitalInfraDetailsDTO temp = hospitalInfraDetailsDTOList;
//            //System.out.println(temp.getHospitalInfraAdditionalDetailsList().get(0));
//
//            if (temp.getHospitalInfraAdditionalDetailsList() != null) {
//                hospitalInfraAdditionalDetailsModel.setEMPANL_ID(temp.getHospitalInfraAdditionalDetailsList().get(0).getEmpanlId());
//                hospitalInfraAdditionalDetailsModel.setL_VALUE(temp.getHospitalInfraAdditionalDetailsList().get(0).getLvalue());
//                String filePath = FILE_STORAGE_LOCATION + "/" + fileName;
//                hospitalInfraAdditionalDetailsModel.setLABLE_DOC(filePath.replaceAll("\\\\", "\\/"));
//                hospitalInfraAdditionalDetailsModel.setCREATED_ON(ts);
//                hospitalInfraAdditionalDetailsModel.setCREATED_BY("Test");
//                hospitalInfraAdditionalDetailsModel.setUPDATED_ON(null);
//                hospitalInfraAdditionalDetailsModel.setUPDATED_BY(null);
//                hospitalInfraAdditionalDetailsModel.setLABEL_ID(temp.getHospitalInfraAdditionalDetailsList().get(0).getLabelId());
//                //result2.add(hospitalInfraAdditionalDetailsModel);
//                hospitalInfraAdditionalDetailsRepo.save(hospitalInfraAdditionalDetailsModel);
//            } else {
//                hospitalInfraDetailsModel.setEMPANL_ID(temp.getEmpanlId());
//                hospitalInfraDetailsModel.setLABEL_VALUE_ID(temp.getLabelValueId());
//                String filePath = FILE_STORAGE_LOCATION + "/" + fileName;
//                hospitalInfraDetailsModel.setATTACHMENT_FILE_PATH(filePath.replaceAll("\\\\", "\\/"));
//                hospitalInfraDetailsModel.setCREATED_ON(ts);
//                hospitalInfraDetailsModel.setCREATED_BY("Test");
//                hospitalInfraDetailsModel.setUPDATED_ON(null);
//                hospitalInfraDetailsModel.setUPDATED_BY(null);
//                //result.add(hospitalInfraDetailsModel);
//                hospitalInfraDetailsRepo.save(hospitalInfraDetailsModel);
//            }
//
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new ApiResponse<>(false, "Unexpected Exception", null, HttpStatus.BAD_REQUEST.value());
//        }
//
//        return new ApiResponse<>(true, "Saved Succesfully", null, HttpStatus.OK.value());
//    }

    public Map<String, Object> infraInitiateApplication() {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("Standardized Archetectural Design", hospitalInfraDetailsRepo.getAllCodeValueList(1));
        response.put("Fire Fighting System", hospitalInfraDetailsRepo.getAllCodeValueList(2));
        response.put("Bio Medical Waste Management", hospitalInfraDetailsRepo.getAllCodeValueList(3));
        response.put("Separate Parking Area for Staff and Public Vehicles", hospitalInfraDetailsRepo.getAllCodeValueList(5));
        response.put("Generator / Power Backup", hospitalInfraDetailsRepo.getAllCodeValueList(6));
        response.put("Lift Provision", hospitalInfraDetailsRepo.getAllCodeValueList(8));
        response.put("Ramp Provision", hospitalInfraDetailsRepo.getAllCodeValueList(9));
        response.put("Advanced Lab Diagnostic Services", hospitalInfraDetailsRepo.getAllCodeValueList(10));
        response.put("Advanced Radio Diagnostic Services", hospitalInfraDetailsRepo.getAllCodeValueList(11));
        response.put("Pharmacy", hospitalInfraDetailsRepo.getAllCodeValueList(12));
        response.put("Blood Bank", hospitalInfraDetailsRepo.getAllCodeValueList(13));
        response.put("Ambulance", hospitalInfraDetailsRepo.getAllCodeValueList(14));
        response.put("Canteen / Pantry", hospitalInfraDetailsRepo.getAllCodeValueList(15));
        return response;
    }

    public ApiResponse<?> uploadfiles(List<MultipartFile> files, List<DocInfoDTO> docInfoDTOS, List<HospitalInfraDetailsDTO> hospitalInfraDetailsDTO) {
        if (files.size() == 0 && files.size() <8)
            return new ApiResponse<>(false, "Please attach All The files", "", HttpStatus.NO_CONTENT.value());
        for (int i = 0; i < files.size(); i++) {
            if (files.get(i).isEmpty() || docInfoDTOS.get(i).getHosRegId() == null)
                return new ApiResponse<>(false, "Incorrect Payload", "", HttpStatus.NO_CONTENT.value());
            Boolean status;
            DocInfoDTO docInfoDTO = docInfoDTOS.get(i);

            if (!CONTENT_TYPE.contains(files.get(i).getContentType()))
                return new ApiResponse<>(false, "Incorrect File Format", "", HttpStatus.NO_CONTENT.value());
            if (CONTENT_TYPE.contains(files.get(i).getContentType())) {
                String Location = "";
                if (docInfoDTO.getLabelValueId().equals("1"))
                    Location = "/home/kpmg/HospitalInfraDocs/StandardizedArchitecturalDesign";
                  //   Location = "C:\\multipartfile\\StandardizedArchitecturalDesign";
                if (docInfoDTO.getLabelValueId().equals("2"))
                  Location = "/home/kpmg/HospitalInfraDocs/Fire Fighting System";
               //            Location = "C:\\multipartfile\\Fire Fighting System";

                if (docInfoDTO.getLabelValueId().equals("3"))
                   Location = "/home/kpmg/HospitalInfraDocs/Bio Medical Waste Management";
                 //            Location = "C:\\multipartfile\\Bio Medical Waste Management";
                if (docInfoDTO.getLabelValueId().equals("4"))
                   Location = "/home/kpmg/HospitalInfraDocs/General Ward(500-10000Sq.Ft)";
              //             Location = "C:\\multipartfile\\General Ward(500-10000Sq.Ft)";
                if (docInfoDTO.getLabelValueId().equals("5"))
                    Location = "/home/kpmg/HospitalInfraDocs/Separate Parking Area for Staff and Public Vehicles";
              //             Location = "C:\\multipartfile\\Separate Parking Area for Staff and Public Vehicles";
                if (docInfoDTO.getLabelValueId().equals("6"))
                    Location = "/home/kpmg/HospitalInfraDocs/Generator-Power Backup";
            //               Location = "C:\\multipartfile\\Generator - Power Backup";
                if (docInfoDTO.getLabelValueId().equals("8"))
                   Location = "/home/kpmg/HospitalInfraDocs/Lift Provision";
              //             Location = "C:\\multipartfile\\Lift Provision";
                if (docInfoDTO.getLabelValueId().equals("9"))
                Location = "/home/kpmg/HospitalInfraDocs/Ramp Provision";
            //              Location = "C:\\multipartfile\\Ramp Provision";
                if (docInfoDTO.getLabelValueId().equals(""))
                    return new ApiResponse<>(false, "Error saving doc", "", HttpStatus.NO_CONTENT.value());


                    String fileName = saveDocuments.saveDocuments(files.get(i), String.valueOf(docInfoDTOS.get(i).getHosRegId()), Location);
                if (StringUtils.hasText(fileName)) {
                    status = savemedcodocs(docInfoDTOS.get(i), fileName);

//                    if(status)
//                        continue;
                    if (status == false){
                        return new ApiResponse<>(false, "Error saving info", "", HttpStatus.NO_CONTENT.value());

                    }
                }
            }
        }

        for (HospitalInfraDetailsDTO hospitalInfraDetailsDTO1 : hospitalInfraDetailsDTO) {
            try {
                Date date = new Date();
                Timestamp ts = new Timestamp(date.getTime());
                HospitalInfraDetailsModel hospitalInfraDetailsModel = new HospitalInfraDetailsModel();
                hospitalInfraDetailsModel.setEMPANL_ID(hospitalInfraDetailsDTO1.getHosRegId());
                hospitalInfraDetailsModel.setATTACHMENT_FILE_PATH(null);
                hospitalInfraDetailsModel.setL_VALUES(hospitalInfraDetailsDTO1.getLabelValue());
                hospitalInfraDetailsModel.setLABEL_VALUE_ID(hospitalInfraDetailsDTO1.getLabelValueId());
                hospitalInfraDetailsModel.setCREATED_ON(ts);
                hospitalInfraDetailsModel.setCREATED_BY(3L);
                hospitalInfraDetailsModel.setUPDATED_ON(null);
                hospitalInfraDetailsModel.setUPDATED_BY(null);
                //result.add(hospitalInfraDetailsModel);
                hospitalInfraDetailsRepo.save(hospitalInfraDetailsModel);
            } catch (Exception e) {
                e.printStackTrace();
                return new ApiResponse<>(false, "Unexpected Exception", null, HttpStatus.BAD_REQUEST.value());
            }

        }
        return new ApiResponse<>(true, "Saved", "", HttpStatus.OK.value());

    }

    private Boolean savemedcodocs(DocInfoDTO docInfoDTO, String fileName) {
        try {
            Date date = new Date();
            Timestamp ts = new Timestamp(date.getTime());
            HospitalInfraDetailsModel hospitalInfraDetailsModel = new HospitalInfraDetailsModel();
            hospitalInfraDetailsModel.setLABEL_VALUE_ID(Long.valueOf(docInfoDTO.getLabelValueId()));
            hospitalInfraDetailsModel.setL_VALUES(docInfoDTO.getLabelValue());
            hospitalInfraDetailsModel.setEMPANL_ID(docInfoDTO.getHosRegId());
            hospitalInfraDetailsModel.setATTACHMENT_FILE_PATH(fileName);
            hospitalInfraDetailsModel.setCREATED_ON(ts);
            hospitalInfraDetailsModel.setCREATED_BY(3L);
     //       hospitalInfraDetailsModel.setUPDATED_ON(ts);
            hospitalInfraDetailsModel.setUPDATED_BY(null);
            hospitalInfraDetailsRepo.save(hospitalInfraDetailsModel);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
