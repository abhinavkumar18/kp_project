package in.kpmg.mr.ysrempanelment.dtos.common;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
@Getter
@Setter
public class HospitalInfraDetailsDTO {

	private Long hosRegId;
	private Long labelValueId;
	private String labelValue;

//	private Long empanlId;
//	private Long labelValueId;
//	//private String attachmentFilePath;
//	//private String createdBy;
//	//private String updatedBy;
//	private List<HospitalInfraAdditionalDetailsDTO> hospitalInfraAdditionalDetailsList;
	
	
	
}
