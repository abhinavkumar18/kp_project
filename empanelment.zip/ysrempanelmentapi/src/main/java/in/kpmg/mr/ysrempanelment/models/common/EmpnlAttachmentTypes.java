package in.kpmg.mr.ysrempanelment.models.common;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@Table(name = "empnl_attachment_type_mst")
@NoArgsConstructor
@AllArgsConstructor
public class EmpnlAttachmentTypes {

    @Id
    @Column(name = "type_id")
    private Integer typeId;

    @Column(name = "type_desc")
    private String typeDesc;

    @Column(name = "is_active")
    private Boolean isActive;



}
