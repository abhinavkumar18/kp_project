package in.kpmg.mr.ysrempanelment.dtos.common;
import lombok.Data;
@Data
public class GeneralInfrastructureDto {
	private Integer labelId;
	private Integer qstId;
	private Integer typeId;
	private Integer empanlId;
	private Long numbers;
	private Long area;
	private Character availability;
	private Boolean isActive;
	private Integer crtBy;
	private Integer updBy;
	
}
