package in.kpmg.mr.ysrempanelment.models.common;

import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "EMPNL_GENERAL_DETAILS")
@Data
public class HospitalBasicInfoModel {
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "ysr.empnl_general_details_empanl_id_seq")
    @SequenceGenerator(name = "ysr.empnl_general_details_empanl_id_seq", sequenceName = "ysr.empnl_general_details_empanl_id_seq", allocationSize = 1)
    private Long EMPANL_ID;
    private Long HOSP_TYPE_ID; //FK might need to change
    private Long ALTERNATE_MOBILE_NO;
    private Long CONSTITUENCY_ID;
    private Long BED_STRENGTH;
    private Long HOSP_PIN;
    private Long CEO_MOB_NO;
    private Long CEO_AADHR_NO;
    private String GEO_CODE_LATITUDE;
    private String GEO_CODE_LONGITUDE;

    private Integer ESTD_YEAR;

 //      private String HOSP_TYPE;
    private String HOSP_NAME;
    @Column(name = "HOSP_PAN")
    private String hospitalPan;
    private String PAN_FILE_PATH;
    private String HOSPITAL_CONTACT_NO;
    @Column(name = "HOSPITAL_EMAIL_ID")
    private String hospitalEmail;
    private Long HOSP_STATE_ID;
    private Long HOSP_DIST_ID;
    private Long MANDAL_ID;
    private String NRST_CITY;
    private String HOSPITAL_ADDRESS;
    private String CEO_NAME;
    private Long CREATED_BY;
    private Long UPDATED_BY;
    @CreationTimestamp
    private Timestamp CREATED_ON;
    @UpdateTimestamp
    private Timestamp UPDATED_ON;
    @Column(name = "PASSWORD")
    private String Password;
    private String IS_EMPNL;
}
