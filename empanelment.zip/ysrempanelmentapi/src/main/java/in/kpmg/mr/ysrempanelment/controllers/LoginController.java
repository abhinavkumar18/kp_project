package in.kpmg.mr.ysrempanelment.controllers;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.EmailOtpDto;
import in.kpmg.mr.ysrempanelment.dtos.common.JwtRequest;
import in.kpmg.mr.ysrempanelment.dtos.common.JwtResponse;
import in.kpmg.mr.ysrempanelment.services.HospitalBasicInfoService;
import in.kpmg.mr.ysrempanelment.services.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class LoginController {
    @Autowired
    HospitalBasicInfoService hospitalBasicInfoService;

    @Autowired
    LoginService loginService;

    @CrossOrigin(origins = "*", allowedHeaders = "*")
    @PostMapping("/loginverification")
    public JwtResponse loginverification(@RequestBody JwtRequest jwtRequest) throws Exception {
        return hospitalBasicInfoService.getloginverification(jwtRequest);}

    @PostMapping("/sendOtpEmail")
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    public ApiResponse<?> sendOtpEmail(@RequestBody EmailOtpDto emailOtpDto){
        return loginService.sendOtpEmail(emailOtpDto);
    }
    @PostMapping("/verifyEmailOtp")
    @CrossOrigin(origins = "*", allowedHeaders = "*")
    public ApiResponse<?> updatePassword(@RequestBody EmailOtpDto emailOtpDto){
        return loginService.updatePasswordwithOtp(emailOtpDto);
    }


}
