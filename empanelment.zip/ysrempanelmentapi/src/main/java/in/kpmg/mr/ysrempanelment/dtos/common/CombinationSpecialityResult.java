package in.kpmg.mr.ysrempanelment.dtos.common;

public interface CombinationSpecialityResult {
    int getSpecialityId();
    int getCombinationSpecialityId();
    String getSpecialityName();


}
