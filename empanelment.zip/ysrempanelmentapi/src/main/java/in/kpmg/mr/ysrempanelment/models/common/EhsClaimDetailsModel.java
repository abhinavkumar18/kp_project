//package in.kpmg.mr.ysrempanelment.models.common;
//
//import lombok.Data;
//import org.hibernate.annotations.CreationTimestamp;
//import org.hibernate.annotations.UpdateTimestamp;
//
//import javax.persistence.*;
//import java.sql.Date;
//import java.sql.Timestamp;
//
//@Data
//@Entity
//@Table(name = "EHS_CLAIM_DETAILS")
//public class EhsClaimDetailsModel {
//    @Id
//    @GeneratedValue(strategy = GenerationType.TABLE, generator = "EHS_CLAIM_DETAILS_SEQ")
//    @SequenceGenerator(name = "EHS_CLAIM_DETAILS_SEQ", sequenceName = "EHS_CLAIM_DETAILS_SEQ", allocationSize = 1)
////    @JoinColumn(referencedColumnName = "INITIATED_ID",name = "ID")
//    private Long ID;
//    private Long CLAIM_ID;
//    private String REMARKS;
//    private String CREATED_BY;
//    @CreationTimestamp
//    private Timestamp CREATED_ON;
//    private String UPDATED_BY;
//    @UpdateTimestamp
//    private Timestamp UPDATED_ON;
//    private Long TOTAL_AMOUNT_CLAIMED;
//    private String PATIENT_TYPE;
//    private Date DATE_OF_ADMISSION;
//    private Date DATE_OF_SURGERY_OR_TREATMENT;
//    private Date DATE_OF_DISCHARGE;
//    private String TREATMENT_TYPE;
//    private String SPECIALITY_ID;
//
////    private Long Initiated_Id;
////    private Character is_init;
//
//
//
//
//}
