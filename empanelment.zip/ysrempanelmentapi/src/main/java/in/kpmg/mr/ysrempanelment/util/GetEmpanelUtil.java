package in.kpmg.mr.ysrempanelment.util;

import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;
import in.kpmg.mr.ysrempanelment.repositories.common.HospitalBasicInfoRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GetEmpanelUtil {
    @Autowired
    private HospitalBasicInfoRepo hospitalBasicInfoRepo;

    public HospitalBasicInfoModel getEmpanelIdModelWithPan(String PanNo){
        HospitalBasicInfoModel hospitalBasicInfoModel = hospitalBasicInfoRepo.findByHospitalPan(PanNo);
        return hospitalBasicInfoModel;
    }
    public HospitalBasicInfoModel getEmpanelIdModelWithEmail(String Email){
        HospitalBasicInfoModel hospitalBasicInfoModel = hospitalBasicInfoRepo.findByHospitalEmail(Email);
        return hospitalBasicInfoModel;
    }
    public Long getEmpanelIdString(String PanNo){
        HospitalBasicInfoModel hospitalBasicInfoModel = hospitalBasicInfoRepo.findByHospitalPan(PanNo);
        return hospitalBasicInfoModel.getEMPANL_ID();
    }
    public HospitalBasicInfoModel getModelwithId(Long id){
        HospitalBasicInfoModel hospitalBasicInfoModel = hospitalBasicInfoRepo.findById(id).get();
        return hospitalBasicInfoModel;
    }
}
