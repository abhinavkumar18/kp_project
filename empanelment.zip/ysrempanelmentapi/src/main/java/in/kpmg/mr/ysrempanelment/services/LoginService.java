package in.kpmg.mr.ysrempanelment.services;

import in.kpmg.mr.ysrempanelment.dtos.common.ApiResponse;
import in.kpmg.mr.ysrempanelment.dtos.common.EmailOtpDto;
import in.kpmg.mr.ysrempanelment.models.common.HospitalBasicInfoModel;
import in.kpmg.mr.ysrempanelment.repositories.common.HospitalBasicInfoRepo;
import in.kpmg.mr.ysrempanelment.util.GetEmpanelUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class LoginService {
	@Autowired
	private HospitalBasicInfoRepo hospitalBasicInfoRepo;
	@Autowired
	EmailService emailService;
	@Autowired
	OtpService otpService;

	@Autowired
	GetEmpanelUtil empanelUtil;

	public ApiResponse<?> sendOtpEmail(EmailOtpDto emailOtpDto) {
		try {
			log.info("Inside of sendOtpEmail functionality");

			HospitalBasicInfoModel hospitalBasicInfoModel1 = empanelUtil
					.getEmpanelIdModelWithEmail(emailOtpDto.getEmailId());
			if (hospitalBasicInfoModel1 == null) {
				return new ApiResponse<>(false, "E-mail not found in database", null,
						HttpStatus.INTERNAL_SERVER_ERROR.value());
			}
			if (emailService.sendEmailOtp(emailOtpDto.getEmailId()))
			{
				 return new ApiResponse<>(true, "Sent an OTP to: "+emailOtpDto.getEmailId(), null,
						HttpStatus.OK.value());}
			else {
				return new ApiResponse<>(false, "Error", null,
						HttpStatus.OK.value());
			}
		} catch (Exception e) {
			log.error("Error occured while fetching the data :", e);
			return new ApiResponse<>(false, e.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
	}

	public ApiResponse<?> updatePasswordwithOtp(EmailOtpDto emailOtpDto) {
		if (otpService.verifyOtp(Integer.parseInt(emailOtpDto.getOtp()), emailOtpDto.getEmailId()))
			return updatePassword(emailOtpDto);
		else
			return new ApiResponse<>(false, "Incorrect password", null, HttpStatus.INTERNAL_SERVER_ERROR.value());

	}

	private ApiResponse<?> updatePassword(EmailOtpDto emailOtpDto) {
		try {
			HospitalBasicInfoModel hospitalBasicInfoModel1 = empanelUtil
					.getEmpanelIdModelWithEmail(emailOtpDto.getEmailId());
			if (hospitalBasicInfoModel1 == null)
				return new ApiResponse<>(false, "Email not registered", null, HttpStatus.INTERNAL_SERVER_ERROR.value());
			hospitalBasicInfoModel1.setPassword(emailOtpDto.getPassword());
			hospitalBasicInfoRepo.save(hospitalBasicInfoModel1);

			return new ApiResponse<>(true, "Password Changed Successfully", null, HttpStatus.OK.value());
		} catch (Exception e) {
			return new ApiResponse<>(false, e.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR.value());
		}

	}
}
