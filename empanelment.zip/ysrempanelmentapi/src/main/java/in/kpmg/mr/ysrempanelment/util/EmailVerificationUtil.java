package in.kpmg.mr.ysrempanelment.util;
import org.apache.commons.validator.routines.EmailValidator;
import org.springframework.stereotype.Component;


@Component
public class EmailVerificationUtil {
    public Boolean isEmailValid(String email){
        EmailValidator validator = EmailValidator.getInstance();
        if (validator.isValid(email)) {
            return true;
        } else {
            return false;
        }
    }
}
