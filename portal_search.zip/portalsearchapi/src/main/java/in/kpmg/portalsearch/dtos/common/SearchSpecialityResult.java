package in.kpmg.portalsearch.dtos.common;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class SearchSpecialityResult {
	@Id
	private BigInteger appid;
	private String specialityName;
	private String specialityCode;
	private String procedureName;
	private String procedureType;
	private String specialInvestigation;
	private String TreatmentProtocol;
	private String AasaraAmt;
	private String pckgs;
	private String procedureInvestigation;
	private String mappedHospitals;
	private String hospitalid;

	public SearchSpecialityResult() {
	}

}