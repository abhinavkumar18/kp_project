package in.kpmg.portalsearch.dtos.common;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class SearchProcedureResult {
	@Id
	private BigInteger appid;
	private String meetingName;
	private String meetingType;
	private String meetingId;
	private String meetingDate;
	private String createdOn;

	public SearchProcedureResult() {
	}

	public SearchProcedureResult(BigInteger appid, String meetingName, String meetingType, String meetingId, String meetingDate,
			String createdOn) {
		this.appid = appid;
		this.meetingName = meetingName;
		this.meetingType = meetingType;
		this.meetingId = meetingId;
		this.meetingDate = meetingDate;
		this.createdOn = createdOn;
	}

}