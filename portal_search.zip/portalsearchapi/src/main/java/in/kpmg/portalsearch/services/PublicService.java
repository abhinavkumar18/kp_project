package in.kpmg.portalsearch.services;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import in.kpmg.portalsearch.dtos.common.AdvanceHospitalSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceProcedureSearch;
import in.kpmg.portalsearch.dtos.common.AdvanceSpecialitySearch;
import in.kpmg.portalsearch.dtos.common.SearchHospitalResult;
import in.kpmg.portalsearch.dtos.common.SearchProcedureResult;
import in.kpmg.portalsearch.dtos.common.SearchSpecialityResult;

import org.springframework.stereotype.Service;
/*import java.util.ArrayList;*/

@Service
public class PublicService {

	@PersistenceContext
	private EntityManager em;
	
	@SuppressWarnings("unchecked")
	public List<SearchHospitalResult> advanceHospitalSearch(AdvanceHospitalSearch request) {

		String nativeQuery ="SELECT ah.hosp_name hospitalName,\n"
				+ "        ah.hosp_type hospitalType,\n"
				+ "                ah.hosp_addr1\n"
				+ "    || ' '\n"
				+ "    || ah.hosp_addr2\n"
				+ "    || ' '\n"
				+ "    || ah.hosp_addr3 hospitalAddress,\n"
				+ "        al.loc_name districtName,\n"
				+ "        spec.specialities_mapped specialities,\n"
				+ "        ah.crt_dt empanalledDate,\n"
				+ "         medco.medco_name medcoName,\n"
				+ "        medco.medco_contact medcoContactNo,\n"
				+ "        mit.mithra_name mitraName,\n"
				+ "        mit.mithra_contact mitraContactNo\n"
				+ "FROM\n"
				+ "    asrim_hospitals ah,\n"
				+ "    asrit_empnl_hospinfo aeh,\n"
				+ "    asrim_locations al,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            LISTAGG(ahs.speciality_id,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                ahs.speciality_id\n"
				+ "            ) specialities_mapped\n"
				+ "        FROM\n"
				+ "            asrim_hosp_speciality ahs,\n"
				+ "            asrim_phase_duration apd\n"
				+ "        WHERE\n"
				+ "            ahs.phase_id = apd.phase_id\n"
				+ "            AND   ahs.renewal = apd.renewal\n"
				+ "-- AND AHS.SPECIALITY_ID='M1'\n"
				+ "            AND   apd.end_dt > SYSDATE\n"
				+ "            AND   ahs.is_active_flg = 'Y'\n"
				+ "        GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) spec,\n"
				+ "    (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            LISTAGG(au.first_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                au.first_name\n"
				+ "            ) mithra_name,\n"
				+ "            LISTAGG(au.cug,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                au.cug\n"
				+ "            ) mithra_contact\n"
				+ "        FROM\n"
				+ "            asrim_mit_users amu,\n"
				+ "            asrim_users au\n"
				+ "        WHERE\n"
				+ "            amu.user_id = au.user_id\n"
				+ "            AND   amu.eff_end_dt IS NULL\n"
				+ "        GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) mit,\n"
				+ "        (\n"
				+ "        SELECT\n"
				+ "            hosp_id,\n"
				+ "            LISTAGG(au.first_name,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                au.first_name\n"
				+ "            ) medco_name,\n"
				+ "            LISTAGG(au.cug,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                au.cug\n"
				+ "            ) medco_contact\n"
				+ "        FROM\n"
				+ "            asrim_nwh_users amu,\n"
				+ "            asrim_users au\n"
				+ "        WHERE\n"
				+ "            amu.user_id = au.user_id\n"
				+ "            AND   amu.eff_end_dt IS NULL\n"
				+ "        GROUP BY\n"
				+ "            hosp_id\n"
				+ "    ) medco\n"
				+ "WHERE\n"
				+ "    ah.hosp_empnl_ref_num = aeh.hospinfo_id\n"
				+ "    AND   ah.hosp_active_yn = 'Y'\n"
				+ "    AND   ah.dist_id = al.loc_id (+)\n"
				+ "    AND   al.loc_hdr_id = 'LH6'\n"
				+ "    AND   spec.hosp_id (+) = ah.hosp_id\n"
				+ "    AND   mit.hosp_id (+) = ah.hosp_id\n"
				+ "    AND   medco.hosp_id (+) = ah.hosp_id\n";
			if(request.getDistrictid() != null)
					nativeQuery = nativeQuery + "   and  ah.dist_id='"+request.getDistrictid()+"'";
			if(request.getHospitalid() != null)
					nativeQuery = nativeQuery +"    and ah.hosp_id='"+request.getHospitalid()+"'";
			if(request.getHospitaltype() != null)
				nativeQuery = nativeQuery + "    and ah.hosp_type ='"+request.getHospitaltype()+"'";
		
		/*nativeQuery = nativeQuery + " ORDER BY\n"
				+ "    district\n";*/
				

		Query query = em.createNativeQuery(nativeQuery, SearchHospitalResult.class);


				List<SearchHospitalResult> searchResults = (List<SearchHospitalResult>)query.getResultList();	
			/*	List<ArrayList> res = new ArrayList<>();
				for(int  i=0;i<searchResults.size();i++) {
					res=ArrayList(searchResults.get(i));
				}*/
					
				
		return searchResults;
		
		

	}
	@SuppressWarnings("unchecked")
	public List<SearchSpecialityResult> advanceSpecialitySearch(AdvanceSpecialitySearch request) {

		String nativeQuery = "SELECT  hosp_id, COUNT(nvl(SPECIALITY_ID,0)),\n"
				+ "            LISTAGG(speciality_id,\n"
				+ "            ',') WITHIN GROUP(\n"
				+ "            ORDER BY\n"
				+ "                speciality_id\n"
				+ "            ) specialities_mapped\n"
				+ "            FROM(\n"
				+ "SELECT\n"
				+ "            DISTINCT AH.hosp_id, ahs.SPECIALITY_ID\n"
				+ "            FROM\n"
				+ "            ASRIM_PHASE_DURATION apd,\n"
				+ "            ASRIM_SURGERY ASU,\n"
				+ "            ASRIM_HOSP_SPECIALITY ahs\n"
				+ "            RIGHT JOIN ASRIM_HOSPITALS AH ON AH.HOSP_ID=ahs.HOSP_ID\n"
				+ "        WHERE  ahs.phase_id = apd.phase_id\n"
				+ "            AND   ahs.renewal = apd.renewal\n"
				+ "            AND   apd.end_dt > SYSDATE\n"
				+ "            AND   ahs.is_active_flg = 'Y'\n"
				+ "            AND ahs.SPECIALITY_ID=ASU.DIS_MAIN_ID\n"
				+ "            AND ASU.STATE_FLAG IN('AP','N','BOTH') AND ASU.ACTIVE_YN='Y'\n"
				+ "            AND AH.HOSP_ACTIVE_YN='Y') HOSP \n"
				+ "          where ";
		if(request.getHospitalid() != null)
			nativeQuery = nativeQuery +" HOSP_ID='"+request.getHospitalid()+"'";
		/*if ((request.getProceduretypeid()) != null)
			nativeQuery = nativeQuery + "  ";

		if (request.getProcedurename() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_NAME) like :meetingName ";

		if (request.getSpecialitycode() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_ID) like :meetingId ";*/

		if (request.getSpecialityid() != null)
			nativeQuery = nativeQuery + "  AND SPECIALITY_ID='"+request.getSpecialityid()+ "'";
		
		nativeQuery = nativeQuery + " GROUP BY\n"
				+ "            hosp_id;\n";

		Query query = em.createNativeQuery(nativeQuery, SearchSpecialityResult.class);


		/*if ((request.getProceduretypeid()) != null)
			query.setParameter("meetingType", request.getProceduretypeid());

		if (request.getProcedurename() != null)
			query.setParameter("meetingName", "%" + request.getProcedurename().toLowerCase() + "%");

		if (request.getSpecialitycode() != null)
			query.setParameter("meetingId", "%" + request.getSpecialitycode().toLowerCase() + "%");		

		if (request.getSpecialityid() != null)
			query.setParameter("venue", request.getSpecialityid());*/

		List<SearchSpecialityResult> searchResults = (List<SearchSpecialityResult>)query.getResultList();		

		return searchResults;

	}
	
	@SuppressWarnings("unchecked")
	public List<SearchProcedureResult> advanceProcedureSearch(AdvanceProcedureSearch request) {

		String nativeQuery = "SELECT\n"
				+ "    dis_main_id AS speciality_code,\n"
				+ "    dis_main_name AS speciality_name,\n"
				+ "    dis_sub_id AS dis_sub_id,\n"
				+ "    dis_name AS dis_sub_name,\n"
				+ "    surgery_id,\n"
				+ "    surg_disp_code,\n"
				+ "    surgery_desc procedure_name,\n"
				+ "    proc_type AS procedure_type,\n"
				+ "    nvl(hosp_stay_amt,0) + nvl(common_cat_amt,0) + nvl(icd_amt,0) AS packageamount,\n"
				+ "    hosp_stay_amt,\n"
				+ "    common_cat_amt,\n"
				+ "    icd_amt,\n"
				+ "    HOSP_STAY_AMT_GOVT,\n"
				+ "    duration_of_stay,\n"
				+ "    IS_PERDM,\n"
				+ "    preinvestigations,\n"
				+ "    postinvestigations,\n"
				+ "    medinvestigations\n"
				+ "FROM\n"
				+ "    (\n"
				+ "         SELECT DISTINCT\n"
				+ "            ad.dis_main_id,\n"
				+ "            ad.dis_main_name,\n"
				+ "            ads.dis_sub_id,\n"
				+ "            ads.dis_name,\n"
				+ "            ac.surgery_id,\n"
				+ "            ac.surg_disp_code,\n"
				+ "            ac.surgery_desc,\n"
				+ "            proc_type,\n"
				+ "            nvl(ahs.hosp_stay_amt,ac.hosp_stay_amt) hosp_stay_amt,\n"
				+ "            nvl(ahs.common_surgery_amt,ac.common_surgery_amt) common_cat_amt,\n"
				+ "            nvl(ahs.buffer_amt,ac.buffer_amt) icd_amt,\n"
				+ "            ac.duration_of_stay,\n"
				+ "            hosp_stay_amt_govt,\n"
				+ "            ac.is_perdm,\n"
				+ "            preinvest.details preinvestigations,\n"
				+ "            postinvest.details postinvestigations,\n"
				+ "            medinvest.details medinvestigations\n"
				+ "        FROM\n"
				+ "            asrim_disease_main ad,\n"
				+ "            asrim_disease_sub ads,\n"
				+ "            asrim_surgery ac,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'PRE'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) preinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'POST'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) postinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'MED'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) medinvest,\n"
				+ "            asrim_hosp_surgeries ahs\n"
				+ "        WHERE\n"
				+ "            ad.dis_main_id = ads.dis_main_id\n"
				+ "            AND   ad.dis_main_id = ac.dis_main_id\n"
				+ "            AND   ads.dis_sub_id = ac.dis_sub_id\n"
				+ "            AND   ac.surgery_id = ahs.surgery_id (+)\n"
				+ "            AND   preinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   postinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   medinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   ac.active_yn = 'Y'\n"
				+ "            AND   ad.dis_active_yn = 'Y'\n"
				+ "            AND   ac.state_flag IN (\n"
				+ "                'BOTH',\n"
				+ "                'AP',\n"
				+ "                'N'\n"
				+ "            )\n"
				+ "            AND   ac.surgery_id != 'M6.5'\n"
				+ "        UNION\n"
				+ "        SELECT DISTINCT\n"
				+ "            ad.dis_main_id,\n"
				+ "            ad.dis_main_name,\n"
				+ "            ads.dis_sub_id,\n"
				+ "            ads.dis_name,\n"
				+ "            ac.surgery_id,\n"
				+ "            ac.surg_disp_code,\n"
				+ "            ac.surgery_desc,\n"
				+ "            proc_type,\n"
				+ "            nvl(ac.hosp_stay_amt,0) hosp_stay_amt,\n"
				+ "            nvl(ac.common_surgery_amt,0) common_cat_amt,\n"
				+ "            nvl(ac.buffer_amt,0) icd_amt,\n"
				+ "            ac.duration_of_stay,\n"
				+ "            hosp_stay_amt_govt,\n"
				+ "            ac.is_perdm,\n"
				+ "            preinvest.details preinvestigations,\n"
				+ "            postinvest.details postinvestigations,\n"
				+ "            medinvest.details medinvestigations\n"
				+ "        FROM\n"
				+ "            asrim_disease_main ad,\n"
				+ "            asrim_disease_sub ads,\n"
				+ "            asrim_surgery ac,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'PRE'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) preinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'POST'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) postinvest,\n"
				+ "            (\n"
				+ "                SELECT\n"
				+ "                    surgery_id,\n"
				+ "                    dstring_agg(invest_desc) AS details\n"
				+ "                FROM\n"
				+ "                    asrim_surgery_invest_ap asi\n"
				+ "                WHERE\n"
				+ "                    asi.active_yn (+) = 'Y'\n"
				+ "                    AND   upper(asi.pre_or_post_op) IN (\n"
				+ "                        'MED'\n"
				+ "                    )\n"
				+ "                GROUP BY\n"
				+ "                    surgery_id\n"
				+ "            ) medinvest\n"
				+ "        WHERE\n"
				+ "            ad.dis_main_id = ads.dis_main_id\n"
				+ "            AND   ad.dis_main_id = ac.dis_main_id\n"
				+ "            AND   ads.dis_sub_id = ac.dis_sub_id\n"
				+ "            AND   preinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   postinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   medinvest.surgery_id (+) = ac.surgery_id\n"
				+ "            AND   ac.active_yn = 'Y'\n"
				+ "            AND   ad.dis_active_yn = 'Y'\n"
				+ "            AND   ac.state_flag IN (\n"
				+ "                'BOTH',\n"
				+ "                'AP',\n"
				+ "                'N'\n"
				+ "            )\n"
				+ "            AND   ac.surgery_id = 'M6.5'\n"
				+ "    ) a\n";
	/*	if ((request.getMeetingType()) != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_TYPE)  like :meetingType ";

		if (request.getMeetingName() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_NAME) like :meetingName ";

		if (request.getMeetingId() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_ID) like :meetingId ";

		if (request.getVenue() != null)
			nativeQuery = nativeQuery + " AND LOWER(COM.MEETING_VENUE) like :venue ";

		if ((request.getStartdate()) != null && (request.getStartdate().length() > 0))
			nativeQuery = nativeQuery + " AND COM.CREATED_ON >= TIMESTAMP(:fromDate)";

		if ((request.getEnddate()) != null && (request.getEnddate().length() > 0))
			nativeQuery = nativeQuery + " AND COM.CREATED_ON <= TIMESTAMP(:toDate)";*/

		nativeQuery = nativeQuery + " ORDER BY\n"
				+ "    substr(dis_main_id,0,1) DESC,\n"
				+ "    to_number(substr(dis_main_id,regexp_instr(dis_main_id,'[^A-Z]') ) ),\n"
				+ "    dis_sub_id,\n"
				+ "    surg_disp_code\n";

		Query query = em.createNativeQuery(nativeQuery, SearchProcedureResult.class);


		/*if ((request.getMeetingType()) != null)
			query.setParameter("meetingType", "%" + request.getMeetingType().toLowerCase() + "%");

		if (request.getMeetingName() != null)
			query.setParameter("meetingName", "%" + request.getMeetingName().toLowerCase() + "%");

		if (request.getMeetingId() != null)
			query.setParameter("meetingId", "%" + request.getMeetingId().toLowerCase() + "%");		

		if (request.getVenue() != null)
			query.setParameter("venue", "%" + request.getVenue().toLowerCase() + "%");
		
		if ((request.getStartdate()) != null && (request.getStartdate().length() > 0))
			query.setParameter("fromDate", request.getStartdate() + " 00:00:00");

		if ((request.getEnddate()) != null && (request.getEnddate().length() > 0))
			query.setParameter("toDate", request.getEnddate() + " 23:59:59");*/

		List<SearchProcedureResult> searchResults = (List<SearchProcedureResult>)query.getResultList();		

		return searchResults;

	}


	
}