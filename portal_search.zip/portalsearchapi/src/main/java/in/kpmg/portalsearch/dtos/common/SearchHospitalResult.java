package in.kpmg.portalsearch.dtos.common;

import java.math.BigInteger;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity

public class SearchHospitalResult {
	/*public BigInteger getAppid() {
		return appid;
	}

	public void setAppid(BigInteger appid) {
		this.appid = appid;
	}
*/
	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getHospitalType() {
		return hospitalType;
	}

	public void setHospitalType(String hospitalType) {
		this.hospitalType = hospitalType;
	}

	public String getHospitalAddress() {
		return hospitalAddress;
	}

	public void setHospitalAddress(String hospitalAddress) {
		this.hospitalAddress = hospitalAddress;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}

	public String getMandalName() {
		return mandalName;
	}

	public void setMandalName(String mandalName) {
		this.mandalName = mandalName;
	}

	public String getSpecialities() {
		return specialities;
	}

	public void setSpecialities(String specialities) {
		this.specialities = specialities;
	}

	public String getEmpanalledDate() {
		return empanalledDate;
	}

	public void setEmpanalledDate(String empanalledDate) {
		this.empanalledDate = empanalledDate;
	}

	public String getMedcoName() {
		return medcoName;
	}

	public void setMedcoName(String medcoName) {
		this.medcoName = medcoName;
	}

	public String getMedcoContactNo() {
		return medcoContactNo;
	}

	public void setMedcoContactNo(String medcoContactNo) {
		this.medcoContactNo = medcoContactNo;
	}

	public String getMitraName() {
		return mitraName;
	}

	public void setMitraName(String mitraName) {
		this.mitraName = mitraName;
	}

	public String getMitraContactNo() {
		return mitraContactNo;
	}

	public void setMitraContactNo(String mitraContactNo) {
		this.mitraContactNo = mitraContactNo;
	}

	@Id
	private String hospitalid;
	/*private BigInteger appid;*/
	private String hospitalName;
	
	public String getHospitalid() {
		return hospitalid;
	}

	public void setHospitalid(String hospitalid) {
		this.hospitalid = hospitalid;
	}

	private String hospitalType;
	private String hospitalAddress;
	private String districtName;
	private String mandalName;
	private String specialities;
	private String empanalledDate;
	private String medcoName;
	private String medcoContactNo;
	private String mitraName;
	private String mitraContactNo;

	public SearchHospitalResult() {
	}

}