package in.kpmg.apmc;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javax.net.ssl.SSLContext;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

public class SaveAPIResponseToExcel {

    private static final String EXCEL_FILE_PATH = "C:\\Users\\aditipruthi1\\OneDrive - KPMG\\YSR Aarogyasri\\Requirement Gathering And Management\\External APIs\\APMC\\22-11-2023\\apmc_data.xlsx";
    private static final String API_URL = "https://apmc.ap.gov.in/apmcwebservices/api/apmc/DoctorRegistrationDetails?fmr_Number=";

    public static void main(String[] args) throws IOException, KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        String bearerToken = "kJjN4vlrNSnYbExjgiUIlpMQxxrS3L8gN9BYASwfr5xcrc7qYxazf7zJ3-42sUqmcBRng2o3hsCeCCCM9M2LZtGrOsrWQ0jEWOaJjT_LAECl90Dmld1c5VjyOTsY1GRIw8bPRwU2wyCHNYyyS_ppVg3ssQKt3tK8IrDUALHeuwG-_bjp0v4RZmjz7V5gwdSbQIrHaw_hJT8WXuum5qhroaUXmddRpzHrCZfZEyM77Q8jU9hAQq0obwOnPxsfJfC-j-BQVzgoclOMdqE9GljCDaAJTqKT2BNvpeUCuqN9XQ24MbKuRBZUZnHrm3sn-XS4qCSQHZXK5G0vyx8Hp7SkUQ";
      //  String params[]=  {"APMC/FMR/64290","APMC/FMR/71739","APMC/FMR/96981","APMC/FMR/79534","APMC/FMR/104422","APMC/FMR/124502","APMC/FMR/122602","APMC/FMR/123432","APMC/FMR/59040","APMC/FMR/83127","APMC/FMR/96236","APMC/FMR/102000","APMC/FMR/35247","APMC/FMR/101102","APMC/FMR/91974","APMC/FMR/91855","APMC/FMR/36707","APMC/FMR/91051","APMC/FMR/95511","APMC/FMR/124242","APMC/FMR/14458","APMC/FMR/40139","APMC/FMR/41198","APMC/FMR/101304","APMC/FMR/110285","APMC/FMR/97351","APMC/FMR/36957","APMC/FMR/86689","APMC/FMR/98795","APMC/FMR/109282","APMC/FMR/97152","APMC/FMR/86711","APMC/FMR/82473","APMC/FMR/46399","APMC/FMR/74546","APMC/FMR/83618","APMC/FMR/123658","APMC/FMR/76719","APMC/FMR/44513","APMC/FMR/76818","APMC/FMR/108630","APMC/FMR/84980","APMC/FMR/60122","APMC/FMR/18243","APMC/FMR/66461","APMC/FMR/33934","APMC/FMR/68390","APMC/FMR/91833"};
      //  String params[]=  {"APMC/FMR/114036","APMC/FMR/92970","APMC/FMR/63989","TSMC/FMR/56325","TSMC/FMR/75124","TSMC/FMR/60234","TSMC/FMR/25505","APMC/FMR/60234","APMC/FMR/106530","APMC/FMR/114214","APMC/FMR/92932","HMC12336","APMC/FMR/127449","APMC/FMR/97423","APMC/FMR/40907","APMC/FMR/38234","APMC/FMR/65296","APMC/FMR/104143","APMC/FMR/102694","APMC/FMR/35176","APMC/FMR/103645","APMC/FMR/101838","APMC/FMR/123880","APMC/FMR/85220","APMC/FMR/77351","APMC/FMR/63002","APMC/FMR/113730"};
       // String params[]=  {"APMC/FMR/59738","APMC/FMR/101731","APMC/FMR/67054","APMC/FMR/112693","APMC/FMR/121102","APMC/FMR/104133","APMC/FMR/117473","APMC/FMR/119209","APMC/FMR/82725","APMC/FMR/98389","APMC/FMR/92591","APMC/FMR/117278","APMC/FMR/127169","APMC/FMR/105520","APMC/FMR/97821","APMC/FMR/87818","APMC/FMR/102475","APMC/FMR/97622","APMC/FMR/77323","APMC/FMR/80772","APMC/FMR/61077","APMC/FMR/124293","APMC/FMR/124292","APMC/FMR/52129"};
//        String params[]=  {"APMC/FMR/52129","APMC/FMR/123934","APMC/FMR/100101","APMC/FMR/110742","APMC/FMR/102900","APMC/FMR/102501","APMC/FMR/103033","APMC/FMR/112182","APMC/FMR/119722","KMC/FMR/16742","KMC/FMR/73443","APMC/FMR/97199","APMC/FMR/46530","APMC/FMR/59738","APMC/FMR/92237","APMC/FMR/125708","APMC/FMR/112752","APMC/FMR/109543"};
       // String params[]= {"APMC/FMR/76349","APMC/FMR/118072","APMC/FMR/70155","APMC/FMR/125338","APMC/FMR/114661","APMC/FMR/74770","APMC/FMR/90096","APMC/FMR/102509","APMC/FMR/93194","APMC/FMR/98372","APMC/FMR/124627","APMC/FMR/87910","APMC/FMR/88702","APMC/FMR/81946","APMC/FMR/88701","APMC/FMR/35354","APMC/FMR/73882","APMC/FMR/35743","APMC/FMR/113264","APMC/FMR/91401","APMC/FMR/86287","APMC/FMR/88553"};
        //String params[] = {"APMC/FMR/116363","APMC/FMR/101602","APMC/FMR/74922","APMC/FMR/41708","APMC/FMR/41302","APMC/FMR/58751","APMC/FMR/100819","APMC/FMR/81463","APMC/FMR/7444","APMC/FMR/104911","APMC/FMR/119228","APMC/FMR/120645","APMC/FMR/115563","APMC/FMR/120350","APMC/FMR/115832","APMC/FMR/121892","APMC/FMR/107409","APMC/FMR/92900","APMC/FMR/80664","APMC/FMR/78011","APMC/FMR/102168","APMC/FMR/85940","APMC/FMR/83217","APMC/FMR/10705","APMC/FMR/84017"};
        String params[] = {"APMC/FMR/98242","APMC/FMR/119706","APMC/FMR/94848","APMC/FMR/103433","APMC/FMR/110704","APMC/FMR/116077","APMC/FMR/118463","APMC/FMR/102046","APMC/FMR/115512","APMC/FMR/111999","TSMC/FMR/15226","TSMC/FMR/19608","APMC/FMR/47555","APMC/FMR/79570","APMC/FMR/127963","APMC/FMR/57220","APMC/FMR/44528","APMC/FMR/58319"};

        // Disable SSL verification (not recommended for production)
        SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, (chain, authType) -> true).build();

        try (CloseableHttpClient httpClient = HttpClients.custom()
                .setSSLContext(sslContext)
                .setSSLHostnameVerifier(NoopHostnameVerifier.INSTANCE)
                .build()) {

            ObjectMapper objectMapper = new ObjectMapper();
            ArrayNode allResponses = objectMapper.createArrayNode();

            for (String param : params) {
                String apiUrl = API_URL + param;
                HttpGet httpGet = new HttpGet(apiUrl);
                httpGet.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + bearerToken);

                try {
                    HttpResponse response = httpClient.execute(httpGet);
                    int statusCode = response.getStatusLine().getStatusCode();

                    if (statusCode == 200) {
                        String json = EntityUtils.toString(response.getEntity());
                        JsonNode jsonResponse = objectMapper.readTree(json);
                        allResponses.add(jsonResponse);
                        System.out.println("Data for param " + param + " added to JSON.");
                    } else {
                        System.err.println("API request failed with status code: " + statusCode);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            writeToExcel(allResponses);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void writeToExcel(ArrayNode allResponses) throws IOException {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("API Data");
            int colIndex = 0;
            int rowIndex = 1;

            for (JsonNode data : allResponses) {
                Row dataRow = sheet.createRow(rowIndex++);
                colIndex = 0;

                for (JsonNode field : data) {
                    if (field.isObject()) {
                        for (JsonNode nestedField : field) {
                            if (nestedField.isObject()) {
                                for (JsonNode nestedNestedField : nestedField) {
                                    Cell dataCell = dataRow.createCell(colIndex++);
                                    dataCell.setCellValue(nestedNestedField.asText());
                                }
                            }
                            Cell dataCell = dataRow.createCell(colIndex++);
                            dataCell.setCellValue(nestedField.asText());
                        }
                    } else {
                        Cell dataCell = dataRow.createCell(colIndex++);
                        dataCell.setCellValue(field.asText());
                    }
                }
            }

            try (FileOutputStream fileOut = new FileOutputStream(EXCEL_FILE_PATH)) {
                workbook.write(fileOut);
            }

            System.out.println("Data exported to " + EXCEL_FILE_PATH);
        }
    }
}

