package in.kpmg.ap.ysr.websitehitcount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class  WebsiteHitCounterApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsiteHitCounterApplication.class, args);
		while(true);
	}

}
