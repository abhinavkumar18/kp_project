package in.kpmg.ap.ysr.websitehitcount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsiteHitCounterApplicationTests {

	@Test
	void contextLoads() {
	}

}
