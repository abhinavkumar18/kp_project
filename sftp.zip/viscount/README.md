# WebsiteHitCounter
Website Hit Counter API using Java Spring boot

Output:


![WebsiteHitCounter](https://user-images.githubusercontent.com/122785048/217503600-d3fb234f-1090-4aba-8089-0905548f7da1.png)
![WebsiteHitPerUserCount](https://user-images.githubusercontent.com/122785048/217503612-b75054aa-a825-446a-a002-fe8fcd55af32.png)
